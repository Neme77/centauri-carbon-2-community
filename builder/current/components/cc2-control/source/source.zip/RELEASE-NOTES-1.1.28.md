# CC2 Control 1.1.28 stable

Test build focused on live print telemetry correctness.

- removes the remaining demo values from the Job page;
- updates temperatures and fan readings independently of the selected UI language;
- keeps Dashboard and Job status labels synchronized with the live printer state;
- reports real object counts instead of the old four-object example;
- adds `print.total_layers` to `/api/printer`;
- accepts total-layer telemetry when exposed by the firmware;
- otherwise reads and caches the layer count from the active local G-code;
- shows elapsed time, remaining time, the estimated completion clock time and the projected total duration;
- reads file-detail layers, estimated duration, filament weight and temperatures from the selected G-code, replacing the old inspection placeholders;
- reports object totals, active objects, exclusions and Klipper's real current object only while object data is available;
- removes synthetic thermal curves, mesh/screw examples and stale startup values from the live HTTP interface;
- shows an em dash when a value is genuinely unavailable.

This stable release has been validated on the printer and can replace
the public 1.1.27 release.
