# CC2 Control 1.1.13

## Persistent materials

- Material presets are now read from and written to
  `/opt/usr/cc2-control/material-presets.json`.
- Saves use a temporary file followed by an atomic rename.
- Presets are shared by every browser opening the printer dashboard.
- Defaults include PLA, PETG, ABS, ASA, TPU and PA-CF.
- Existing browser-only presets are used as a fallback and migrate to the
  printer on the next save.
- Canvas accepts custom safe names containing letters, numbers, `+`, `-` and
  `_`, with editable minimum and maximum nozzle temperatures.

## Referenced 3D bed mesh

- Adds a translucent ideal build-plate plane at `Z=0`.
- Adds Cartesian X, Y and Z axes.
- Adds sparse vertical stems from the ideal plane to the measured surface.
- Keeps rotation, pinch/wheel zoom and adjustable Z exaggeration.
- Uses the existing browser canvas renderer and adds no external library or
  continuous animation.

## Upgrade files

Deploy the binary, `web/index.html` and `start.sh`. The existing MQTT
configuration is preserved. Do not pre-create `material-presets.json`; the
service supplies defaults until the first successful save.
