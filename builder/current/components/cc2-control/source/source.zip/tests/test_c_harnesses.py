#!/usr/bin/env python3
"""Compile and run the standalone C test harnesses that no other driver runs."""
import os
import pathlib
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
FLAGS = ["-O2", "-std=c11", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-D_POSIX_C_SOURCE=200809L", "-pthread", *os.environ.get("CC2_TEST_CFLAGS", "").split()]
BACKEND = [ROOT / "src/mqtt.c", ROOT / "src/console.c", ROOT / "src/control.c", ROOT / "src/panda.c", ROOT / "src/uds.c", ROOT / "src/network_status.c"]
HARNESSES = {
    "test_panda_metadata.c": [],
    "test_maintenance_barrier.c": [],
    "test_maintenance_api.c": BACKEND,
    "test_rfid_runtime.c": [],
    "test_rfid_lifecycle.c": [],
    "test_backup.c": BACKEND,
    "test_external_filament.c": [ROOT / "src/control.c"],
    "test_canvas_state.c": [ROOT / "src/control.c"],
    "test_canvas_recovery_load.c": [ROOT / "src/control.c"],
    "test_app_update_guards.c": BACKEND,
    "test_gcode_metadata.c": [],
    "test_gcode_layer_path.c": [],
    "test_object_query.c": BACKEND,
    "test_exclude_objects.c": BACKEND,
    # test_file_ops.c and test_orca_upload.c include src/main.c themselves.
    "test_file_ops.c": BACKEND,
    "test_file_analysis.c": BACKEND,
    "test_recovery_download.c": BACKEND,
    "test_emergency_latch.c": [],
    "test_emergency_stop_direct.c": [ROOT / "src/console.c"],
    "test_emergency_stop_edges.c": [ROOT / "src/console.c"],
    "test_emergency_stop_deadline.c": [ROOT / "src/console.c"],
    "test_runtime_limits.c": BACKEND,
    "test_mqtt_limits.c": [],
    "test_calibrated_start.c": BACKEND,
    "test_external_feed_start.c": BACKEND,
    "test_usb_print_start.c": BACKEND,
    "test_usb_copy_verified.c": BACKEND,
    "test_usb_copy_throttle.c": BACKEND,
    "test_usb_start_checked_once.c": BACKEND,
    "test_usb_queue_start.c": BACKEND,
    "test_usb_slot_swap.c": BACKEND,
    "test_internal_start_background.c": BACKEND,
    "test_usb_copy_cleanup.c": BACKEND,
    "test_usb_start_fixes.c": BACKEND,
    "test_usb_start_large_and_stall.c": BACKEND,
    "test_queue_canvas_combined.c": BACKEND,
    "test_usb_canvas_refresh.c": BACKEND,
    "test_usb_large_file.c": BACKEND,
    "test_active_scan_abort.c": BACKEND,
    "test_external_feed.c": BACKEND,
    "test_filament_metadata.c": BACKEND,
    "test_orca_upload.c": BACKEND,
    "test_mqtt_workload.c": [],
    "test_mqtt_registration.c": [],
    "test_canvas_discovery.c": [],
    "test_printer_replies.c": [],
    "test_print_options.c": [],
    "test_light_api.c": BACKEND,
    "test_grille_api.c": BACKEND,
    "test_rotation_core.c": [],
    "test_load_cell_guide_core.c": [],
    "test_calibration_tools.c": BACKEND,
    "test_history_api.c": BACKEND,
    "test_print_completion.c": BACKEND,
    "test_uds.c": [ROOT / "src/uds.c"],
    "test_canvas_uds.c": BACKEND,
    "test_experiments.c": BACKEND,
    "test_bed_drying.c": BACKEND,
    "test_nozzle_expansion.c": BACKEND,
    "test_chamber_preheat.c": BACKEND,
    "test_runout.c": BACKEND,
    "test_mesh_api.c": BACKEND,
    "test_uds_diagnostic.c": BACKEND,
    "test_tuning_api.c": BACKEND,
    "test_pressure_advance_api.c": BACKEND,
    "test_quick_preferences.c": BACKEND,
    "test_pid_api.c": BACKEND,
    "test_layer_path_deadline.c": BACKEND,
    "test_screw_tram_end.c": BACKEND,
    "test_mesh_align.c": BACKEND,
    "test_z_offset_api.c": BACKEND,
    "test_plates.c": BACKEND,
    "test_plate_probe_result.c": BACKEND,
    "test_canvas_unload.c": BACKEND,
    "test_pending_autosave.c": BACKEND,
    "test_spools.c": BACKEND,
    "test_spoolman.c": BACKEND,
    "test_queue_tracking.c": BACKEND,
    "test_control_actions.c": [ROOT / "src/control.c"],
    "test_nozzle_target_limits.c": [ROOT / "src/control.c"],
    "test_screw_history.c": [ROOT / "src/control.c"],
}

with tempfile.TemporaryDirectory(prefix="cc2-c-harness-") as temporary:
    for name, sources in HARNESSES.items():
        binary = pathlib.Path(temporary) / name[:-2]
        subprocess.run(["cc", *FLAGS, str(ROOT / "tests" / name), *map(str, sources), "-o", str(binary), "-lm"], check=True)
        subprocess.run([str(binary)], cwd=temporary, check=True)
        print(f"PASS: {name}")
