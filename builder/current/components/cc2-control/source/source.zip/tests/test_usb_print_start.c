#define main cc2_main_original
#define mqtt_start_print mock_mqtt_start_print
#define console_emergency_stop mock_console_emergency_stop
#include "../src/main.c"
#undef main
#undef mqtt_start_print
#undef console_emergency_stop
#include <assert.h>

static int emergency_stops;
int mock_console_emergency_stop(console_state *state, char *reason, size_t cap) {
    (void)state; (void)reason; (void)cap; emergency_stops++; return 0;
}

/* Holds the worker right before the copy until the test releases it: a slow copy on demand. */
static int gate[2];
static atomic_int copy_held;
static void hold_copy(void) {
    atomic_store(&copy_held, 1);
    char byte; assert(read(gate[0], &byte, 1) == 1);
    atomic_store(&copy_held, 0);
}
static void release_copy(void) { assert(write(gate[1], "x", 1) == 1); }
/* The worker scans the file before it reaches the copy; a cancel during the scan ends it without a copy.
 * A test about a held copy waits until the worker really holds there. */
static void wait_held(void) {
    for (int i = 0; i < 5000 && !atomic_load(&copy_held); ++i) nanosleep(&(struct timespec){0, 1000000}, NULL);
    assert(atomic_load(&copy_held));
}


/* #344: a print dialog start from USB scans and copies the file on a worker thread. The socket gets
 * its answer only from usb_start_tick() on the main loop, which checks the printer again first. */
static char events[128], started_name[PATH_MAX_LOCAL];

static int fake_uds(const char *request, char **reply, size_t *length) {
    (void)request;
    static const char acknowledged[] = "{\"id\":1001,\"result\":{}}";
    strcat(events, "clear;");
    *reply = strdup(acknowledged); *length = strlen(acknowledged);
    return *reply ? 0 : -1;
}

static int mock_start_result; /* 0: the start request goes out; else it cannot be sent */
int mock_mqtt_start_print(mqtt_client *c, const char *media, const char *filename,
                          const int *tools, const int *trays, size_t count,
                          char layout, int bedlevel_force, int timelapse) {
    if (mock_start_result) return mock_start_result;
    (void)c; (void)tools; (void)trays; (void)layout; (void)bedlevel_force; (void)timelapse;
    char text[32]; snprintf(text, sizeof(text), "1020:%s:%zu;", media, count); strcat(events, text);
    snprintf(started_name, sizeof(started_name), "%s", filename);
    return 0;
}

static int starts_sent(void) {
    int count = 0;
    for (const char *at = events; (at = strstr(at, "1020:")); at += 5) count++;
    return count;
}

static void write_file(const char *path, const char *text) {
    FILE *file = fopen(path, "wb"); assert(file);
    assert(fputs(text, file) >= 0); assert(!fclose(file));
}

static int imports(void) {
    DIR *dir = opendir("gcode"); assert(dir);
    int count = 0; struct dirent *entry;
    while ((entry = readdir(dir))) if (!strncmp(entry->d_name, GCODE_USB_IMPORT_PREFIX, 8)) count++;
    closedir(dir);
    return count;
}

static int answer(int peer, char *response, size_t cap) {
    size_t used = 0; ssize_t n;
    { struct timeval rcv_limit = {30, 0}; /* never wait forever: a missing answer fails the test */
      setsockopt(peer, SOL_SOCKET, SO_RCVTIMEO, &rcv_limit, sizeof(rcv_limit)); }
    while (used + 1 < cap && (n = recv(peer, response + used, cap - 1 - used, 0)) > 0) used += (size_t)n;
    response[used] = 0; close(peer);
    assert(used > 0);
    return atoi(strchr(response, ' ') + 1);
}

static int no_answer_yet(int peer) {
    char byte; return recv(peer, &byte, 1, MSG_DONTWAIT) < 0 && (errno == EAGAIN || errno == EWOULDBLOCK);
}

/* Begins a start; returns the peer socket when the worker took it, or answers in `response` and -1. */
static int begin(mqtt_client *mqtt, const char *body, char *response, size_t cap, int *status) {
    events[0] = 0; started_name[0] = 0;
    int pair[2]; assert(!socketpair(AF_UNIX, SOCK_STREAM, 0, pair));
    if (usb_start_begin(pair[0], mqtt, body, strlen(body))) return pair[1];
    close(pair[0]);
    *status = answer(pair[1], response, cap);
    return -1;
}

/* The printer's Canvas report, one loaded tray 1 (method 2005), as a fresh report. */
static void canvas_reports(mqtt_client *mqtt) {
    mqtt->last_message = time(NULL); mqtt->canvas_revision++; mqtt->canvas_discovery_complete = 1;
    mqtt->canvas_snapshot_len = (size_t)snprintf(mqtt->canvas_snapshot, sizeof(mqtt->canvas_snapshot),
        "{\"id\":2005,\"result\":{\"canvas_info\":{\"canvas_list\":[{\"canvas_id\":0,\"connected\":1,\"tray_list\":["
        "{\"tray_id\":1,\"status\":1,\"filament_type\":\"PLA\"},{\"tray_id\":3,\"status\":1,\"filament_type\":\"PLA\"}]}]}}}");
}
/* Ticks the main loop until the start is answered (at most 3 s), answering each Canvas report asked for. */
static void settle(mqtt_client *mqtt, int reports) {
    for (int i = 0; i < 3000 && usb_start_active(); ++i) {
        if (reports && mqtt->canvas_refresh_due) { mqtt->canvas_refresh_due = 0; canvas_reports(mqtt); }
        usb_start_tick(mqtt); if (usb_start_active()) nanosleep(&(struct timespec){0, 1000000}, NULL);
    }
    assert(!usb_start_active());
}

static void wait_worker(void) {
    for (int i = 0; i < 5000 && !atomic_load(&usb_start_done); ++i) nanosleep(&(struct timespec){0, 1000000}, NULL);
    assert(atomic_load(&usb_start_done));
}

/* A test that waits for something that never comes ends red with a message instead of hanging the suite. */
static void test_too_long(int signal_number) {
    (void)signal_number;
    static const char text[] = "FAIL: the test ran longer than 300 s (an answer that never came?)\n";
    if (write(2, text, sizeof(text) - 1) < 0) {}
    _exit(1);
}
int main(void) {
    signal(SIGALRM, test_too_long); alarm(300);
    char response[1024]; int status = 0;
    char dir[] = "usb-start-XXXXXX"; /* the harnesses share one working directory */
    assert(mkdtemp(dir) && !chdir(dir));
    assert(!mkdir("gcode", 0700) && !mkdir("usb", 0700) && !mkdir("maps", 0700));
    layer_store_dir = "maps";
    static char big[3 * 65536 + 123];
    for (size_t i = 0; i + 1 < sizeof(big); ++i) big[i] = (i % 61 == 60) ? '\n' : (char)('A' + i % 26);
    big[0] = ';'; big[sizeof(big) - 1] = 0;
    write_file("usb/cube.gcode", big);
    write_file("usb/flat.gcode", "G28\nG1 X10 Y10 E1\n");
    write_file("usb/two.gcode", "T0\nG1 X1 E1\nT1\nG1 X2 E1\n");
    write_file("autosave.cfg", "[bed_mesh default]\nx_count = 11\ny_count = 11\npoints =\n  0, 0\n");
    gcode_internal_root = "gcode"; gcode_usb_root = "usb"; printer_autosave_path = "autosave.cfg";
    canvas_color_table_uds = fake_uds;
    mqtt_client mqtt = {0};
    mqtt.connected = mqtt.registered = 1; mqtt.have_machine_status = 1; mqtt.machine_status = 1;

    /* The worker takes the socket; nothing is answered or started before the main loop's tick. */
    int peer = begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0 && usb_start_active());
    assert(printer_change_blocked() && strstr(printer_change_blocked(), "USB file"));
    /* A second USB start while the first one copies is refused at once. */
    assert(begin(&mqtt, "usb\nflat.gcode\n\nA\nsaved\n0", response, sizeof(response), &status) < 0);
    assert(status == 409 && strstr(response, "still being copied"));
    wait_worker();
    assert(no_answer_yet(peer) && !events[0]);
    usb_start_tick(&mqtt);
    assert(!usb_start_active() && !printer_change_blocked());
    assert(answer(peer, response, sizeof(response)) == 202);
    assert(strstr(response, "\"imported_from_usb\":true") && strstr(response, "\"storage_media\":\"local\""));
    assert(!strcmp(events, "clear;1020:local:0;"));
    assert(!strncmp(started_name, GCODE_USB_IMPORT_PREFIX, 8) && strstr(started_name, "_cube.gcode"));
    char copy[PATH_MAX_LOCAL * 2]; snprintf(copy, sizeof(copy), "gcode/%s", started_name);
    FILE *file = fopen(copy, "rb"); assert(file);
    static char back[sizeof(big)]; size_t got = fread(back, 1, sizeof(back), file); fclose(file);
    assert(got == sizeof(big) - 1 && !memcmp(back, big, got));
    assert(imports() == 1);
    assert(!unlink(copy));

    /* The printer started something during the copy: refused, and the copy is removed again. */
    peer = begin(&mqtt, "usb\nflat.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0);
    wait_worker();
    assert(imports() == 1);
    mqtt.machine_status = 2;
    usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 409 && strstr(response, "idle printer"));
    assert(!events[0] && imports() == 0 && !usb_start_active());
    mqtt.machine_status = 1;

    /* An earlier import of the same file is never removed by a refused start. */
    write_file("gcode/" GCODE_USB_IMPORT_PREFIX "kept", "x"); /* stands in for an unrelated import */
    peer = begin(&mqtt, "usb\nflat.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker(); usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 202);
    char kept_copy[PATH_MAX_LOCAL * 2]; snprintf(kept_copy, sizeof(kept_copy), "gcode/%s", started_name);
    assert(imports() == 2);
    peer = begin(&mqtt, "usb\nflat.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker();
    mqtt.machine_status = 2;
    usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 409 && imports() == 2);
    struct stat kept; assert(!stat(kept_copy, &kept) && kept.st_size == 18);
    assert(!unlink(kept_copy) && !unlink("gcode/" GCODE_USB_IMPORT_PREFIX "kept"));
    mqtt.machine_status = 1;

    /* The start request cannot be sent after the copy was published: the copy is removed again and its layer map goes
     * with it (a map of the copy can exist by then: a layer request queued it and the builder ran in between). */
    mock_start_result = -1;
    peer = begin(&mqtt, "usb\nflat.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker();
    char failed_map[PATH_MAX_LOCAL * 3];
    {   DIR *dir = opendir("gcode"); assert(dir); struct dirent *entry; char copy_path[PATH_MAX_LOCAL * 2] = "";
        while ((entry = readdir(dir))) if (!strncmp(entry->d_name, GCODE_USB_IMPORT_PREFIX, 8))
            snprintf(copy_path, sizeof(copy_path), "gcode/%s", entry->d_name);
        closedir(dir); assert(copy_path[0]);
        size_t length = strlen(copy_path);
        if (length > 5 && !strcmp(copy_path + length - 5, ".part")) copy_path[length - 5] = 0; /* published at the tick */
        assert(layer_store_index_path(copy_path, failed_map, sizeof(failed_map)) == 0);
        write_file(failed_map, "x"); }
    usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 503 && imports() == 0 && !usb_start_active());
    assert(access(failed_map, F_OK) != 0); /* the copy and its layer map are both gone */
    mock_start_result = 0;

    /* A start the scan refuses is answered without copying the file. */
    peer = begin(&mqtt, "usb\nflat.gcode\n\nA\nadaptive\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker(); usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 409 && strstr(response, "leveling mode"));
    assert(!events[0] && imports() == 0);
    peer = begin(&mqtt, "usb\ntwo.gcode\n0:1\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker(); usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 409 && strstr(response, "Canvas mapping"));
    assert(!events[0] && imports() == 0);
    /* A start with a mapping is judged with the Canvas trays: the printer has reported them before the start. */
    canvas_reports(&mqtt);
    peer = begin(&mqtt, "usb\ntwo.gcode\n0:1,1:3\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker(); settle(&mqtt, 1);
    assert(answer(peer, response, sizeof(response)) == 202 && !strcmp(events, "1020:local:2;"));
    snprintf(copy, sizeof(copy), "gcode/%s", started_name); assert(!unlink(copy));
    /* A start with a mapping while the Canvas never reports (behaviour change against #347, where it went out at
     * once): refused after the wait with its own message, before anything is copied. */
    mqtt.canvas_snapshot_len = 0; usb_start_canvas_wait_ms = 50;
    peer = begin(&mqtt, "usb\ntwo.gcode\n0:1,1:3\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); settle(&mqtt, 0); /* the worker waits for the report before copying: only ticks end it */
    assert(answer(peer, response, sizeof(response)) == 409 && strstr(response, "did not report its trays when the start began"));
    assert(!events[0] && imports() == 0);
    usb_start_canvas_wait_ms = USB_START_CANVAS_WAIT_MS;

    /* Refusals that need no file access are answered at once, without the worker. */
    mqtt.machine_status = 2;
    assert(begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status) < 0);
    assert(status == 409 && !usb_start_active());
    mqtt.machine_status = 1; mqtt.registered = 0;
    assert(begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status) < 0);
    assert(status == 503 && strstr(response, "MQTT"));
    mqtt.registered = 1;
    assert(begin(&mqtt, "usb\nmissing.gcode\n\nA\nsaved\n0", response, sizeof(response), &status) < 0);
    assert(status == 404 && !usb_start_active());
    assert(begin(&mqtt, "usb\ncube.gcode\n\nA\nsideways\n0", response, sizeof(response), &status) < 0);
    assert(status == 400);

    /* The stick was pulled after the copy: refused like a missing file, and the copy is removed. */
    write_file("usb/gone.gcode", "G28\n");
    peer = begin(&mqtt, "usb\ngone.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker();
    assert(!unlink("usb/gone.gcode"));
    usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 404 && !events[0] && imports() == 0);

    /* #347 review: the browser gives up (timeout, closed tab) while a slow copy runs. The start
     * is cancelled and never dispatched, and a retry cannot add a second print. */
    assert(!pipe(gate));
    usb_start_copy_hook = hold_copy;
    peer = begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_held();
    close(peer);
    usb_start_tick(&mqtt);                       /* noticed while the copy is still held */
    assert(usb_start_active() && usb_start_cancelled == 1 && !atomic_load(&usb_start_done));
    assert(begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status) < 0);
    assert(status == 409 && strstr(response, "still being copied"));
    release_copy(); wait_worker(); usb_start_tick(&mqtt);
    assert(!usb_start_active() && starts_sent() == 0 && imports() == 0);
    usb_start_copy_hook = NULL;
    peer = begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
    assert(peer >= 0); wait_worker(); usb_start_tick(&mqtt);
    assert(answer(peer, response, sizeof(response)) == 202 && starts_sent() == 1 && imports() == 1);
    snprintf(copy, sizeof(copy), "gcode/%s", started_name); assert(!unlink(copy));
    usb_start_tick(&mqtt);
    assert(starts_sent() == 1);

    /* The emergency stop answers at once during a large import, and the pending start is dropped. */
    console_state console; console_init(&console, "/tmp/unused");
    for (int i = 0; i < 2; i++) {
        usb_start_copy_hook = hold_copy;
        peer = begin(&mqtt, "usb\ncube.gcode\n\nA\nsaved\n0", response, sizeof(response), &status);
        assert(peer >= 0); wait_held();
        int pair[2]; assert(!socketpair(AF_UNIX, SOCK_STREAM, 0, pair));
        if (i == 0) control_response(pair[0], &console, &mqtt, "system:emergency_stop", 21);
        else console_command_response(pair[0], &console, &mqtt, "M112", 4);
        close(pair[0]);
        /* Answered while the copy is still held: the stop does not wait for the import. */
        assert(answer(pair[1], response, sizeof(response)) == 202 && !atomic_load(&usb_start_done));
        assert(emergency_stops == i + 1 && usb_start_cancelled == 2);
        release_copy(); wait_worker(); usb_start_tick(&mqtt);
        assert(answer(peer, response, sizeof(response)) == 409 && strstr(response, "emergency stop"));
        assert(!usb_start_active() && !events[0] && imports() == 0);
    }
    usb_start_copy_hook = NULL;
    console_destroy(&console);
    close(gate[0]); close(gate[1]);

    puts("PASS USB print start: copy on a worker, start from the main loop, refusals clean up, "
         "client disconnect and emergency stop cancel an undispatched start");
    return 0;
}
