#define main cc2_main_original
#include "../src/main.c"
#undef main
#include <assert.h>
#include <sys/socket.h>

static void expect(int condition,const char *msg){if(!condition){fprintf(stderr,"FAIL %s\n",msg);exit(1);}fprintf(stdout,"PASS %s\n",msg);}
static int run_delete(mqtt_client *mqtt,const char *body,const char *auth){
    int pair[2];expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create delete socket");
    (void)auth;char request[512];snprintf(request,sizeof(request),"POST /api/gcode-files/delete HTTP/1.1\r\n\r\n");
    gcode_delete_response(pair[0],request,mqtt,body,strlen(body));
    char response[600];ssize_t size=recv(pair[1],response,sizeof(response)-1,0);
    expect(size>0,"receive delete response");response[size]=0;
    close(pair[0]);close(pair[1]);
    return atoi(strchr(response,' ')+1);
}
static int run_upload(mqtt_client *mqtt,const char *name,const char *storage,const char *content,const char *auth){
    int pair[2];expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create upload socket");
    (void)auth;char req[1024];int len=snprintf(req,sizeof(req),"POST /api/gcode-files/upload?storage=%s&name=%s HTTP/1.1\r\nHost: test\r\nContent-Length: %zu\r\n\r\n%s",storage,name,strlen(content),content);
    size_t header=(size_t)(strstr(req,"\r\n\r\n")-req)+4;
    char query[512];snprintf(query,sizeof(query),"storage=%s&name=%s",storage,name);
    int owned=gcode_upload_start(pair[0],req,query,(size_t)len,header,mqtt);
    char response[600];ssize_t size=recv(pair[1],response,sizeof(response)-1,0);
    expect(size>0,"receive upload response");response[size]=0;
    if(!owned)close(pair[0]);
    close(pair[1]);
    return atoi(strchr(response,' ')+1);
}
/* A browser sends the headers first and the body after them. A rejected
 * upload must read that body before answering: closing with unread input
 * resets the connection, and the browser shows a network error instead. */
static void test_rejected_upload_drains_body(mqtt_client *mqtt){
    enum{BODY=1024*1024};
    static char body[BODY];memset(body,'G',sizeof(body));
    int pair[2];expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create drained upload socket");
    struct timeval timeout={10,0};
    setsockopt(pair[1],SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    setsockopt(pair[1],SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    char req[256];int len=snprintf(req,sizeof(req),"POST /api/gcode-files/upload?storage=internal&name=cube.gcode HTTP/1.1\r\nHost: test\r\nContent-Length: %d\r\n\r\n",BODY);
    expect(gcode_upload_start(pair[0],req,"storage=internal&name=cube.gcode",(size_t)len,(size_t)len,mqtt),"duplicate upload handed to worker");
    size_t sent=0;
    while(sent<sizeof(body)){ssize_t n=send(pair[1],body+sent,sizeof(body)-sent,MSG_NOSIGNAL);if(n<=0)break;sent+=(size_t)n;}
    expect(sent==sizeof(body),"server reads the whole rejected body");
    char response[600];size_t used=0;ssize_t size;
    while(used<sizeof(response)-1 && (size=recv(pair[1],response+used,sizeof(response)-1-used,0))>0)used+=(size_t)size;
    expect(used>0,"receive drained upload response");response[used]=0;
    expect(strstr(response,"409 Conflict")&&strstr(response,"File already exists"),"duplicate reported after the body");
    close(pair[1]);
}
static void test_upload_size_limit(mqtt_client *mqtt){
    const size_t limit=512UL*1024UL*1024UL;
    expect(FILE_UPLOAD_MAX==limit,"upload limit is 512 MiB");
    int pair[2];expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create oversized upload socket");
    char request[512];int n=snprintf(request,sizeof(request),
        "POST /api/gcode-files/upload?storage=internal&name=large.gcode HTTP/1.1\r\nContent-Length: %zu\r\n\r\n",limit+1);
    expect(!gcode_upload_start(pair[0],request,"storage=internal&name=large.gcode",(size_t)n,(size_t)n,mqtt),"oversized raw upload rejected before worker starts");
    char response[512];ssize_t got=recv(pair[1],response,sizeof(response)-1,0);expect(got>0,"receive size rejection");response[got]=0;
    expect(strstr(response,"413 Payload Too Large")&&strstr(response,"maximum 512 MiB"),"raw upload reports updated maximum");
    close(pair[0]);close(pair[1]);
    expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create oversized multipart socket");
    n=snprintf(request,sizeof(request),"POST /api/files/local HTTP/1.1\r\nContent-Type: multipart/form-data; boundary=test\r\nContent-Length: %zu\r\n\r\n",limit+8193);
    expect(!orca_upload_start(pair[0],request,(size_t)n,(size_t)n,mqtt),"oversized multipart body rejected before worker starts");
    got=recv(pair[1],response,sizeof(response)-1,0);expect(got>0,"receive multipart size rejection");response[got]=0;
    expect(strstr(response,"413 Payload Too Large")!=NULL,"multipart overhead remains bounded");
    close(pair[0]);close(pair[1]);
}
/* Admit a realistic large body from headers without allocating or sending it.
 * EOF must abort the streaming worker and remove the incomplete target. */
static void test_large_upload_admission(mqtt_client *mqtt){
    expect(UPLOAD_CHUNK==16384,"large uploads retain 16 KiB buffer");
    expect(UPLOAD_TOTAL_SECONDS==1800,"large uploads have bounded 30 minute deadline");
    int pair[2];expect(socketpair(AF_UNIX,SOCK_STREAM,0,pair)==0,"create large admission socket");
    struct timeval timeout={10,0};setsockopt(pair[1],SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    char request[512];int n=snprintf(request,sizeof(request),
        "POST /api/gcode-files/upload?storage=internal&name=large.gcode HTTP/1.1\r\nContent-Length: %zu\r\n\r\n",450UL*1024UL*1024UL);
    shutdown(pair[1],SHUT_WR);
    expect(gcode_upload_start(pair[0],request,"storage=internal&name=large.gcode",(size_t)n,(size_t)n,mqtt),"450 MiB raw body admitted by streaming worker");
    char response[1024];size_t used=0;ssize_t got;
    while(used<sizeof(response)-1 && (got=recv(pair[1],response+used,sizeof(response)-1-used,0))>0)used+=(size_t)got;
    response[used]=0;close(pair[1]);
    expect(used>0 && !strstr(response,"413 Payload Too Large") && !strstr(response,"201 Created"),"incomplete large upload fails without a false size refusal or success");
    char path[1024];snprintf(path,sizeof(path),"%s/large.gcode",gcode_internal_root);
    expect(access(path,F_OK)!=0,"incomplete large upload never finalized");
    const struct timespec pause={0,10000000};
    for(int i=0;i<100 && atomic_load(&upload_busy);i++)nanosleep(&pause,NULL);
    expect(!atomic_load(&upload_busy),"large upload releases worker slot");
}
static void test_busy_deletion(mqtt_client *mqtt, const char *root) {
    char path[1024], alias[1024];
    expect(run_upload(mqtt,"unused.gcode","internal","G1 X1\n","")==201,"prepare unused file");
    uds_init(&telemetry); telemetry.fd=1; telemetry.ready=1;
    clock_gettime(CLOCK_MONOTONIC,&telemetry.last_rx);
    telemetry.have_print_state=telemetry.have_filename=1;
    strcpy(telemetry.print_state,"printing"); strcpy(telemetry.filename,"local/cube.gcode");
    mqtt->machine_status=2; strcpy(mqtt->print_state,"printing"); strcpy(mqtt->filename,"cube.gcode");
    expect(run_delete(mqtt,"internal\ncube.gcode","")==409,"active print cannot be deleted");
    expect(run_delete(mqtt,"internal\nunused.gcode","")==200,"unused file can be deleted while printing");
    expect(gcode_delete_guard(mqtt,"sub/CUBE.GCODE")!=NULL,"basename and FAT case aliases protected");
    strcpy(telemetry.filename,"local/CC2_USB_imported.gcode");
    expect(gcode_delete_guard(mqtt,"cube.gcode")!=NULL,"MQTT source protected beside native USB import");
    expect(gcode_delete_guard(mqtt,"CC2_USB_imported.gcode")!=NULL,"native USB import protected");
    strcpy(telemetry.filename,"local/cube.gcode");
    strcpy(telemetry.print_state,"paused"); strcpy(mqtt->print_state,"paused");
    expect(gcode_delete_guard(mqtt,"cube.gcode")!=NULL,"paused job protected");
    expect(gcode_delete_guard(mqtt,"other.gcode")==NULL,"unused file allowed while paused");
    mqtt->machine_status=1; strcpy(telemetry.print_state,"error"); strcpy(mqtt->print_state,"error");
    expect(gcode_delete_guard(mqtt,"cube.gcode")!=NULL,"errored recoverable job protected");
    mqtt->machine_status=2; strcpy(telemetry.print_state,"printing"); strcpy(mqtt->print_state,"printing");
    telemetry.last_rx.tv_sec-=10;
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"stale native status blocks busy deletion");
    clock_gettime(CLOCK_MONOTONIC,&telemetry.last_rx); telemetry.filename[0]=0;
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"missing native filename blocks busy deletion");
    strcpy(telemetry.filename,"local/cube.gcode"); mqtt->last_message=time(NULL)-60;
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"stale MQTT blocks deletion");
    mqtt->last_message=time(NULL)+60;
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"future MQTT timestamp blocks deletion");
    mqtt->last_message=time(NULL); strcpy(telemetry.print_state,"standby");
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"conflicting job states block deletion");
    mqtt->print_state[0]=0; mqtt->machine_status=10;
    expect(gcode_delete_guard(mqtt,"other.gcode")==NULL,"unused files allowed during homing with fresh native standby");
    mqtt->machine_status=15;
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"power-loss recovery is guarded");
    mqtt->machine_status=1; strcpy(orca_pending_filename,"cube.gcode");
    expect(gcode_delete_guard(mqtt,"cube.gcode")!=NULL,"pending Orca start protected");
    orca_pending_filename[0]=0;
    atomic_store(&upload_busy,1);
    expect(gcode_delete_guard(mqtt,"other.gcode")!=NULL,"in-flight upload blocks deletion before pending job publication");
    atomic_store(&upload_busy,0);
    snprintf(path,sizeof(path),"%s/cube.gcode",root); snprintf(alias,sizeof(alias),"%s/alias.gcode",root);
    expect(link(path,alias)==0,"prepare hard-link alias");
    expect(run_delete(mqtt,"internal\nalias.gcode","")==409,"hard-link restrictions remain"); unlink(alias);
    expect(symlink(path,alias)==0,"prepare symlink alias");
    expect(run_delete(mqtt,"internal\nalias.gcode","")==404,"symlink restrictions remain"); unlink(alias);
    expect(access(path,F_OK)==0,"active file remains intact");
    telemetry.fd=-1; telemetry.ready=0; mqtt->filename[0]=mqtt->print_state[0]=0;
}

int main(void){
    char root[]="/tmp/cc2-file-manager-test-XXXXXX";expect(mkdtemp(root)!=NULL,"create test directory");
    gcode_internal_root=root;gcode_usb_root="/tmp/cc2-usb-not-mounted";
    mqtt_client mqtt;memset(&mqtt,0,sizeof(mqtt));strcpy(mqtt.password,"test-code");
    mqtt.connected=mqtt.registered=mqtt.have_machine_status=1;
    mqtt.machine_status=1;mqtt.last_message=time(NULL);
    test_upload_size_limit(&mqtt);
    test_large_upload_admission(&mqtt);
    expect(run_upload(&mqtt,"cube.gcode","internal","; cube test\n","test-code")==201,"upload into internal memory");
    expect(run_upload(&mqtt,"barca%201.gcode","internal","; spaced name\n","test-code")==201,"upload URL-encoded filename with spaces");
    char path[1024];snprintf(path,sizeof(path),"%s/cube.gcode",root);
    struct stat statbuf;expect(stat(path,&statbuf)==0&&statbuf.st_size==12,"uploaded file finalized");
    expect(run_upload(&mqtt,"cube.gcode","internal","duplicate","test-code")==409,"reject duplicate without overwrite");
    test_rejected_upload_drains_body(&mqtt);
    expect(stat(path,&statbuf)==0&&statbuf.st_size==12,"duplicate left the original intact");
    expect(run_upload(&mqtt,"no-code.gcode","internal","no-auth","")==201,"upload without access code");
    expect(run_upload(&mqtt,"..%2Fetc.gcode","internal","bad-path","test-code")==400,"reject URL-encoded slash");
    expect(run_upload(&mqtt,"new.gcode","usb","test","test-code")==400,"reject unavailable USB");
    mqtt.machine_status=2;
    expect(run_upload(&mqtt,"new.gcode","internal","test","test-code")==201,"allow upload during print");
    expect(run_delete(&mqtt,"internal\ncube.gcode","test-code")==409,"reject delete during print");
    expect(run_upload(&mqtt,"cube.gcode","internal","replacement","test-code")==409,"reject overwrite during print");
    mqtt.last_message=time(NULL)-60;
    expect(run_upload(&mqtt,"stale.gcode","internal","test","test-code")==409,"reject stale telemetry");
    mqtt.last_message=time(NULL);mqtt.connected=0;
    expect(run_upload(&mqtt,"offline.gcode","internal","test","test-code")==409,"reject disconnected upload");
    mqtt.connected=1;mqtt.machine_status=10;
    expect(run_upload(&mqtt,"active.gcode","internal","test","test-code")==409,"reject other active states");
    mqtt.machine_status=1;
    test_busy_deletion(&mqtt,root);
    expect(run_delete(&mqtt,"internal\nno-code.gcode","")==200,"delete without access code");
    expect(run_delete(&mqtt,"internal\nbarca 1.gcode","")==200,"delete filename with spaces");
    expect(run_delete(&mqtt,"internal\n../cube.gcode","test-code")==404,"reject path traversal delete");
    expect(run_delete(&mqtt,"internal\ncube.gcode","test-code")==200,"delete internal G-code");
    expect(stat(path,&statbuf)<0&&errno==ENOENT,"deleted file absent");
    /* /dev/shm is a separate tmpfs mount in this test container: exercise the
       USB mount check on a real mount without touching any user files. */
    gcode_usb_root="/dev/shm";
    struct stat shm_stat,dev_stat;
    if(stat("/dev/shm",&shm_stat)==0&&stat("/dev",&dev_stat)==0&&shm_stat.st_dev!=dev_stat.st_dev){
    expect(run_upload(&mqtt,"cc2-file-manager-smoke-9f78.gcode","usb","G28\n","test-code")==201,"upload to mounted USB-style filesystem");
    expect(run_delete(&mqtt,"usb\ncc2-file-manager-smoke-9f78.gcode","test-code")==200,"delete on mounted USB-style filesystem");
    }else puts("SKIP mounted USB-style test: /dev/shm not separately mounted");
    snprintf(path,sizeof(path),"%s/new.gcode",root);unlink(path);
    rmdir(root);puts("PASS all file mutation tests");return 0;
}
