"""Exercise the real event loop against a local fake UDS peer."""
import json
import os
import shlex
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

binary = Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="cc2-uds-api-") as temporary:
    root = Path(temporary)
    path = str(root / "peer.sock")
    try:
        listener = socket.socket(socket.AF_UNIX)
    except PermissionError:
        print("SKIP UDS peer integration: environment prohibits AF_UNIX sockets")
        sys.exit(0)
    listener.bind(path)
    listener.listen(1)
    listener.settimeout(10)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    process = subprocess.Popen([
        *shlex.split(os.environ.get("CC2_TEST_RUNNER", "")), str(binary),
        "--port", str(port), "--panda-port", "0", "--uds-socket", path,
        "--config", str(root / "missing.conf"),
        "--preferences", str(root / "preferences.json"),
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    peer = None
    def get(route):
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{route}", timeout=3) as reply:
            return json.load(reply)
    def wait_for(route, predicate):
        for _ in range(80):
            try:
                value = get(route)
                if predicate(value):
                    return value
            except (OSError, ValueError):
                pass
            time.sleep(0.05)
        raise AssertionError(f"Timed out: {route}")
    def send(message):
        peer.sendall(json.dumps(message).encode() + b"\x03")
    try:
        peer, _ = listener.accept()
        peer.settimeout(3)
        request = b""
        while b"\x03" not in request:
            request += peer.recv(4096)
        subscription = json.loads(request.split(b"\x03")[0])
        assert subscription["method"] == "objects/subscribe"
        assert "gcode/script" not in request.decode()
        # Spool tracking charges filament_used to the Canvas channel reported in the same stream.
        objects = subscription["params"]["objects"]
        assert objects["canvas_dev"] == ["active_cid"] and {"state", "filament_used"} <= set(objects["print_stats"])
        assert "pressure_advance" in objects["extruder"], "PA uses the existing native subscription"
        send({"id": 11, "result": {"eventtime": 1, "status": {
            "extruder": {"temperature": 210, "target": 215},
            "fan": {"speed": 0.6, "rpm": 8700},
            "gcode_move": {"speed_factor": 0.8, "extrude_factor": 0.95},
        }}})
        value = wait_for("/api/uds", lambda x: x["fresh"])
        assert value["values"]["speed_factor"] == 0.8
        assert value["values"]["extrude_factor"] == 0.95
        assert value["homed_axes"] is None and value["light"] is None
        send({"method": "cc2_status", "params": {"eventtime": 1.1, "status": {
            "toolhead": {"homed_axes": "xyz"}, "output_pin led_pin": {"value": 1}
        }}})
        value = wait_for("/api/uds", lambda x: x.get("homed_axes") == "xyz")
        assert value["light"] is True
        send({"id": 0, "report": {"message": "vendor report"}})
        send({"method": "other_notification", "params": {}})
        value = wait_for("/api/uds", lambda x: x["ignored_messages"] == 2)
        assert value["connections"] == 1 and value["disconnects"] == 0
        assert value["values"]["speed_factor"] == 0.8
        printer = get("/api/printer")
        assert printer["extruder"] == {"temperature": 210, "target": 215}
        assert printer["fans"]["part"] == 153
        assert printer["tuning"] == {"speed_percent": 80, "flow_percent": 95, "live_velocity": None, "pressure_advance": None}
        send({"method": "cc2_status", "params": {"eventtime": 2, "status": {
            "extruder": {"temperature": 211, "pressure_advance": 0.04237}, "gcode_move": {"speed_factor": 1.3}
        }}})
        value = wait_for("/api/uds", lambda x: x["values"]["speed_factor"] == 1.3)
        assert value["values"]["nozzle_target"] == 215
        assert value["values"]["pressure_advance"] == 0.04237
        assert get("/api/printer")["tuning"]["pressure_advance"] == 0.04237
        assert value["values"]["canvas_channel"] is None and value["print_state"] is None
        send({"method": "cc2_status", "params": {"eventtime": 2.5, "status": {
            "canvas_dev": {"active_cid": 3}, "print_stats": {"state": "printing"}
        }}})
        value = wait_for("/api/uds", lambda x: x["values"]["canvas_channel"] == 3)
        assert value["print_state"] == "printing"
        assert value["values"]["part_rpm"] == 8700
        # elegoo_printer keeps every request it receives in memory, so a stream
        # that keeps notifying is never probed; a silent one gets one info request.
        peer.settimeout(0.1)
        try:
            while peer.recv(4096):
                pass
        except socket.timeout:
            pass
        received = b""
        for step in range(8):
            send({"method": "cc2_status", "params": {"eventtime": 3 + step, "status": {
                "extruder": {"temperature": 212 + step}
            }}})
            last_notification = time.monotonic()
            while time.monotonic() - last_notification < 0.5:
                try:
                    received += peer.recv(4096)
                except socket.timeout:
                    pass
        assert b'"method":"info"' not in received, received
        peer.settimeout(6)
        while b'"method":"info"' not in received:
            chunk = peer.recv(4096)
            assert chunk, "the client closed the stream instead of probing it"
            received += chunk
        silence = time.monotonic() - last_notification
        assert 2.9 <= silence <= 4.8, silence
        send({"id": 12, "result": {"state": "ready"}})
        value = wait_for("/api/uds", lambda x: x["fresh"])
        assert value["connections"] == 1 and value["disconnects"] == 0
        peer.close()
        peer = None
        wait_for("/api/uds", lambda x: not x["fresh"])
        value = get("/api/uds")
        assert value["homed_axes"] is None and value["light"] is None
        assert get("/api/printer")["extruder"]["temperature"] is None
        assert get("/api/printer")["tuning"]["pressure_advance"] is None
        # Accept the automatic reconnection and confirm the old cache is reset.
        peer, _ = listener.accept()
        peer.settimeout(3)
        assert b"objects/subscribe" in peer.recv(4096)
        send({"id": 11, "result": {"eventtime": 0.1, "status": {
            "extruder": {"temperature": 30}
        }}})
        value = wait_for("/api/uds", lambda x: x["fresh"])
        assert value["values"]["nozzle_temperature"] == 30
        assert value["values"]["speed_factor"] is None
        assert value["values"]["pressure_advance"] is None
        assert get("/api/printer")["tuning"]["pressure_advance"] is None
        assert value["homed_axes"] is None and value["light"] is None
        # Passive monitoring uses the SAME connection, even while print state is active.
        send({"method": "cc2_status", "params": {"eventtime": 0.2, "status": {
            "print_stats": {"state": "printing"}
        }}})
        wait_for("/api/uds", lambda x: x["print_state"] == "printing")
        def monitor(route="/api/console/monitor"):
            request = urllib.request.Request(f"http://127.0.0.1:{port}{route}", data=b"",
                headers={"X-CC2-Request": "1"}, method="POST")
            with urllib.request.urlopen(request, timeout=3) as reply:
                return json.load(reply)
        assert monitor()["frames"] == []
        report = {"method": "cc2_report", "params": {"response": 'probe: 1.234 \"quoted\" <script> & \nnext'}}
        frame = json.dumps(report).encode() + b"\x03"
        peer.sendall(frame[:17]); peer.sendall(frame[17:])
        time.sleep(0.15)
        log = monitor()
        assert len(log["frames"]) == 1 and json.loads(log["frames"][0]) == report
        assert get("/api/console")["command"] == "", "Monitoring must not run a command"
        cleared = monitor("/api/console/monitor/clear")
        assert cleared["frames"] == [] and cleared["dropped"] == 0
        peer.settimeout(0.1)
        unsolicited = b""
        try:
            while True:
                unsolicited += peer.recv(4096)
        except socket.timeout:
            pass
        assert b"gcode/script" not in unsolicited
        print("PASS UDS subscription, HTTP cache, delta preservation, silence-only probe, disconnect fallback and reconnect")
    finally:
        if peer is not None:
            peer.close()
        listener.close()
        process.terminate()
        process.wait(timeout=5)
