# CC2 Stage 2 — screws + mesh display, based on the working 1.1.17 + Panda

Adds **only** the guarded four-screw measurement action and its dashboard panel; fixes the 3D mesh X display direction. It leaves `src/main.c`, `src/mqtt.c`, `src/panda.c`, G-code/USB/Canvas print handling and the existing 2D mesh workflow unchanged. This package contains source, **not** a verified printer-ready ARM binary.

The probing coordinates X35/225 Y30/225 were copied from the 1.1.22 source. These are motion commands: inspect that they are appropriate for your particular build plate before enabling the operation. For the first live test, verify the existing small G-code print **before** trying the screw measurement; test the mesh rendering with previously saved data and without moving the printer. The measurements do not automatically adjust the bed or save configuration.

## Build on Windows + WSL

Extract to `C:\CC2_TEST_STAGE2` and run in PowerShell:

```powershell
wsl -d Ubuntu -- bash -lc "cd /mnt/c/CC2_TEST_STAGE2 && make clean && make && file dist/cc2-control/cc2-control"
```

Confirm ARM 32-bit ELF before copying. The stage-1 working package remains untouched.

## Install as isolated test

When the printer is fully idle:

```powershell
ssh root@192.168.1.103 "mkdir -p /opt/usr/cc2-stage2/web"
scp "C:\CC2_TEST_STAGE2\dist\cc2-control\cc2-control" root@192.168.1.103:/opt/usr/cc2-stage2/
scp "C:\CC2_TEST_STAGE2\dist\cc2-control\web\index.html" root@192.168.1.103:/opt/usr/cc2-stage2/web/
```

Via SSH, only after the current CC2 process has been stopped and the printer is idle:

```sh
PID=$(pidof cc2-control); [ -n "$PID" ] && kill "$PID"
sleep 2
pidof cc2-control
# If PID still exists, stop the respawning service before starting any second instance.
chmod +x /opt/usr/cc2-stage2/cc2-control
/opt/usr/cc2-stage2/cc2-control --port 8081 --panda-port 7125 \
 --web-root /opt/usr/cc2-stage2/web \
 --config /opt/usr/cc2-control/cc2-control.conf \
 --presets /opt/usr/cc2-control/material-presets.json \
 > /opt/usr/cc2-stage2/test.log 2>&1 &
readlink /proc/$(pidof cc2-control)/exe
wget -qO- http://127.0.0.1:8081/api/health
```

Open the dashboard and check Panda `/server/info`, mesh 2D/3D and a known-good print. Only afterwards, if appropriate, test the four-screw measurement with a clear build plate and direct supervision. `202 Accepted` is not proof that printing started; check actual machine status.

## Restore the verified stage 1 (printer idle)

```sh
PID=$(pidof cc2-control); [ -n "$PID" ] && kill "$PID"
sleep 2
/opt/usr/cc2-test117-panda/cc2-control --port 8081 --panda-port 7125 \
 --web-root /opt/usr/cc2-test117-panda/web \
 --config /opt/usr/cc2-control/cc2-control.conf \
 --presets /opt/usr/cc2-control/material-presets.json \
 > /opt/usr/cc2-test117-panda/test.log 2>&1 &
```
