# OrcaSlicer Upload & Print — Canvas confirmation trial

Based on CC2 Control Stage 2 + application PING + File Manager + thumbnails + Object Exclusion + camera and filename fixes. This is an experimental test build, not a release.

- POST /api/files/local with multipart `print=true` uploads to internal storage and queues a pending print; it does NOT send method 1020 itself.
- GET /api/orca/pending-print returns the queued filename and generation. The CC2 Control page polls this endpoint while visible and opens the existing Canvas selection popup for the queued file.
- Only the user's click on Start print in the Canvas popup calls the existing `/api/gcode-files/print`; Cancel clears the request. The request is also cleared after a successful HTTP submission.
- A pending request expires after 1 hour. One pending upload-and-print at a time. G-code overwrites, unsafe filenames, busy-printer uploads, and files larger than 64 MiB are rejected.
- Upload only (print=false) remains as in the prior build. The OrcaSlicer profile must point to port 8081 and the Device tab must display this CC2 Control page so the operator can confirm Canvas mapping. If the tab is closed, reopen it to see the pending request.
- The Object Exclusion panel text now wraps within the existing card; the outdated Settings footer 'Preview only' text is replaced with a true description of browser-local preferences.
- No alterations to mqtt.c, the application heartbeat, Panda bridge, Klipper control, or the existing print-start function.

## Safe first test

Compile and install under a new directory, preserving the existing working binary and web UI. Start CC2 Control only when printer is idle. From OrcaSlicer select 'Upload and Print' for a **small expendable G-code**. The file should appear in local storage, and the Canvas popup should open in the OrcaSlicer Device dashboard; verify that the printer does not start before pressing Start print. First cancel the popup and verify the printer remains idle; then use a second uniquely named test file and explicitly confirm the Canvas slot. Never test with a live print or unattended.

The file-manager operations on port 8081 are not authenticated: do not expose the port beyond trusted LAN. This version has not been ARM-compiled or tested on the user's printer.
