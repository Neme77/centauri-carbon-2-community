#include "console.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

static int append_output(console_state *state, const char *data, size_t length) {
    int truncated = 0;
    pthread_mutex_lock(&state->lock);
    size_t room = sizeof(state->output) - state->output_len - 1;
    if (length > room) { length = room; truncated = 1; }
    if (length) {
        memcpy(state->output + state->output_len, data, length);
        state->output_len += length;
        state->output[state->output_len] = '\0';
    }
    pthread_mutex_unlock(&state->lock);
    return truncated;
}

/* Responses from elegoo_printer may be split across read() calls.  Keep a
 * small rolling protocol window so the command-result marker is recognised
 * even after the user-visible output buffer has filled or the JSON token is
 * divided between packets. */
static int protocol_window_contains_result(char *window, size_t *used,
                                           const char *data, size_t length) {
    static const char marker[] = "\"id\":101";
    const size_t capacity = 511;
    if (length >= capacity) {
        data += length - capacity;
        length = capacity;
        *used = 0;
    } else if (*used + length > capacity) {
        size_t discard = *used + length - capacity;
        memmove(window, window + discard, *used - discard);
        *used -= discard;
    }
    memcpy(window + *used, data, length);
    *used += length;
    window[*used] = '\0';
    return strstr(window, marker) != NULL;
}

static int send_all_fd(int fd, const char *data, size_t length) {
    while (length) {
        ssize_t sent = send(fd, data, length, MSG_NOSIGNAL);
        if (sent < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        data += (size_t)sent;
        length -= (size_t)sent;
    }
    return 0;
}

static int json_escape_string(char *out, size_t cap, const char *in) {
    size_t used = 0;
    while (*in) {
        unsigned char c = (unsigned char)*in++;
        const char *escape = NULL;
        if (c == '"') escape = "\\\"";
        else if (c == '\\') escape = "\\\\";
        else if (c == '\n') escape = "\\n";
        else if (c == '\r') escape = "\\r";
        else if (c == '\t') escape = "\\t";
        if (escape) {
            size_t n = strlen(escape);
            if (used + n >= cap) return -1;
            memcpy(out + used, escape, n); used += n;
        } else if (c >= 32) {
            if (used + 1 >= cap) return -1;
            out[used++] = (char)c;
        }
    }
    if (used >= cap) return -1;
    out[used] = '\0';
    return 0;
}

static void finish(console_state *state, int success, const char *message) {
    if (message) append_output(state, message, strlen(message));
    pthread_mutex_lock(&state->lock);
    state->success = success;
    state->completed = 1;
    state->busy = 0;
    pthread_mutex_unlock(&state->lock);
}

/* Append what was read to the visible output (a frame end becomes a line end) and collect the current frame, so the
 * result of the line just sent is recognised: 1 result, 0 error result, -1 none yet. An error report (non-zero
 * error_code; level 3 is a resume event, not a fault) is noted in `seen->fault` even when the request itself was
 * acknowledged: a failed home or probe can be answered with a plain result. The frame being collected belongs to the
 * connection, not to a line: a read can end in the middle of a report that follows an acknowledgement, and the rest of
 * it arrives in the next read, while the next line is waited for or in the final read (staged_drain). */
typedef struct { char frame[1024]; size_t used; } staged_frame;
typedef struct { int saturated; int fault; } staged_seen;
static int staged_error_report(const char *frame) {
    const char *report = strstr(frame, "\"report\"");
    const char *key = report ? strstr(report, "\"error_code\":") : NULL;
    if (!key) return 0;
    char *end = NULL;
    double code = strtod(key + 13, &end);
    if (end == key + 13 || code == 0) return 0;
    const char *level_key = strstr(report, "\"error_level\":");
    double level = 0;
    if (level_key) { char *level_end = NULL; double v = strtod(level_key + 14, &level_end); if (level_end != level_key + 14) level = v; }
    return code == 704 || level <= 2;
}
static int staged_feed(console_state *state, staged_frame *f, const char *buffer, size_t got, staged_seen *seen) {
    int result = -1;
    size_t start = 0;
    for (size_t i = 0; i < got; ++i) {
        if ((unsigned char)buffer[i] != 0x03) {
            if (f->used + 1 < sizeof(f->frame)) f->frame[f->used++] = buffer[i];
            continue;
        }
        if (i > start) seen->saturated |= append_output(state, buffer + start, i - start);
        seen->saturated |= append_output(state, "\n", 1);
        start = i + 1;
        f->frame[f->used] = '\0';
        if (staged_error_report(f->frame)) seen->fault = 1;
        if (result < 0 && strstr(f->frame, "\"id\":101")) result = strstr(f->frame, "\"error\"") ? 0 : 1;
        f->used = 0;
    }
    if (start < got) seen->saturated |= append_output(state, buffer + start, got - start);
    return result;
}
/* The result of a line came in a read that ended inside the next frame (a report that follows the acknowledgement): wait
 * until that frame is whole before the next line is sent, so that an error report in it stops the job before more is
 * sent. The rest of a frame that has begun is on its way; a quiet connection (750 ms) or the deadline ends the wait, and
 * the frame stays in `frame` for the next read. */
static void staged_complete_frame(console_state *state, int fd, time_t deadline, staged_frame *frame, staged_seen *seen) {
    while (frame->used && time(NULL) < deadline) {
        struct pollfd pfd = {fd, POLLIN, 0};
        int ready = poll(&pfd, 1, 750);
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0) return;
        char buffer[4096];
        ssize_t got = read(fd, buffer, sizeof(buffer));
        if (got <= 0) return;
        staged_feed(state, frame, buffer, (size_t)got, seen);
    }
}
/* Send one line and wait for its result: 1 done, 0 the printer answered with an error, -1 connection lost or time over. */
static int staged_line(console_state *state, int fd, const char *line, time_t deadline, staged_frame *frame,
                       staged_seen *seen) {
    char escaped[CONSOLE_COMMAND_MAX * 2], request[CONSOLE_COMMAND_MAX * 2 + 128];
    if (json_escape_string(escaped, sizeof(escaped), line) != 0) return -1;
    int length = snprintf(request, sizeof(request),
        "{\"id\":101,\"method\":\"gcode/script\",\"params\":{\"script\":\"%s\"}}\003", escaped);
    if (length <= 0 || (size_t)length >= sizeof(request) || send_all_fd(fd, request, (size_t)length) != 0) return -1;
    while (time(NULL) < deadline) {
        struct pollfd pfd = {fd, POLLIN, 0};
        int ready = poll(&pfd, 1, 2000);
        if (ready < 0) { if (errno == EINTR) continue; return -1; }
        if (ready == 0) continue;
        char buffer[4096];
        ssize_t got = read(fd, buffer, sizeof(buffer));
        if (got <= 0) return -1;
        int result = staged_feed(state, frame, buffer, (size_t)got, seen);
        if (result >= 0) {
            staged_complete_frame(state, fd, deadline, frame, seen);
            return result;
        }
    }
    return -1;
}
/* The reports that trail the last result: read until the socket has been quiet for 750 ms. */
static void staged_drain(console_state *state, int fd, time_t deadline, staged_frame *frame, staged_seen *seen) {
    while (time(NULL) < deadline) {
        struct pollfd pfd = {fd, POLLIN, 0};
        int ready = poll(&pfd, 1, 750);
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0) return;
        char buffer[4096];
        ssize_t got = read(fd, buffer, sizeof(buffer));
        if (got <= 0) return;
        staged_feed(state, frame, buffer, (size_t)got, seen);
    }
}
/* Run `script` line by line: 1 done, 0 a printer error (the rest is not sent), 2 cancelled, -1 connection lost or time
 * over. The cancel tail (`tail`) is not stopped by a cancel and runs on past an error. */
/* A completed line that homes axes makes them known as homed for the rest of the job: G28 (all axes, or the named
 * ones) and G180 S3 (the nozzle cleaning homes first). */
static void staged_note_homing(const char *line, unsigned *homed) {
    if (!strncmp(line, "G180", 4)) { *homed |= CONSOLE_AXES_ALL; return; }
    if (strncmp(line, "G28", 3) || (line[3] && line[3] != ' ')) return;
    unsigned bits = 0;
    for (const char *p = line + 3; *p; ++p) {
        if (*p == 'X' || *p == 'x') bits |= CONSOLE_AXES_X;
        else if (*p == 'Y' || *p == 'y') bits |= CONSOLE_AXES_Y;
        else if (*p == 'Z' || *p == 'z') bits |= CONSOLE_AXES_Z;
    }
    *homed |= bits ? bits : CONSOLE_AXES_ALL;
}
static int staged_lines(console_state *state, int fd, const char *script, time_t deadline, int tail, int *sent,
                        staged_frame *frame, staged_seen *seen, unsigned *homed) {
    const char *at = script;
    while (*at) {
        const char *end = strchr(at, '\n');
        size_t n = end ? (size_t)(end - at) : strlen(at);
        char line[CONSOLE_COMMAND_MAX];
        if (n >= sizeof(line)) return -1;
        memcpy(line, at, n); line[n] = '\0';
        at += n + (end ? 1 : 0);
        if (!n) continue;
        const char *text = line;
        if (tail && !strncmp(line, CONSOLE_TAIL_IF_HOMED, 3)) {
            /* a move that needs referenced axes: not sent while they are not, nor after the printer reported an error (a
             * homing line can be acknowledged and its failure reported a read later) */
            if (*homed != CONSOLE_AXES_ALL || seen->fault) continue;
            text = line + 3;
        }
        if (!tail && atomic_load(&state->cancel_requested)) return 2;
        int result = staged_line(state, fd, text, deadline, frame, seen);
        if (sent) (*sent)++;
        if (result < 0) return -1;
        if (result == 1) staged_note_homing(text, homed);
        if (!tail && (result == 0 || seen->fault)) return 0;
    }
    return 1;
}
static void staged_run(console_state *state, int fd, const char *command) {
    char tail[CONSOLE_CANCEL_TAIL_MAX];
    pthread_mutex_lock(&state->lock);
    snprintf(tail, sizeof(tail), "%s", state->cancel_tail);
    unsigned homed = state->staged_homed;
    pthread_mutex_unlock(&state->lock);
    append_output(state, "> ", 2);
    append_output(state, command, strlen(command));
    append_output(state, "\n", 1);
    time_t deadline = time(NULL) + 900;
    int sent = 0;
    staged_seen seen = {0, 0};
    staged_frame frame = {{0}, 0};
    int result = staged_lines(state, fd, command, deadline, 0, &sent, &frame, &seen, &homed);
    if (result == 2) {
        append_output(state, "[CC2 Control: cancelled]\n", 25);
        /* Nothing sent yet: nothing to undo. */
        if (sent) result = staged_lines(state, fd, tail, time(NULL) + 120, 1, NULL, &frame, &seen, &homed) < 0 ? -1 : 2;
        if (result == 2) staged_drain(state, fd, time(NULL) + 10, &frame, &seen);
        close(fd);
        pthread_mutex_lock(&state->lock);
        state->cancelled = 1;
        pthread_mutex_unlock(&state->lock);
        finish(state, 0, result < 0 ? "Console connection ended or command timed out\n" : NULL);
        return;
    }
    if (result < 0) { close(fd); finish(state, 0, "Console connection ended or command timed out\n"); return; }
    /* A printer error (an error response, or an error report even next to an acknowledged request) is a failure, not
     * a measurement that completed: the error text is already in the output, the lines after it are not sent and no
     * motion tail follows (whether the axes are homed and the printer allows a move is not known here; the heaters are
     * switched off by the caller's deferred shutdown, control_screws_tick). Reports that trail the last result are read first,
     * so a late error text is kept too. */
    staged_drain(state, fd, deadline, &frame, &seen);
    close(fd);
    if (result == 0 || seen.fault) { finish(state, 0, "[CC2 Control: the printer reported an error; the job was stopped]\n"); return; }
    finish(state, 1, NULL);
}

static void *console_worker(void *opaque) {
    console_state *state = opaque;
    char command[CONSOLE_COMMAND_MAX], escaped[CONSOLE_COMMAND_MAX * 2];
    char request[CONSOLE_COMMAND_MAX * 2 + 128];
    char socket_path[108];
    struct sockaddr_un address;

    pthread_mutex_lock(&state->lock);
    snprintf(command, sizeof(command), "%s", state->command);
    snprintf(socket_path, sizeof(socket_path), "%s", state->socket_path);
    pthread_mutex_unlock(&state->lock);

    if (json_escape_string(escaped, sizeof(escaped), command) != 0) {
        finish(state, 0, "Command is too long after JSON encoding\n");
        return NULL;
    }

    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) { finish(state, 0, "Cannot create UDS socket\n"); return NULL; }
    memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path, sizeof(address.sun_path), "%s", socket_path);
    if (connect(fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        close(fd); finish(state, 0, "Cannot connect to elegoo_printer\n"); return NULL;
    }

    const char subscribe[] = "{\"id\":100,\"method\":\"gcode/subscribe_report\",\"params\":{}}\003";
    if (send_all_fd(fd, subscribe, sizeof(subscribe) - 1) != 0) {
        close(fd); finish(state, 0, "Cannot subscribe to console reports\n"); return NULL;
    }
    pthread_mutex_lock(&state->lock);
    int staged = state->staged;
    pthread_mutex_unlock(&state->lock);
    if (staged) { staged_run(state, fd, command); return NULL; }
    int length = snprintf(request, sizeof(request),
        "{\"id\":101,\"method\":\"gcode/script\",\"params\":{\"script\":\"%s\"}}\003", escaped);
    if (length <= 0 || (size_t)length >= sizeof(request) ||
        send_all_fd(fd, request, (size_t)length) != 0) {
        close(fd); finish(state, 0, "Cannot send command\n"); return NULL;
    }

    if (strcmp(command, "M112") == 0) atomic_store(&state->emergency_sent, 1);

    append_output(state, "> ", 2);
    append_output(state, command, strlen(command));
    append_output(state, "\n", 1);

    int saw_command_result = 0;
    int output_saturated = 0;
    char protocol_window[512] = {0};
    size_t protocol_used = 0;
    time_t deadline = time(NULL) + 900;
    while (time(NULL) < deadline) {
        struct pollfd pfd = {fd, POLLIN, 0};
        int poll_timeout = saw_command_result ? 750 : (output_saturated ? 10000 : 2000);
        int ready = poll(&pfd, 1, poll_timeout);
        if (ready < 0) { if (errno == EINTR) continue; break; }
        if (ready == 0) {
            if (saw_command_result || output_saturated) {
                close(fd);
                finish(state, 1, output_saturated && !saw_command_result ?
                    "\n[CC2 Control: console output limit reached; operation released after 10 seconds without new reports]\n" : NULL);
                return NULL;
            }
            continue;
        }
        char buffer[4096];
        ssize_t got = read(fd, buffer, sizeof(buffer));
        if (got <= 0) break;
        if (protocol_window_contains_result(protocol_window, &protocol_used,
                                            buffer, (size_t)got))
            saw_command_result = 1;
        size_t start = 0;
        for (ssize_t i = 0; i < got; ++i) {
            if ((unsigned char)buffer[i] == 0x03) {
                if ((size_t)i > start)
                    output_saturated |= append_output(state, buffer + start, (size_t)i - start);
                output_saturated |= append_output(state, "\n", 1);
                start = (size_t)i + 1;
            }
        }
        if (start < (size_t)got)
            output_saturated |= append_output(state, buffer + start, (size_t)got - start);
    }
    close(fd);
    finish(state, 0, "Console connection ended or command timed out\n");
    return NULL;
}

void console_init(console_state *state, const char *socket_path) {
    memset(state, 0, sizeof(*state));
    atomic_init(&state->emergency_sent, 0);
    atomic_init(&state->cancel_requested, 0);
    pthread_mutex_init(&state->lock, NULL);
    snprintf(state->socket_path, sizeof(state->socket_path), "%s", socket_path);
}

void console_destroy(console_state *state) { pthread_mutex_destroy(&state->lock); }

int console_clear(console_state *state) {
    pthread_mutex_lock(&state->lock);
    if (state->busy) { pthread_mutex_unlock(&state->lock); return -1; }
    state->command[0]='\0'; state->output[0]='\0'; state->output_len=0;
    state->completed=0; state->success=0; state->generation++;
    pthread_mutex_unlock(&state->lock);
    return 0;
}

static void first_word(char *out, size_t cap, const char *command) {
    while (isspace((unsigned char)*command)) command++;
    size_t used = 0;
    while (*command && !isspace((unsigned char)*command) && *command != ';' && used + 1 < cap)
        out[used++] = (char)toupper((unsigned char)*command++);
    out[used] = '\0';
}

static int has_full_homing(const mqtt_client *mqtt) {
    if (!mqtt) return 0;
    return strchr(mqtt->homed_axes, 'x') && strchr(mqtt->homed_axes, 'y') && strchr(mqtt->homed_axes, 'z');
}

static int is_prehome_nonmotion(const char *word) {
    static const char *commands[] = {
        "HELP","STATUS","GET_POSITION","M105","M114","M115",
        "QUERY_PROBE","QUERY_ENDSTOPS","QUERY_FILAMENT_SENSOR","DUMP_TMC",
        "ACCELEROMETER_QUERY","LOAD_CELL_READ","LOAD_CELL_DIAGNOSTIC",
        "BED_MESH_OUTPUT","G90","G91","M82","M83",
        "SET_HEATER_TEMPERATURE","TURN_OFF_HEATERS","M104","M109","M140","M190",
        "M106","M107","SET_FAN_SPEED","SET_CAVITY_FAN",
        /* Native Canvas mode/material setters update data only; load/unload
         * and other Canvas commands retain the homing requirement. */
        "USED_CANVAS_DEV","CANVAS_SET_FILAMENT_INFO"
    };
    for (size_t i = 0; i < sizeof(commands)/sizeof(commands[0]); ++i)
        if (strcmp(word, commands[i]) == 0) return 1;
    return 0;
}

static int is_kinematic_bypass(const char *word) {
    static const char *blocked[] = {
        "FORCE_MOVE", "SET_KINEMATIC_POSITION", "MANUAL_STEPPER", "STEPPER_BUZZ",
        "SET_STEPPER_ENABLE", "M18", "M84", "G92"
    };
    for (size_t i = 0; i < sizeof(blocked)/sizeof(blocked[0]); ++i)
        if (strcmp(word, blocked[i]) == 0) return 1;
    return 0;
}

static int parse_axis_value(const char *command, char axis, double *value) {
    const char *p = command;
    while (*p && !isspace((unsigned char)*p)) p++; /* skip G0/G1 token */
    while (*p) {
        if (*p == ';') break;
        if (toupper((unsigned char)*p) == axis) {
            char *end = NULL;
            double v = strtod(p + 1, &end);
            if (end == p + 1) return -1;
            *value = v;
            return 1;
        }
        p++;
    }
    return 0;
}

static int direct_move_safe(console_state *state, const char *command, const mqtt_client *mqtt,
                            char *reason, size_t reason_cap) {
    if (!mqtt->have_position) {
        snprintf(reason, reason_cap, "Current position is unavailable; movement rejected");
        return 0;
    }
    if (!has_full_homing(mqtt)) {
        snprintf(reason, reason_cap, "Home X, Y and Z before manual movement");
        return 0;
    }

    int relative;
    pthread_mutex_lock(&state->lock);
    relative = state->relative_xyz;
    pthread_mutex_unlock(&state->lock);

    const char axes[] = {'X','Y','Z'};
    const double current[] = {mqtt->x, mqtt->y, mqtt->z};
    const double minimum[] = {0.0, 0.0, -2.0};
    const double maximum[] = {256.0, 266.0, 256.0};
    int any_xyz = 0;
    for (size_t i = 0; i < 3; ++i) {
        double requested = 0.0;
        int found = parse_axis_value(command, axes[i], &requested);
        if (found < 0) {
            snprintf(reason, reason_cap, "Invalid %c coordinate", axes[i]);
            return 0;
        }
        if (!found) continue;
        any_xyz = 1;
        double target = relative ? current[i] + requested : requested;
        if (target < minimum[i] - 0.0001 || target > maximum[i] + 0.0001) {
            snprintf(reason, reason_cap,
                     "%c target %.3f is outside the protected range %.3f..%.3f",
                     axes[i], target, minimum[i], maximum[i]);
            return 0;
        }
    }
    /* E-only G0/G1 is still a manual move. Full homing above is intentionally
       required, but there is no XYZ target to range-check here. */
    (void)any_xyz;
    return 1;
}

static int console_idle_safe(const mqtt_client *mqtt, char *reason, size_t reason_cap) {
    if (!mqtt || !mqtt->connected || !mqtt->registered) {
        snprintf(reason, reason_cap, "Printer MQTT is not ready");
        return 0;
    }
    if (!mqtt->have_machine_status) {
        snprintf(reason, reason_cap, "Printer state is unavailable");
        return 0;
    }
    if (mqtt->last_message > 0 && time(NULL) - mqtt->last_message > 20) {
        snprintf(reason, reason_cap, "Printer telemetry is stale");
        return 0;
    }
    if (mqtt->machine_status == 2) {
        snprintf(reason, reason_cap, "Manual console is blocked while printing");
        return 0;
    }
    if (mqtt->machine_status != 1) {
        snprintf(reason, reason_cap, "Manual console requires the printer to be idle (machine_status=%d)", mqtt->machine_status);
        return 0;
    }
    return 1;
}

int console_command_allowed(console_state *state, const char *command, const mqtt_client *mqtt,
                            char *reason, size_t reason_cap) {
    char word[80];
    first_word(word, sizeof(word), command);
    if (!word[0] || strchr(command, '\n') || strchr(command, '\r')) {
        snprintf(reason, reason_cap, "Only one command at a time is allowed");
        return 0;
    }
    if (!console_idle_safe(mqtt, reason, reason_cap)) {
        return 0;
    }
    if (is_kinematic_bypass(word)) {
        snprintf(reason, reason_cap, "Command is blocked because it can bypass homing or motion limits");
        return 0;
    }
    if (strcmp(word, "G28") == 0) return 1;
    if (strcmp(word, "G0") == 0 || strcmp(word, "G00") == 0 ||
        strcmp(word, "G1") == 0 || strcmp(word, "G01") == 0)
        return direct_move_safe(state, command, mqtt, reason, reason_cap);

    if (!has_full_homing(mqtt) && !is_prehome_nonmotion(word)) {
        snprintf(reason, reason_cap,
                 "Home X, Y and Z before commands that may move the printer");
        return 0;
    }

    /* Once homed, behave like a normal Klipper console: pass supported
       commands/macros through to Klipper. Klipper remains the final authority
       for command validity and kinematic limits. */
    if (strcmp(word, "G90") == 0 || strcmp(word, "G91") == 0) {
        pthread_mutex_lock(&state->lock);
        state->relative_xyz = strcmp(word, "G91") == 0;
        pthread_mutex_unlock(&state->lock);
    }
    return 1;
}

/* One deadline covers connection, transmission and the complete reply. These
 * sockets must never stall the HTTP thread when the firmware accept queue is full. */
static long long emergency_now_ms(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return -1;
    return (long long)now.tv_sec * 1000 + now.tv_nsec / 1000000;
}

static int emergency_wait(int fd, short events, long long deadline) {
    for (;;) {
        long long now = emergency_now_ms();
        if (now < 0 || now >= deadline) return -1;
        struct pollfd pfd = {fd, events, 0};
        int ready = poll(&pfd, 1, (int)(deadline - now));
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0 || (pfd.revents & POLLNVAL)) return -1;
        /* HUP/ERR also wake the nonblocking read/send to report EOF or failure. */
        return 0;
    }
}

/* Preserve Noahwhite2014's direct firmware endpoint and its independent console
 * connection. Return failure on a refused, incomplete or oversized response so
 * the existing caller can attempt its M112 fallback. A clean close with no reply
 * still counts as sent: firmware shutdown can close the socket immediately. */
int console_emergency_stop(console_state *state, char *reason, size_t reason_cap) {
    static const char request[] = "{\"id\":112,\"method\":\"emergency_stop\",\"params\":{}}\003";
    const char *failure = "Cannot connect to elegoo_printer";
    long long started = emergency_now_ms();
    if (started < 0) { snprintf(reason, reason_cap, "Cannot read emergency stop clock"); return -1; }
    long long deadline = started + 2000;
    char socket_path[108];
    pthread_mutex_lock(&state->lock);
    snprintf(socket_path, sizeof(socket_path), "%s", state->socket_path);
    pthread_mutex_unlock(&state->lock);
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) { snprintf(reason, reason_cap, "Cannot create UDS socket"); return -1; }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0 ||
        fcntl(fd, F_SETFD, FD_CLOEXEC) < 0) goto failed;
    struct sockaddr_un address;
    memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path, sizeof(address.sun_path), "%s", socket_path);
    if (connect(fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        /* AF_UNIX reports a saturated accept queue as EAGAIN. No pending
         * connection exists in that case; fail promptly rather than polling it. */
        if (errno != EINPROGRESS) goto failed;
        if (emergency_wait(fd, POLLOUT, deadline) != 0) goto failed;
        int error = 0;
        socklen_t length = sizeof(error);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &length) < 0 || error) goto failed;
    }
    failure = "Cannot send the emergency stop";
    size_t sent = 0;
    while (sent < sizeof(request) - 1) {
        long long now = emergency_now_ms();
        if (now < 0 || now >= deadline) goto failed;
        ssize_t n = send(fd, request + sent, sizeof(request) - 1 - sent, MSG_NOSIGNAL);
        if (n > 0) { sent += (size_t)n; continue; }
        if (n < 0 && errno == EINTR) continue;
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) &&
            emergency_wait(fd, POLLOUT, deadline) == 0) continue;
        goto failed;
    }
    atomic_store(&state->emergency_sent, 1);
    char reply[8192];
    size_t used = 0;
    failure = "Incomplete emergency stop response";
    for (;;) {
        if (emergency_wait(fd, POLLIN, deadline) != 0) goto failed;
        ssize_t got = read(fd, reply + used, sizeof(reply) - 1 - used);
        if (got == 0 && used == 0) { close(fd); return 0; }
        if (got < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        if (got <= 0) goto failed;
        used += (size_t)got;
        reply[used] = '\0';
        char *end = memchr(reply, 3, used);
        if (end) {
            *end = '\0';
            /* Conservative: any error marker in the complete firmware frame
             * requests fallback, preserving the upstream refusal behaviour. */
            if (strstr(reply, "\"error\"")) {
                failure = "The printer refused the emergency stop";
                goto failed;
            }
            if (end == reply || memchr(reply, 0, (size_t)(end - reply))) goto failed;
            close(fd);
            return 0;
        }
        if (used == sizeof(reply) - 1) {
            failure = "Emergency stop response too large";
            goto failed;
        }
    }
failed:
    close(fd);
    snprintf(reason, reason_cap, "%s", failure);
    return -1;
}


int console_start(console_state *state, const char *command, char *reason, size_t reason_cap) {
    pthread_t thread;
    pthread_mutex_lock(&state->lock);
    if (state->busy) { state->staged_next=0; state->staged_homed_next=0; pthread_mutex_unlock(&state->lock); snprintf(reason,reason_cap,"Another command is running"); return -1; }
    snprintf(state->command, sizeof(state->command), "%s", command);
    state->output[0]='\0'; state->output_len=0; state->busy=1; state->completed=0; state->success=0; state->generation++;
    state->staged=state->staged_next; state->staged_next=0; state->cancelled=0;
    state->staged_homed=state->staged_homed_next; state->staged_homed_next=0;
    snprintf(state->cancel_tail, sizeof(state->cancel_tail), "%s", state->cancel_tail_next);
    atomic_store(&state->cancel_requested, 0);
    pthread_mutex_unlock(&state->lock);
    if (pthread_create(&thread, NULL, console_worker, state) != 0) {
        finish(state, 0, "Cannot start console worker\n"); return -1;
    }
    pthread_detach(thread);
    return 0;
}

void console_arm_staged(console_state *state, const char *cancel_tail, unsigned homed) {
    pthread_mutex_lock(&state->lock);
    state->staged_next = 1;
    state->staged_homed_next = homed & CONSOLE_AXES_ALL;
    snprintf(state->cancel_tail_next, sizeof(state->cancel_tail_next), "%s", cancel_tail ? cancel_tail : "");
    pthread_mutex_unlock(&state->lock);
}

int console_cancel(console_state *state) {
    pthread_mutex_lock(&state->lock);
    int running = state->busy && state->staged;
    if (running) atomic_store(&state->cancel_requested, 1);
    pthread_mutex_unlock(&state->lock);
    return running ? 0 : -1;
}

int console_cancelled(console_state *state, unsigned long generation) {
    pthread_mutex_lock(&state->lock);
    int cancelled = state->cancelled && state->generation == generation;
    pthread_mutex_unlock(&state->lock);
    return cancelled;
}

void console_json(console_state *state, char *out, size_t capacity) {
    char escaped[CONSOLE_OUTPUT_MAX * 2];
    char escaped_command[CONSOLE_COMMAND_MAX * 2];
    pthread_mutex_lock(&state->lock);
    if (json_escape_string(escaped, sizeof(escaped), state->output) != 0) snprintf(escaped,sizeof(escaped),"Output too large");
    if (json_escape_string(escaped_command, sizeof(escaped_command), state->command) != 0) escaped_command[0]='\0';
    snprintf(out, capacity, "{\"busy\":%s,\"completed\":%s,\"success\":%s,\"generation\":%lu,\"cancellable\":%s,\"cancelling\":%s,\"cancelled\":%s,\"command\":\"%s\",\"output\":\"%s\"}\n",
        state->busy?"true":"false",state->completed?"true":"false",state->success?"true":"false",state->generation,
        state->busy&&state->staged?"true":"false",state->busy&&atomic_load(&state->cancel_requested)?"true":"false",
        state->cancelled?"true":"false",escaped_command,escaped);
    pthread_mutex_unlock(&state->lock);
}
