#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdatomic.h>
#include <poll.h>
#include <stdint.h>
#include <sys/file.h>
#include <sys/statvfs.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <limits.h>
#include <math.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

#include "mqtt.h"
#include "panda.h"
#include "console.h"
#include "control.h"
#include "canvas_state.h"
#include "maintenance_barrier.h"
#include "uds.h"
#include "http_guard.h"
#include "experiments_state.h"
#include "external_feed_state.h"
static int app_update_active(void);
static int plates_background_active(void);
static int experiments_normal_confirmed(console_state *console);
static int drying_active(void);
static int nx_active(void);
static int drying_status_json(char *out,size_t capacity,const mqtt_client *mqtt);

static uds_client telemetry;
/* Build-plate measurement and nozzle chosen for a print (plates.h). */
static const char *plates_print_prepare(const mqtt_client *mqtt, char side, int saved_mesh, const char *measure,
                                        const char *nozzle, char *late);
static void plates_print_arm(const char *late, char side);
/* X/Y motor mode last requested through motors:quiet/normal. elegoo_printer
 * reloads the configured mode when it restarts, so the request is only
 * reported for the UDS connection it was made on. */
static const char *motor_mode_requested;
static unsigned long motor_mode_connection;
static int z_offset_pending;
static double z_offset_expected;
static int z_offset_session;
static double z_offset_reference;
static struct timespec z_offset_started;
static int z_offset_timed_out;
static void z_offset_expire(void){
    struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);
    if(z_offset_pending && now.tv_sec-z_offset_started.tv_sec>=5){
        z_offset_pending=0;z_offset_session=0;z_offset_timed_out=1;
    }
}

static int z_offset_readback(double *value){
    z_offset_expire();
    if(!uds_value(&telemetry,U_Z_OFFSET,value))return 0;
    if(z_offset_pending&&fabs(*value-z_offset_expected)<0.0005)z_offset_pending=0;
    else if(!z_offset_pending&&z_offset_session&&fabs(*value-z_offset_expected)>=0.0005)
        z_offset_session=0; /* Firmware/display/G-code changed the reference outside our controls. */
    return 1;
}

#define REQUEST_MAX 12288
#define FILE_UPLOAD_MAX (512UL * 1024UL * 1024UL)
#define UPLOAD_CHUNK 16384
#define PATH_MAX_LOCAL 512
#define GCODE_FILES_MAX 128
#define GCODE_SCAN_DEPTH_MAX 4
#define GCODE_SCAN_ENTRIES_MAX 4096
#define GCODE_JSON_CAP (192 * 1024)
#define GCODE_TOOLS_MAX 16
#define GCODE_THUMBNAIL_SCAN_MAX (4 * 1024 * 1024)
#define GCODE_THUMBNAIL_BASE64_MAX (1024 * 1024)

#define GCODE_INTERNAL_ROOT "/opt/usr/gcode/local"
#define GCODE_USB_ROOT "/mnt/exUDISK"
#define GCODE_USB_IMPORT_PREFIX "CC2_USB_"

#ifndef CC2_CONTROL_VERSION /* the Makefile sets it from VERSION */
#define CC2_CONTROL_VERSION "0.0.0-dev"
#endif
#ifndef CC2_COMMUNITY_FIRMWARE_VERSION /* the Makefile sets it from FIRMWARE_VERSION */
#define CC2_COMMUNITY_FIRMWARE_VERSION "0.0-dev"
#endif
#define CC2_DISCOVERY_API_VERSION 1

static volatile sig_atomic_t running = 1;
static volatile sig_atomic_t first_run_restart_requested = 0;
static const char *material_presets_path = "./material-presets.json";
static const char *mqtt_config_path = "./cc2-control.conf";
static const char *ui_preferences_path = "./ui-preferences.json";
static const char *plates_path = "./bed-plates.json";
static const char *spools_path = "./spools.json";
static const char *queue_path = "./print-queue.json";
static const char *printer_autosave_path = "/opt/usr/cfg/autosave.cfg";
static const char *gcode_internal_root = GCODE_INTERNAL_ROOT;
static const char *gcode_usb_root = GCODE_USB_ROOT;
static int setup_mode = 0;
static int service_http_port = 8081;
static const char *http_host_alias = NULL;
static int service_panda_port = 7125;
static const char default_material_presets[] =
    "[{\"name\":\"PLA\",\"nozzle\":200,\"bed\":60,\"min\":190,\"max\":230},"
    "{\"name\":\"PETG\",\"nozzle\":240,\"bed\":70,\"min\":220,\"max\":260},"
    "{\"name\":\"ABS\",\"nozzle\":250,\"bed\":100,\"min\":230,\"max\":280},"
    "{\"name\":\"ASA\",\"nozzle\":255,\"bed\":100,\"min\":240,\"max\":280},"
    "{\"name\":\"TPU\",\"nozzle\":220,\"bed\":50,\"min\":200,\"max\":240},"
    "{\"name\":\"PA-CF\",\"nozzle\":285,\"bed\":100,\"min\":260,\"max\":300}]\n";

static void stop_server(int signal_number) {
    (void)signal_number;
    running = 0;
}

static int send_all(int fd, const void *buffer, size_t length) {
    const char *cursor = (const char *)buffer;
    while (length > 0) {
        ssize_t sent = send(fd, cursor, length, MSG_NOSIGNAL);
        if (sent < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        cursor += sent;
        length -= (size_t)sent;
    }
    return 0;
}

/* Submit one atomic script to the printer's local Klippy socket. Calibrated
 * starts cannot use MQTT method 1020: that method is routed to
 * INTERNAL_START_PRINT and skips the preparation performed by LAN START_PRINT. */
static int send_local_gcode_script(const char *script) {
    char escaped[8192], request[8448];
    size_t used = 0;
    if (!script) return -1;
    for (const unsigned char *cursor = (const unsigned char *)script; *cursor; ++cursor) {
        unsigned char ch = *cursor;
        const char *replacement = NULL;
        if (ch == '"') replacement = "\\\"";
        else if (ch == '\\') replacement = "\\\\";
        else if (ch == '\n') replacement = "\\n";
        else if (ch == '\r') replacement = "\\r";
        else if (ch == '\t') replacement = "\\t";
        if (replacement) {
            size_t replacement_length = strlen(replacement);
            if (used + replacement_length >= sizeof(escaped)) return -1;
            memcpy(escaped + used, replacement, replacement_length);
            used += replacement_length;
        } else {
            if (ch < 32 || used + 1 >= sizeof(escaped)) return -1;
            escaped[used++] = (char)ch;
        }
    }
    escaped[used] = '\0';
    int length = snprintf(request, sizeof(request),
        "{\"id\":301,\"method\":\"gcode/script\",\"params\":{\"script\":\"%s\"}}\003",
        escaped);
    if (length <= 0 || (size_t)length >= sizeof(request)) return -1;

    int uds = socket(AF_UNIX, SOCK_STREAM, 0);
    if (uds < 0) return -1;
    struct timeval timeout = {2, 0};
    setsockopt(uds, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    struct sockaddr_un address; memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path, sizeof(address.sun_path), "%s", "/tmp/elegoo_uds");
    int result = connect(uds, (struct sockaddr *)&address, sizeof(address));
    if (result == 0) result = send_all(uds, request, (size_t)length);
    close(uds);
    return result;
}

static int saved_plate_mesh_exists(char print_layout) {
    const char *profile = print_layout == 'B' ? "default1" : "default";
    FILE *file = fopen(printer_autosave_path, "rb");
    if (!file) return 0;
    char line[256], marker[64];
    snprintf(marker, sizeof(marker), "[bed_mesh %s]", profile);
    int in_profile = 0, x_count = 0, y_count = 0, have_points = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, "[bed_mesh ")) {
            if (in_profile) break;
            in_profile = strstr(line, marker) != NULL;
            continue;
        }
        if (!in_profile) continue;
        if (strstr(line, "points =")) have_points = 1;
        const char *x = strstr(line, "x_count =");
        const char *y = strstr(line, "y_count =");
        if (x) x_count = atoi(x + strlen("x_count ="));
        if (y) y_count = atoi(y + strlen("y_count ="));
    }
    fclose(file);
    return have_points && x_count == 11 && y_count == 11;
}

static void respond(int fd, int status, const char *status_text,
                    const char *content_type, const char *body, size_t body_len) {
    char header[512];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %lu\r\n"
        "Cache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "X-Frame-Options: DENY\r\n"
        "Connection: close\r\n\r\n",
        status, status_text, content_type, (unsigned long)body_len);
    if (header_len <= 0 || (size_t)header_len >= sizeof(header)) return;
    if (send_all(fd, header, (size_t)header_len) == 0)
        (void)send_all(fd, body, body_len);
}

static long read_first_long(const char *path) {
    FILE *file = fopen(path, "r");
    long value = -1;
    if (file) {
        if (fscanf(file, "%ld", &value) != 1) value = -1;
        fclose(file);
    }
    return value;
}

static void memory_values(long *total, long *available) {
    FILE *file = fopen("/proc/meminfo", "r");
    char key[64];
    long value;
    char unit[32];
    *total = -1;
    *available = -1;
    if (!file) return;
    while (fscanf(file, "%63s %ld %31s", key, &value, unit) == 3) {
        if (strcmp(key, "MemTotal:") == 0) *total = value;
        else if (strcmp(key, "MemAvailable:") == 0) *available = value;
        if (*total >= 0 && *available >= 0) break;
    }
    fclose(file);
}

static void layer_path_health_json(char *out, size_t cap);
static void health_response(int fd, const mqtt_client *mqtt) {
    char body[1536], layer_path[512];
    layer_path_health_json(layer_path, sizeof(layer_path));
    char load[96] = "unknown";
    long uptime = read_first_long("/proc/uptime");
    long mem_total, mem_available;
    FILE *load_file = fopen("/proc/loadavg", "r");
    if (load_file) {
        if (!fgets(load, sizeof(load), load_file)) strcpy(load, "unknown");
        fclose(load_file);
        load[strcspn(load, "\r\n")] = '\0';
    }
    memory_values(&mem_total, &mem_available);
    int length = snprintf(body, sizeof(body),
        "{\"service\":\"cc2-control\",\"version\":\"" CC2_CONTROL_VERSION "\","
        "\"mode\":\"protected-control\",\"uptime_seconds\":%ld,"
        "\"mem_total_kb\":%ld,\"mem_available_kb\":%ld,"
        "\"loadavg\":\"%s\",\"mqtt_connected\":%s,\"mqtt_registered\":%s,"
        "\"snapshot_received\":%s,\"mqtt_received_publishes\":%lu,\"mqtt_skipped_requests\":%lu,\"mqtt_skipped_request_bytes\":%lu,\"mqtt_oversized_packets\":%lu,\"mqtt_oversized_snapshots\":%lu,\"mqtt_oversized_replies\":%lu,%s}\n",
        uptime, mem_total, mem_available, load, mqtt->connected ? "true" : "false",
        mqtt->registered ? "true" : "false", mqtt->snapshot_len ? "true" : "false",
        mqtt->received_publishes,mqtt->skipped_requests,mqtt->skipped_request_bytes,mqtt->oversized_packets,mqtt->oversized_snapshots,mqtt->oversized_replies,layer_path);
    if (length < 0 || (size_t)length >= sizeof(body)) return;
    respond(fd, 200, "OK", "application/json; charset=utf-8", body, (size_t)length);
}

static void json_escape(char *out,size_t cap,const char *in);

static void system_info_response(int fd, const mqtt_client *mqtt) {
    char body[3072], uuid[260];
    json_escape(uuid, sizeof(uuid), mqtt ? mqtt->uuid : "");
    int length = snprintf(body, sizeof(body),
        "{"
        "\"platform\":\"cc2-community\","
        "\"implementation\":\"Neme77/centauri-carbon-2-community\","
        "\"device\":\"ELEGOO Centauri Carbon 2\","
        "\"community_firmware\":\"%s\","
        "\"cc2_control\":\"%s\","
        "\"api_version\":%d,"
        "\"printer_uuid\":\"%s\","
        "\"services\":{"
            "\"cc2_control\":%d,"
            "\"moonraker_compat\":%d"
        "},"
        "\"capabilities\":{"
            "\"mqtt\":true,"
            "\"camera\":true,"
            "\"canvas\":true,"
            "\"file_manager\":true,"
            "\"gcode_thumbnails\":true,"
            "\"object_exclusion\":true,"
            "\"gcode_console\":true,"
            "\"orca_upload\":true,"
            "\"orca_print\":true,"
            "\"panda_compat\":%s,"
            "\"material_presets\":true,"
            "\"persistent_ui_preferences\":true,"
            "\"print_history\":true,"
            "\"canvas_auto_refill\":true,"
            "\"canvas_unload_distance\":true,"
            "\"bed_plates\":true,"
            "\"spool_tracking\":true"
        "},"
        "\"endpoints\":{"
            "\"printer\":\"/api/printer\","
            "\"health\":\"/api/health\","
            "\"canvas\":\"/api/canvas\","
            "\"files\":\"/api/gcode-files\","
            "\"console\":\"/api/console\","
            "\"preferences\":\"/api/preferences\","
            "\"runout\":\"/api/runout\","
            "\"history\":\"/api/history\","
            "\"plates\":\"/api/plates\","
            "\"screws_history\":\"/api/screws/history\","
            "\"spools\":\"/api/spools\","
            "\"discovery\":\"/api/v1/system/info\""
        "},"
        "\"runtime\":{"
            "\"mqtt_connected\":%s,"
            "\"mqtt_registered\":%s"
        "}"
        "}\n",
        CC2_COMMUNITY_FIRMWARE_VERSION,
        CC2_CONTROL_VERSION,
        CC2_DISCOVERY_API_VERSION,
        uuid,
        service_http_port,
        service_panda_port,
        service_panda_port > 0 ? "true" : "false",
        mqtt && mqtt->connected ? "true" : "false",
        mqtt && mqtt->registered ? "true" : "false");
    if (length > 0 && (size_t)length < sizeof(body))
        respond(fd, 200, "OK", "application/json; charset=utf-8", body, (size_t)length);
}

static void json_number(char *out, size_t cap, int have, double value) {
    if (have) snprintf(out, cap, "%.1f", value);
    else snprintf(out, cap, "null");
}

static void json_z_offset(char *out, size_t cap, int have, double value) {
    if (have) snprintf(out, cap, "%.3f", fabs(value) < 0.0005 ? 0.0 : value);
    else snprintf(out, cap, "null");
}

static void json_escape(char *out,size_t cap,const char *in) {
    size_t n=0;
    while(*in&&n+1<cap){unsigned char ch=(unsigned char)*in++;
        if((ch=='"'||ch=='\\')&&n+2<cap){out[n++]='\\';out[n++]=(char)ch;}
        else if(ch>=32)out[n++]=(char)ch;}
    out[n]='\0';
}

typedef struct {
    char relative_path[PATH_MAX_LOCAL];
    long long size;
    long long modified;
} gcode_file_entry;

typedef struct {
    gcode_file_entry files[GCODE_FILES_MAX];
    size_t count;
    size_t total;   /* G-code files found, listed or not */
    size_t scanned; /* directory entries examined */
    int available;
    int truncated;
    int scan_truncated;
    int has_more;
    const gcode_file_entry *after;
} gcode_file_list;

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int failed;
} json_builder;

static void json_builder_printf(json_builder *builder, const char *format, ...) {
    if (builder->failed || builder->length >= builder->capacity) return;
    va_list args;
    va_start(args, format);
    int written = vsnprintf(builder->data + builder->length,
                            builder->capacity - builder->length, format, args);
    va_end(args);
    if (written < 0 || (size_t)written >= builder->capacity - builder->length) {
        builder->failed = 1;
        return;
    }
    builder->length += (size_t)written;
}

static void json_builder_string(json_builder *builder, const char *value) {
    json_builder_printf(builder, "\"");
    for (const unsigned char *cursor = (const unsigned char *)value;
         *cursor && !builder->failed; ++cursor) {
        unsigned char ch = *cursor;
        if (ch == '"' || ch == '\\') json_builder_printf(builder, "\\%c", ch);
        else if (ch < 32) json_builder_printf(builder, "\\u%04x", (unsigned int)ch);
        else json_builder_printf(builder, "%c", ch);
    }
    json_builder_printf(builder, "\"");
}

static int is_gcode_filename(const char *name) {
    size_t length = strlen(name);
    return length > 6 && strcasecmp(name + length - 6, ".gcode") == 0;
}

static int safe_relative_path(const char *relative) {
    if (!relative[0] || relative[0] == '/' || strchr(relative, '\\')) return 0;
    const char *segment = relative;
    for (const char *cursor = relative; ; ++cursor) {
        unsigned char ch = (unsigned char)*cursor;
        if (ch && ch < 32) return 0;
        if (ch == '/' || ch == '\0') {
            size_t length = (size_t)(cursor - segment);
            if (!length || (length == 1 && segment[0] == '.') ||
                (length == 2 && segment[0] == '.' && segment[1] == '.')) return 0;
            if (!ch) break;
            segment = cursor + 1;
        }
    }
    return 1;
}

static int compare_gcode_files(const void *left, const void *right) {
    const gcode_file_entry *a = (const gcode_file_entry *)left;
    const gcode_file_entry *b = (const gcode_file_entry *)right;
    if (a->modified != b->modified) return a->modified < b->modified ? 1 : -1;
    int order = strcasecmp(a->relative_path, b->relative_path);
    return order ? order : strcmp(a->relative_path, b->relative_path);
}

/* Keep the newest GCODE_FILES_MAX files in whatever order readdir returns
 * them. On ext4 that order follows name hashes, so keeping the first files
 * found would hide arbitrary ones, often the latest upload. */
static void add_gcode_file(gcode_file_list *list, const char *relative,
                           const struct stat *status) {
    gcode_file_entry candidate;
    snprintf(candidate.relative_path, sizeof(candidate.relative_path), "%s", relative);
    candidate.size = (long long)status->st_size;
    candidate.modified = (long long)status->st_mtime;
    list->total++;
    if (list->after && compare_gcode_files(&candidate, list->after) <= 0) return;
    if (list->count < GCODE_FILES_MAX) {
        list->files[list->count++] = candidate;
        return;
    }
    list->truncated = 1;
    list->has_more = 1;
    size_t oldest = 0;
    for (size_t index = 1; index < list->count; ++index)
        if (compare_gcode_files(&list->files[index], &list->files[oldest]) > 0) oldest = index;
    if (compare_gcode_files(&candidate, &list->files[oldest]) < 0) list->files[oldest] = candidate;
}

static void scan_gcode_directory(const char *root, const char *relative,
                                 unsigned int depth, gcode_file_list *list) {
    if (depth > GCODE_SCAN_DEPTH_MAX || list->scanned >= GCODE_SCAN_ENTRIES_MAX) {
        list->scan_truncated = list->truncated = 1;
        return;
    }
    char directory_path[PATH_MAX_LOCAL * 2];
    int directory_length = relative[0]
        ? snprintf(directory_path, sizeof(directory_path), "%s/%s", root, relative)
        : snprintf(directory_path, sizeof(directory_path), "%s", root);
    if (directory_length < 0 || (size_t)directory_length >= sizeof(directory_path)) {
        list->scan_truncated = list->truncated = 1;
        return;
    }
    DIR *directory = opendir(directory_path);
    if (!directory) return;
    struct dirent *item;
    while ((item = readdir(directory)) != NULL) {
        if (item->d_name[0] == '.') continue;
        if (list->scanned >= GCODE_SCAN_ENTRIES_MAX) {
            list->scan_truncated = list->truncated = 1;
            break;
        }
        list->scanned++;
        char child_relative[PATH_MAX_LOCAL];
        int relative_length = relative[0]
            ? snprintf(child_relative, sizeof(child_relative), "%s/%s", relative, item->d_name)
            : snprintf(child_relative, sizeof(child_relative), "%s", item->d_name);
        if (relative_length < 0 || (size_t)relative_length >= sizeof(child_relative)) {
            list->scan_truncated = list->truncated = 1;
            continue;
        }
        char child_path[PATH_MAX_LOCAL * 2];
        int path_length = snprintf(child_path, sizeof(child_path), "%s/%s", root, child_relative);
        if (path_length < 0 || (size_t)path_length >= sizeof(child_path)) {
            list->scan_truncated = list->truncated = 1;
            continue;
        }
        struct stat status;
        if (lstat(child_path, &status) != 0 || S_ISLNK(status.st_mode)) continue;
        if (S_ISDIR(status.st_mode)) {
            if (depth < GCODE_SCAN_DEPTH_MAX)
                scan_gcode_directory(root, child_relative, depth + 1, list);
            else list->scan_truncated = list->truncated = 1;
        } else if (S_ISREG(status.st_mode) && is_gcode_filename(item->d_name) &&
                   safe_relative_path(child_relative)) {
            add_gcode_file(list, child_relative, &status);
        }
    }
    closedir(directory);
}

static void collect_gcode_files_after(const char *root, gcode_file_list *list, const gcode_file_entry *after) {
    memset(list, 0, sizeof(*list));
    list->after = after;
    struct stat status;
    if (stat(root, &status) != 0 || !S_ISDIR(status.st_mode)) return;
    DIR *probe = opendir(root);
    if (!probe) return;
    closedir(probe);
    list->available = 1;
    scan_gcode_directory(root, "", 0, list);
    qsort(list->files, list->count, sizeof(list->files[0]), compare_gcode_files);
}

static void collect_gcode_files(const char *root, gcode_file_list *list) {
    collect_gcode_files_after(root, list, NULL);
}

static void append_gcode_storage(json_builder *builder, const char *name,
                                 const gcode_file_list *list, const char *root) {
    json_builder_string(builder, name);
    json_builder_printf(builder, ":{\"available\":%s,\"truncated\":%s,\"count\":%lu,\"total\":%lu,\"files\":[",
                        list->available ? "true" : "false",
                        list->truncated ? "true" : "false",
                        (unsigned long)list->count, (unsigned long)list->total);
    for (size_t index = 0; index < list->count; ++index) {
        const gcode_file_entry *entry = &list->files[index];
        if (index) json_builder_printf(builder, ",");
        json_builder_printf(builder, "{\"path\":");
        json_builder_string(builder, entry->relative_path);
        json_builder_printf(builder, ",\"size\":%lld,\"modified\":%lld}",
                            entry->size, entry->modified);
    }
    json_builder_printf(builder, "]");
    json_builder_printf(builder, ",\"has_more\":%s,\"scan_truncated\":%s,\"next\":",
                        list->has_more ? "true" : "false", list->scan_truncated ? "true" : "false");
    if (list->has_more && list->count) {
        const gcode_file_entry *last = &list->files[list->count - 1];
        json_builder_printf(builder, "{\"modified\":\"%lld\",\"path\":", last->modified);
        json_builder_string(builder, last->relative_path);
        json_builder_printf(builder, "}");
    } else json_builder_printf(builder, "null");
    struct statvfs space;
    struct stat st, parent;
    char upper[PATH_MAX_LOCAL * 2];
    int mounted = strcmp(name, "usb") != 0 ||
        (snprintf(upper, sizeof(upper), "%s/..", root) < (int)sizeof(upper) &&
         stat(root, &st) == 0 && stat(upper, &parent) == 0 && st.st_dev != parent.st_dev);
    if (list->available && mounted && statvfs(root, &space) == 0) {
        unsigned long long unit = space.f_frsize ? space.f_frsize : space.f_bsize;
        json_builder_printf(builder, ",\"space\":{\"total_bytes\":%llu,\"available_bytes\":%llu,\"free_bytes\":%llu}",
            unit * space.f_blocks, unit * space.f_bavail, unit * space.f_bfree);
    } else json_builder_printf(builder, ",\"space\":null");
    json_builder_printf(builder, "}");
}

static void gcode_files_response(int fd) {
    gcode_file_list *internal_files = calloc(1, sizeof(*internal_files));
    gcode_file_list *usb_files = calloc(1, sizeof(*usb_files));
    char *body = malloc(GCODE_JSON_CAP);
    if (!internal_files || !usb_files || !body) {
        const char *error = "{\"error\":\"Out of memory\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8",
                error, strlen(error));
        free(internal_files);
        free(usb_files);
        free(body);
        return;
    }
    collect_gcode_files(gcode_internal_root, internal_files);
    collect_gcode_files(gcode_usb_root, usb_files);
    json_builder builder = { body, 0, GCODE_JSON_CAP, 0 };
    json_builder_printf(&builder, "{");
    append_gcode_storage(&builder, "internal", internal_files, gcode_internal_root);
    json_builder_printf(&builder, ",");
    append_gcode_storage(&builder, "usb", usb_files, gcode_usb_root);
    json_builder_printf(&builder, "}\n");
    if (builder.failed) {
        const char *error = "{\"error\":\"File list is too large\"}\n";
        respond(fd, 507, "Insufficient Storage", "application/json; charset=utf-8",
                error, strlen(error));
    } else {
        respond(fd, 200, "OK", "application/json; charset=utf-8", body, builder.length);
    }
    free(internal_files);
    free(usb_files);
    free(body);
}

static int gcode_file_is_printable(const char *root, const char *relative) {
    if (!safe_relative_path(relative) || !is_gcode_filename(relative)) return 0;
    char current[PATH_MAX_LOCAL * 2];
    int root_length = snprintf(current, sizeof(current), "%s", root);
    if (root_length < 0 || (size_t)root_length >= sizeof(current)) return 0;
    const char *segment = relative;
    while (*segment) {
        const char *slash = strchr(segment, '/');
        size_t length = slash ? (size_t)(slash - segment) : strlen(segment);
        size_t used = strlen(current);
        if (used + 1 + length >= sizeof(current)) return 0;
        current[used++] = '/';
        memcpy(current + used, segment, length);
        current[used + length] = '\0';
        struct stat status;
        if (lstat(current, &status) != 0 || S_ISLNK(status.st_mode)) return 0;
        if (slash) {
            if (!S_ISDIR(status.st_mode)) return 0;
            segment = slash + 1;
        } else {
            return S_ISREG(status.st_mode);
        }
    }
    return 0;
}

static int gcode_resolved_path(const char *root, const char *relative,
                               char *path, size_t capacity) {
    if (!gcode_file_is_printable(root, relative)) return 0;
    int length = snprintf(path, capacity, "%s/%s", root, relative);
    return length >= 0 && (size_t)length < capacity;
}


static int gcode_request_file(const char *body, size_t body_len,
                              char storage[16], char filename[PATH_MAX_LOCAL],
                              const char **extra, size_t *extra_len,
                              const char **root, const char **media);
static size_t content_length_from_headers(const char *request);

static int gcode_storage_root(const char *storage, const char **root) {
    if(strcmp(storage,"internal")==0) {*root=gcode_internal_root;return 1;}
    if(strcmp(storage,"usb")==0) {*root=gcode_usb_root;return 1;}
    return 0;
}

#include "gcode_download.h"
#include "gcode_layer_path.h"
#include "gcode_layer_index_store.h"
#include "gcode_layer_path_http.h"
#include "gcode_object_preview_http.h"

/* Cursor pages keep the fixed 128-entry window and all traversal guards.
 * A cursor is metadata for ordering only, never an instruction to open a path.
 * Timestamps are decimal strings in the response to avoid JS integer rounding. */
static int gcode_page_query(const char *query, char storage[16], gcode_file_entry *after) {
    if (!query || strncmp(query, "storage=", 8)) return 0;
    const char *before = strstr(query + 8, "&before=");
    if (!before || before == query + 8 || (size_t)(before - query - 8) >= 16) return 0;
    memcpy(storage, query + 8, (size_t)(before - query - 8)); storage[before - query - 8] = 0;
    const char *number = before + 8, *file = strstr(number, "&file=");
    if (!file || file == number || file - number >= 32 || strchr(file + 6, '&')) return 0;
    char text[32]; memcpy(text, number, (size_t)(file - number)); text[file - number] = 0;
    for (size_t i = text[0] == '-' ? 1 : 0; text[i]; i++) if (!isdigit((unsigned char)text[i])) return 0;
    char *end; errno = 0; after->modified = strtoll(text, &end, 10);
    if (errno || end == text || *end) return 0;
    return download_decode(after->relative_path, sizeof(after->relative_path), file + 6, strlen(file + 6)) &&
           safe_relative_path(after->relative_path) && is_gcode_filename(after->relative_path);
}
static void gcode_page_response(int fd, const char *query) {
    char storage[16]; gcode_file_entry after = {0}; const char *root;
    if (!gcode_page_query(query, storage, &after) || !gcode_storage_root(storage, &root)) {
        const char error[] = "{\"error\":\"Invalid file page cursor\"}\n";
        respond(fd,400,"Bad Request","application/json",error,sizeof(error)-1); return;
    }
    gcode_file_list *list = calloc(1, sizeof(*list)); char *body = malloc(GCODE_JSON_CAP);
    if (!list || !body) {
        const char error[] = "{\"error\":\"Out of memory\"}\n";
        respond(fd,503,"Service Unavailable","application/json",error,sizeof(error)-1);
        free(list); free(body); return;
    }
    collect_gcode_files_after(root, list, &after);
    json_builder b = {body,0,GCODE_JSON_CAP,0}; json_builder_printf(&b,"{");
    append_gcode_storage(&b,storage,list,root); json_builder_printf(&b,"}\n");
    if (b.failed) {
        const char error[] = "{\"error\":\"File page is too large\"}\n";
        respond(fd,507,"Insufficient Storage","application/json",error,sizeof(error)-1);
    } else respond(fd,200,"OK","application/json",body,b.length);
    free(body); free(list);
}

/* USB root must actually be a mounted removable filesystem, not a plain
 * directory on internal flash left behind when the drive is unplugged. */
static int gcode_storage_writable(const char *storage, const char *root) {
    struct stat st,parent;
    if(stat(root,&st)!=0||!S_ISDIR(st.st_mode))return 0;
    if(strcmp(storage,"usb")==0){
        char upper[PATH_MAX_LOCAL*2];
        if(snprintf(upper,sizeof(upper),"%s/..",root)>=(int)sizeof(upper)||
           stat(upper,&parent)!=0||st.st_dev==parent.st_dev)return 0;
    }
    return access(root,W_OK|X_OK)==0;
}

static int gcode_idle_for_mutation(const mqtt_client *mqtt){
    return mqtt->connected && mqtt->registered && mqtt->have_machine_status &&
        mqtt->machine_status==1 && mqtt->last_message>0 &&
        time(NULL)-mqtt->last_message<=15;
}

/* Uploads publish new files without changing the active job. */
static int gcode_ready_for_upload(const mqtt_client *mqtt){
    return mqtt->connected && mqtt->registered && mqtt->have_machine_status &&
        (mqtt->machine_status==1 || mqtt->machine_status==2) &&
        mqtt->last_message>0 && time(NULL)-mqtt->last_message<=15;
}

/* A sliced job can be named by its basename, a native local/ path, or an
 * imported USB alias. Protect matching basenames on both media (including FAT
 * case aliases) rather than guessing which representation the native UI uses. */
static atomic_int upload_busy=0;
static pthread_mutex_t orca_pending_mutex=PTHREAD_MUTEX_INITIALIZER;
static char orca_pending_filename[PATH_MAX_LOCAL];
static int gcode_same_job_name(const char *file, const char *job) {
    if (!file || !*file || !job || !*job) return 0;
    const char *a = strrchr(file, '/'), *b = strrchr(job, '/');
    return !strcasecmp(a ? a + 1 : file, b ? b + 1 : job);
}
/* Compare file identity as well as text: removable filesystems can resolve
 * different Unicode case spellings to the same file. Restrict all lookups to
 * the already-qualified G-code roots and retain their no-symlink checks. */
static int gcode_same_job_file(const char *file, const char *job) {
    if (!file || !job || !*job) return 0;
    const char *roots[] = {gcode_internal_root, gcode_usb_root};
    const char *relative = job;
    for (unsigned i = 0; i < 2; i++) {
        size_t n = strlen(roots[i]);
        if (!strncmp(job, roots[i], n) && job[n] == '/') { relative = job + n + 1; break; }
    }
    if (!strncmp(relative,"local/",6)) relative += 6;
    else if (!strncmp(relative,"u-disk/",7)) relative += 7;
    else if (!strncmp(relative,"usb/",4)) relative += 4;
    char candidate[PATH_MAX_LOCAL*2], active[PATH_MAX_LOCAL*2];
    struct stat a,b;
    for (unsigned i = 0; i < 2; i++) {
        if (!gcode_resolved_path(roots[i],file,candidate,sizeof(candidate)) || stat(candidate,&a)) continue;
        for (unsigned j = 0; j < 2; j++)
            if (gcode_resolved_path(roots[j],relative,active,sizeof(active)) && !stat(active,&b) &&
                a.st_dev == b.st_dev && a.st_ino == b.st_ino) return 1;
    }
    return 0;
}
/* Stable codes are for UI localization; retain English error text for API clients. */
static void gcode_delete_error(int fd, int status, const char *reason, const char *code) {
    static const struct { const char *code, *message; } errors[] = {
        {"file_delete_fresh_status", "Printer must be connected with fresh status"},
        {"file_delete_busy", "File deletion unavailable during startup, transfer, upgrade or recovery"},
        {"file_delete_upload_busy", "Finish the current upload before deleting files"},
        {"file_delete_pending_print", "File is waiting to start printing"},
        {"file_delete_active_print_unknown", "Cannot identify the active print safely"},
        {"file_delete_active_print", "Cannot delete the active, paused or recoverable print"},
        {"file_delete_state_unknown", "Cannot identify the printer state safely"},
        {"file_delete_storage_unavailable", "Storage unavailable or not writable"},
        {"file_delete_unsafe_file", "G-code file not found or unsafe"},
        {"file_delete_failed", "Cannot delete this file"},
    };
    const char *message = "Cannot delete this file";
    for (size_t i = 0; i < sizeof(errors) / sizeof(errors[0]); i++)
        if (!strcmp(code, errors[i].code)) { message = errors[i].message; break; }
    char json[384];
    int n = snprintf(json, sizeof(json), "{\"error\":\"%s\",\"code\":\"%s\"}\n", message, code);
    respond(fd,status,reason,"application/json",json,(size_t)n);
}

static int print_start_preparing(const char *file); /* a start of this file is checked on the worker */
static const char *gcode_delete_guard(const mqtt_client *mqtt, const char *file) {
    time_t now = time(NULL);
    if (!mqtt->connected || !mqtt->registered || !mqtt->have_machine_status ||
        mqtt->last_message <= 0 || now < mqtt->last_message || now - mqtt->last_message > 15)
        return "file_delete_fresh_status";
    if (mqtt->machine_status == 0 || mqtt->machine_status == 9 || mqtt->machine_status == 11 ||
        mqtt->machine_status == 15 || mqtt->machine_status == 16)
        return "file_delete_busy";
    if (atomic_load(&upload_busy)) return "file_delete_upload_busy";
    pthread_mutex_lock(&orca_pending_mutex);
    int pending = gcode_same_job_name(file, orca_pending_filename) || gcode_same_job_file(file, orca_pending_filename);
    pthread_mutex_unlock(&orca_pending_mutex);
    if (pending || print_start_preparing(file)) return "file_delete_pending_print";
    const char *native = uds_print_state(&telemetry);
    int reported_job = mqtt->machine_status == 2 || !strcmp(mqtt->print_state, "printing") ||
                       !strcmp(mqtt->print_state, "paused") || !strcmp(mqtt->print_state, "error");
    int native_job = native && (!strcmp(native, "printing") || !strcmp(native, "paused") || !strcmp(native, "error"));
    if (reported_job || native_job) {
        if (!native_job || !telemetry.have_filename || !telemetry.filename[0])
            return "file_delete_active_print_unknown";
        if (gcode_same_job_name(file, mqtt->filename) || gcode_same_job_name(file, telemetry.filename) ||
            gcode_same_job_file(file, mqtt->filename) || gcode_same_job_file(file, telemetry.filename))
            return "file_delete_active_print";
        return NULL;
    }
    if (mqtt->machine_status == 1 && !native) return NULL; /* retain idle operation without native telemetry */
    if (!native || (strcmp(native, "standby") && strcmp(native, "complete") && strcmp(native, "cancelled")))
        return "file_delete_state_unknown";
    return NULL;
}

static void gcode_delete_response(int fd,const char *request,const mqtt_client *mqtt,
                                  const char *body,size_t length){
    (void)request;
    char storage[16],file[PATH_MAX_LOCAL];const char *root,*media;
    if(!gcode_request_file(body,length,storage,file,NULL,NULL,&root,&media)||
       !gcode_storage_writable(storage,root)){
        gcode_delete_error(fd,400,"Bad Request","file_delete_storage_unavailable");return;
    }
    (void)media;
    char path[PATH_MAX_LOCAL*2];
    if(!gcode_resolved_path(root,file,path,sizeof(path))){
        gcode_delete_error(fd,404,"Not Found","file_delete_unsafe_file");return;
    }
    const char *blocked = gcode_delete_guard(mqtt, file);
    if (blocked) {
        gcode_delete_error(fd,409,"Conflict",blocked);return;
    }
    /* Recheck direct filename and block hard-linked content. */
    struct stat st;
    if(lstat(path,&st)!=0||!S_ISREG(st.st_mode)||st.st_nlink!=1||
       unlink(path)!=0){
        gcode_delete_error(fd,409,"Conflict","file_delete_failed");return;
    }
    layer_store_forget(path);
    const char *ok="{\"deleted\":true}\n";
    respond(fd,200,"OK","application/json",ok,strlen(ok));
}

static void gcode_copy_response(int fd,const mqtt_client *mqtt,const char *body,size_t length){
    if(!gcode_idle_for_mutation(mqtt)){
        const char *e="{\"error\":\"Printer must be idle and connected\"}\n";
        respond(fd,409,"Conflict","application/json",e,strlen(e));return;
    }
    char source_storage[16],destination_storage[16],file[PATH_MAX_LOCAL];
    const char *first=memchr(body,'\n',length);if(!first)goto invalid;
    const char *second=memchr(first+1,'\n',length-(size_t)(first+1-body));if(!second)goto invalid;
    size_t a=(size_t)(first-body),b=(size_t)(second-first-1),c=length-(size_t)(second+1-body);
    while(c&&isspace((unsigned char)second[1+c-1]))c--;
    if(!a||a>=sizeof(source_storage)||!b||b>=sizeof(destination_storage)||!c||c>=sizeof(file))goto invalid;
    memcpy(source_storage,body,a);source_storage[a]=0;memcpy(destination_storage,first+1,b);destination_storage[b]=0;memcpy(file,second+1,c);file[c]=0;
    if(strcmp(source_storage,destination_storage)==0)goto invalid;
    const char *source_root,*destination_root;
    if(!gcode_storage_root(source_storage,&source_root)||!gcode_storage_root(destination_storage,&destination_root)||
       !gcode_storage_writable(destination_storage,destination_root))goto invalid;
    char source[PATH_MAX_LOCAL*2],destination[PATH_MAX_LOCAL*2],temporary[PATH_MAX_LOCAL*2];
    if(!gcode_resolved_path(source_root,file,source,sizeof(source)))goto missing;
    const char *base=strrchr(file,'/');base=base?base+1:file;
    if(!safe_relative_path(base)||!is_gcode_filename(base)||
       snprintf(destination,sizeof(destination),"%s/%s",destination_root,base)>=(int)sizeof(destination)||
       snprintf(temporary,sizeof(temporary),"%s.part",destination)>=(int)sizeof(temporary))goto invalid;
    struct stat st;if(lstat(source,&st)!=0||!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))goto missing;
    if(lstat(destination,&st)==0||errno!=ENOENT){const char *e="{\"error\":\"Destination file already exists\"}\n";respond(fd,409,"Conflict","application/json",e,strlen(e));return;}
    FILE *in=fopen(source,"rb"),*out=NULL;int failed=0;if(!in)goto missing;
    out=fopen(temporary,"wb");if(!out){fclose(in);goto copy_failed;}
    char buffer[65536];for(;;){size_t n=fread(buffer,1,sizeof(buffer),in);if(n&&fwrite(buffer,1,n,out)!=n){failed=1;break;}if(n<sizeof(buffer)){if(ferror(in))failed=1;break;}}
    if(!failed&&fflush(out)!=0)failed=1;
    if(!failed&&fsync(fileno(out))!=0)failed=1;
    if(fclose(out)!=0)failed=1;
    fclose(in);
    if(failed||rename(temporary,destination)!=0){unlink(temporary);goto copy_failed;}
    layer_store_note(destination);
    {const char *ok="{\"copied\":true}\n";respond(fd,201,"Created","application/json",ok,strlen(ok));return;}
invalid:{const char *e="{\"error\":\"Invalid copy request or unavailable storage\"}\n";respond(fd,400,"Bad Request","application/json",e,strlen(e));return;}
missing:{const char *e="{\"error\":\"Source G-code file not found or unsafe\"}\n";respond(fd,404,"Not Found","application/json",e,strlen(e));return;}
copy_failed:{const char *e="{\"error\":\"Cannot copy this file\"}\n";respond(fd,409,"Conflict","application/json",e,strlen(e));return;}
}

/* A small URL parser: storage and basename are encoded independently; never
 * allow directories or URL-decoded path separators in an upload filename. */
static int gcode_decode_name(char *out,size_t cap,const char *encoded){
    size_t n=0;
    for(size_t i=0;encoded[i];i++){
        unsigned char ch=(unsigned char)encoded[i];
        if(ch=='%'){
            int a,b;char x=encoded[++i],y=x?encoded[++i]:0;
            if(!x||!y)return 0;
            a=x>='0'&&x<='9'?x-'0':x>='A'&&x<='F'?x-'A'+10:x>='a'&&x<='f'?x-'a'+10:-1;
            b=y>='0'&&y<='9'?y-'0':y>='A'&&y<='F'?y-'A'+10:y>='a'&&y<='f'?y-'a'+10:-1;
            if(a<0||b<0)return 0;
            ch=(unsigned char)((a<<4)|b);
        }
        if(ch<32||ch==127||ch=='/'||ch=='\\'||ch=='?'||ch=='#'||ch==':')return 0;
        if(n+1>=cap)return 0;
        out[n++]=(char)ch;
    }
    out[n]=0;
    return n>6&&strcmp(out,".")!=0&&strcmp(out,"..")!=0&&is_gcode_filename(out);
}

static int gcode_upload_query(const char *query,char storage[16],char name[PATH_MAX_LOCAL]){
    if(!query||strncmp(query,"storage=",8)!=0)return 0;
    const char *separator=strstr(query+8,"&name=");
    if(!separator||(size_t)(separator-(query+8))>=16)return 0;
    memcpy(storage,query+8,(size_t)(separator-(query+8)));
    storage[separator-(query+8)]=0;
    return gcode_decode_name(name,PATH_MAX_LOCAL,separator+6);
}

typedef struct {
    int fd;
    unsigned char initial[REQUEST_MAX+1];
    size_t initial_length;
    size_t header_length;
    size_t content_length;
    char storage[16];
    char name[PATH_MAX_LOCAL];
    const mqtt_client *mqtt;
    struct timespec started;
} gcode_upload_job;
#define UPLOAD_TOTAL_SECONDS 1800
#define UPLOAD_STORAGE_MARGIN (16ULL*1024*1024)
static int (*upload_statvfs)(const char *,struct statvfs *)=statvfs;
static int upload_has_space(const char *root,size_t length,unsigned copies){
    struct statvfs st;
    if(upload_statvfs(root,&st))return 0;
    uint64_t block=st.f_frsize?st.f_frsize:st.f_bsize;
    if(!block)return 0;
    uint64_t available=st.f_bavail>UINT64_MAX/block?UINT64_MAX:(uint64_t)st.f_bavail*block;
    uint64_t required=(uint64_t)length*copies+UPLOAD_STORAGE_MARGIN;
    return available>=required;
}
static int upload_space_guard(int fd,const char *root,size_t length,unsigned copies){
    if(upload_has_space(root,length,copies))return 1;
    const char *error="{\"error\":\"Insufficient free space for upload and storage reserve\"}\n";
    respond(fd,507,"Insufficient Storage","application/json",error,strlen(error));return 0;
}
/* As upload_space_guard, but an upload into internal memory full of old USB copies first lets the oldest of them
 * make room (gcode_usb_make_room: only what may be deleted, only as many as needed, only with a fresh printer
 * status), as a USB start does. Main loop, before the upload slot is taken (so file_delete_upload_busy is not set). */
static void gcode_usb_make_room(const mqtt_client *mqtt, uint64_t size, const char *name);
static int upload_space_or_room(int fd,const mqtt_client *mqtt,const char *root,size_t length,unsigned copies){
    if(!upload_has_space(root,length,copies)&&mqtt&&!strcmp(root,gcode_internal_root))
        gcode_usb_make_room(mqtt,(uint64_t)length*copies,"");
    return upload_space_guard(fd,root,length,copies);
}
static int upload_seconds_left(const gcode_upload_job *job){
    struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);
    long elapsed=now.tv_sec-job->started.tv_sec;
    return elapsed>=UPLOAD_TOTAL_SECONDS?0:UPLOAD_TOTAL_SECONDS-(int)elapsed;
}
static ssize_t upload_receive(gcode_upload_job *job,void *buffer,size_t length){
    for(;;){
        int left=upload_seconds_left(job);if(!left){errno=ETIMEDOUT;return -1;}
        struct pollfd p={job->fd,POLLIN,0};
        int ready=poll(&p,1,(left<20?left:20)*1000);
        if(ready<0&&errno==EINTR)continue;
        if(ready<=0){errno=ETIMEDOUT;return -1;}
        ssize_t n=recv(job->fd,buffer,length,MSG_DONTWAIT);
        if(n<0&&(errno==EINTR||errno==EAGAIN||errno==EWOULDBLOCK))continue;
        return n;
    }
}
/* Read and drop the rest of a rejected body before answering. Closing a
 * socket with unread input resets the connection, and a browser then reports
 * a network error instead of the response. */
static void upload_discard(gcode_upload_job *job,size_t received,unsigned char *buffer,size_t capacity){
    while(received<job->content_length){
        size_t want=job->content_length-received;
        if(want>capacity)want=capacity;
        ssize_t n=upload_receive(job,buffer,want);
        if(n<=0)return;
        received+=(size_t)n;
    }
}
/* One upload at a time. The connection thread takes the slot and the upload
 * worker releases it, so this is an atomic flag: a mutex must be unlocked by
 * the thread that locked it. */
static int upload_slot_acquire(void){int expected=0;return atomic_compare_exchange_strong(&upload_busy,&expected,1);}
static void upload_slot_release(void){atomic_store(&upload_busy,0);}
/* One print request may await the operator's Canvas mapping. Never print from
 * the upload worker: the existing protected print route remains authoritative. */
static unsigned long orca_pending_generation=0;
static time_t orca_pending_created=0;

static void orca_pending_expire_locked(void){
    if(orca_pending_filename[0] &&
       (time(NULL)<orca_pending_created || time(NULL)-orca_pending_created>3600))
        orca_pending_filename[0]=0;
}
static void orca_pending_response(int fd){
    char filename[PATH_MAX_LOCAL*2],body[PATH_MAX_LOCAL*3];
    unsigned long generation=0;
    pthread_mutex_lock(&orca_pending_mutex);
    orca_pending_expire_locked();
    if(orca_pending_filename[0]){
        json_escape(filename,sizeof(filename),orca_pending_filename);
        generation=orca_pending_generation;
    }else filename[0]=0;
    pthread_mutex_unlock(&orca_pending_mutex);
    int n=snprintf(body,sizeof(body),
      "{\"pending\":%s,\"filename\":\"%s\",\"generation\":%lu}\n",
      generation?"true":"false",filename,generation);
    if(n>0 && (size_t)n<sizeof(body))respond(fd,200,"OK","application/json",body,(size_t)n);
}
static void orca_pending_clear_response(int fd,const char *body,size_t length){
    char number[32];
    if(!length||length>=sizeof(number)){
        static const char error[]="{\"error\":\"Invalid generation\"}\n";
        respond(fd,400,"Bad Request","application/json",error,sizeof(error)-1);return;
    }
    memcpy(number,body,length);number[length]=0;
    char *end=NULL;errno=0;
    unsigned long generation=strtoul(number,&end,10);
    if(errno||!generation||end==number||*end){
        static const char error[]="{\"error\":\"Invalid generation\"}\n";
        respond(fd,400,"Bad Request","application/json",error,sizeof(error)-1);return;
    }
    pthread_mutex_lock(&orca_pending_mutex);
    orca_pending_expire_locked();
    int cleared=orca_pending_filename[0] && generation==orca_pending_generation;
    if(cleared)orca_pending_filename[0]=0;
    pthread_mutex_unlock(&orca_pending_mutex);
    static const char ok[]="{\"cleared\":true}\n";
    static const char conflict[]="{\"error\":\"Print request no longer pending\"}\n";
    respond(fd,cleared?200:409,cleared?"OK":"Conflict","application/json",
            cleared?ok:conflict,cleared?sizeof(ok)-1:sizeof(conflict)-1);
}


static void *gcode_upload_worker(void *arg){
    gcode_upload_job *job=arg;
    const char *root=NULL;
    const char *error=NULL;
    int code=400;const char *status="Bad Request";
    int output=-1;char destination[PATH_MAX_LOCAL*2],temporary[PATH_MAX_LOCAL*2];
    temporary[0]=0;
    size_t received=job->initial_length-job->header_length;
    unsigned char chunk[UPLOAD_CHUNK];
    if(!gcode_storage_root(job->storage,&root)||!gcode_storage_writable(job->storage,root)){
        error="Storage unavailable or not writable";goto done;
    }
    if(!job->content_length||job->content_length>FILE_UPLOAD_MAX){
        error="Invalid upload size";goto done;
    }
    if(snprintf(destination,sizeof(destination),"%s/%s",root,job->name)>=(int)sizeof(destination)){
        error="File name too long";goto done;
    }
    /* Existing files are never overwritten, and symlinks are not followed. */
    struct stat st;
    if(lstat(destination,&st)==0){code=409;status="Conflict";error="File already exists";goto done;}
    if(errno!=ENOENT){error="Cannot inspect destination";goto done;}
    /* The temp filename must not end in .gcode, so the UI cannot list it. */
    if(snprintf(temporary,sizeof(temporary),"%s/.cc2-upload-XXXXXX",root)>=(int)sizeof(temporary)){
        error="Temporary path too long";goto done;
    }
    if(!upload_has_space(root,job->content_length,1)){code=507;status="Insufficient Storage";error="Insufficient free space";goto done;}
    output=mkstemp(temporary);
    if(output<0){code=507;status="Insufficient Storage";error="Cannot create temporary file";goto done;}
    (void)fchmod(output,0644);
    if(received>job->content_length){error="Invalid upload body";goto done;}
    {size_t offset=0;
     while(offset<received){
        ssize_t n=write(output,job->initial+job->header_length+offset,received-offset);
        if(n<0&&errno==EINTR)continue;
        if(n<=0){code=507;status="Insufficient Storage";error="Cannot write upload";goto done;}
        offset+=(size_t)n;
     }}
    while(received<job->content_length){
        size_t required=job->content_length-received;
        if(required>sizeof(chunk))required=sizeof(chunk);
        ssize_t n=upload_receive(job,chunk,required);
        if(n<0&&errno==EINTR)continue;
        if(n<=0){if(n<0&&errno==ETIMEDOUT){code=408;status="Request Timeout";}error="Upload interrupted or timed out";goto done;}
        received+=(size_t)n;
        size_t offset=0;
        while(offset<(size_t)n){
            ssize_t written=write(output,chunk+offset,(size_t)n-offset);
            if(written<0&&errno==EINTR)continue;
            if(written<=0){code=507;status="Insufficient Storage";error="Cannot write upload";goto done;}
            offset+=(size_t)written;
        }
    }
    if(!upload_seconds_left(job)){code=408;status="Request Timeout";error="Upload deadline exceeded";goto done;}
    if(fsync(output)!=0){code=507;status="Insufficient Storage";error="Cannot finalize upload";goto done;}
    if(close(output)!=0){output=-1;error="Cannot close uploaded file";goto done;}
    output=-1;
    /* FAT/exFAT USB drives do not support hard links. Atomically reserve the
     * destination name using O_EXCL, then rename the completed temp file. */
    int reservation=open(destination,O_WRONLY|O_CREAT|O_EXCL,0600);
    if(reservation<0){
        code=errno==EEXIST?409:507;
        status=code==409?"Conflict":"Insufficient Storage";
        error=code==409?"File already exists":"Cannot reserve uploaded file";goto done;
    }
    close(reservation);
    if(rename(temporary,destination)!=0){
        unlink(destination);
        code=507;status="Insufficient Storage";
        error="Cannot publish uploaded file";goto done;
    }
    temporary[0]=0;
    layer_store_note(destination);
    code=201;status="Created";
done:
    if(output>=0)close(output);
    if(temporary[0])unlink(temporary);
    /* A rejected body is drained while the slot is still held, so only one
     * drain runs at a time; a stalled client (408) is not waited for again. */
    if(code!=201&&code!=408)upload_discard(job,received,chunk,sizeof(chunk));
    /* Free the upload slot before answering: a client may start its next
     * upload as soon as it reads this response. */
    upload_slot_release();
    {char body[220];int n=code==201?snprintf(body,sizeof(body),"{\"uploaded\":true}\n"):
        snprintf(body,sizeof(body),"{\"error\":\"%s\"}\n",error?error:"Upload failed");
     respond(job->fd,code,status,"application/json",body,(size_t)n);}
    close(job->fd);free(job);
    return NULL;
}

static int gcode_upload_start(int fd,const char *request,const char *query,
                              size_t used,size_t header_length,const mqtt_client *mqtt){
    if(!gcode_ready_for_upload(mqtt)){
        const char *e="{\"error\":\"Printer must be idle or printing and connected\"}\n";
        respond(fd,409,"Conflict","application/json",e,strlen(e));return 0;
    }
    char storage[16],name[PATH_MAX_LOCAL];
    if(!gcode_upload_query(query,storage,name)){
        const char *e="{\"error\":\"Invalid storage or G-code name\"}\n";
        respond(fd,400,"Bad Request","application/json",e,strlen(e));return 0;
    }
    const char *root;
    if(!gcode_storage_root(storage,&root)||!gcode_storage_writable(storage,root)){
        const char *e="{\"error\":\"Storage unavailable or not writable\"}\n";
        respond(fd,400,"Bad Request","application/json",e,strlen(e));return 0;
    }
    size_t len=content_length_from_headers(request);
    if(!len||len>FILE_UPLOAD_MAX||header_length>used||used-header_length>len){
        const char *e="{\"error\":\"Invalid upload size (maximum 512 MiB)\"}\n";
        respond(fd,413,"Payload Too Large","application/json",e,strlen(e));return 0;
    }
    if(!upload_space_or_room(fd,mqtt,root,len,1))return 0;
    if(!upload_slot_acquire()){
        const char *e="{\"error\":\"Another upload is running\"}\n";
        respond(fd,409,"Conflict","application/json",e,strlen(e));return 0;
    }
    gcode_upload_job *job=calloc(1,sizeof(*job));
    if(!job){upload_slot_release();return 0;}
    clock_gettime(CLOCK_MONOTONIC,&job->started);
    job->fd=fd;job->initial_length=used;job->header_length=header_length;
    job->content_length=len;memcpy(job->initial,request,used);
    snprintf(job->storage,sizeof(job->storage),"%s",storage);
    snprintf(job->name,sizeof(job->name),"%s",name);
    struct timeval timeout={20,0};
    setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    pthread_t worker;
    if(pthread_create(&worker,NULL,gcode_upload_worker,job)!=0){
        free(job);upload_slot_release();return 0;
    }
    pthread_detach(worker);
    return 1; /* worker owns fd */
}

/* OctoPrint-compatible upload-only adapter for OrcaSlicer. Never starts a print.
 * A bounded spool on internal storage permits multipart parsing with small RAM. */
static int orca_file_name_ok(const char *name){
    if(!name || !*name || strlen(name)>=PATH_MAX_LOCAL ||
       strcmp(name,".")==0 || strcmp(name,"..")==0 || !is_gcode_filename(name))return 0;
    for(const unsigned char *p=(const unsigned char *)name;*p;p++)
        if(*p<32||*p==127||*p=='/'||*p=='\\'||*p==':'||*p=='?'||*p=='#')return 0;
    return 1;
}
/* OrcaSlicer cannot rename a refused upload, and re-slicing the same model
 * repeats its name. A taken name is therefore saved as "name (1).gcode",
 * "name (2).gcode" and so on; an existing file is never overwritten. */
#define ORCA_NAME_COPIES_MAX 99
static int orca_copy_name(char out[PATH_MAX_LOCAL],const char *name,unsigned copy){
    size_t length=strlen(name);
    if(length<6)return 0;
    int n=copy?snprintf(out,PATH_MAX_LOCAL,"%.*s (%u)%s",(int)(length-6),name,copy,name+length-6)
              :snprintf(out,PATH_MAX_LOCAL,"%s",name);
    return n>0&&n<PATH_MAX_LOCAL&&n<=NAME_MAX;
}
/* The first free name from copy number `first` on: its number, -1 when none
 * fits, or -2 when the destination cannot be inspected. */
static int orca_free_name(const char *root,const char *name,unsigned first,
                          char chosen[PATH_MAX_LOCAL],char *destination,size_t capacity){
    for(unsigned copy=first;copy<=ORCA_NAME_COPIES_MAX;copy++){
        struct stat st;
        if(!orca_copy_name(chosen,name,copy)||
           snprintf(destination,capacity,"%s/%s",root,chosen)>=(int)capacity)return -1;
        if(lstat(destination,&st)!=0)return errno==ENOENT?(int)copy:-2;
    }
    return -1;
}
static int orca_get_boundary(const char *request,char boundary[80]){
    const char *p=request;
    while(*p){
        const char *end=strstr(p,"\r\n");
        if(!end)break;
        if(end==p)break;
        if((size_t)(end-p)>13 && !strncasecmp(p,"Content-Type:",13)){
            const char *m=p+13;
            while(m<end && (*m==' '||*m=='\t'))m++;
            if((size_t)(end-m)<19||strncasecmp(m,"multipart/form-data",19))return 0;
            const char *b=m;
            while(b+9<end && strncasecmp(b,"boundary=",9))b++;
            if(b+9>=end)return 0;
            b+=9;
            char quote=0;
            if(*b=='"'){quote='"';b++;}
            size_t n=0;
            while(b<end && n<70 && (!quote?*b!=';'&&*b!=' '&&*b!='\t':*b!=quote)){
                unsigned char ch=(unsigned char)*b++;
                if(ch<33||ch>126||ch=='\\'||ch=='"')return 0;
                boundary[n++]=(char)ch;
            }
            boundary[n]=0;
            return n>=1 && n<=70 && (!quote || (b<end && *b==quote));
        }
        p=end+2;
    }
    return 0;
}
/* Return the first valid CRLF--boundary marker starting at offset.  The
 * lookahead also handles patterns split across read buffers. */
static int orca_next_boundary(FILE *f,long start,const char *boundary,
                              long *payload_end,long *next,long *is_final){
    char pattern[80];
    int pat=snprintf(pattern,sizeof(pattern),"\r\n--%s",boundary);
    if(pat<=0||(size_t)pat>=sizeof(pattern))return 0;
    unsigned char buffer[UPLOAD_CHUNK+96];
    long base=start;
    size_t keep=(size_t)pat+2;
    if(fseek(f,start,SEEK_SET)!=0)return 0;
    for(;;){
        size_t n=fread(buffer,1,UPLOAD_CHUNK+keep,f);
        if(n<keep)return 0;
        for(size_t i=0;i+(size_t)pat+2<=n;i++){
            if(memcmp(buffer+i,pattern,(size_t)pat))continue;
            unsigned char a=buffer[i+(size_t)pat],b=buffer[i+(size_t)pat+1];
            if(!((a=='\r'&&b=='\n')||(a=='-'&&b=='-')))continue;
            *payload_end=base+(long)i;
            *next=base+(long)i+pat+2;
            *is_final=(a=='-'&&b=='-');
            return 1;
        }
        if(n<=keep)return 0;
        base+=(long)(n-keep);
        if(fseek(f,base,SEEK_SET)!=0)return 0;
    }
}
static int orca_part_headers(FILE *f,long start,long *data_offset,
                             char field[32],char filename[PATH_MAX_LOCAL]){
    char line[4096];int disposition=0;field[0]=filename[0]=0;
    if(fseek(f,start,SEEK_SET)!=0)return 0;
    for(int i=0;i<24;i++){
        if(!fgets(line,sizeof(line),f))return 0;
        size_t n=strlen(line);
        if(n<2||line[n-2]!='\r'||line[n-1]!='\n')return 0;
        if(n==2){*data_offset=ftell(f);return disposition;}
        if(!strncasecmp(line,"Content-Disposition:",20)){
            if(!strstr(line,"form-data"))return 0;
            const char *a=line;
            while((a=strstr(a,"name=\"")) && a>line && a[-1]!=';' && !isspace((unsigned char)a[-1]))a+=5;
            if(!a)return 0;
            a+=6;const char *end=strchr(a,'"');
            if(!end || (size_t)(end-a)>=32)return 0;
            memcpy(field,a,(size_t)(end-a));field[end-a]=0;
            const char *b=strstr(line,"filename=\"");
            if(b){
                b+=10;end=strchr(b,'"');
                if(!end || (size_t)(end-b)>=PATH_MAX_LOCAL)return 0;
                memcpy(filename,b,(size_t)(end-b));filename[end-b]=0;
            }
            disposition=1;
        }
    }
    return 0;
}
static void *orca_upload_worker(void *arg){
    gcode_upload_job *job=arg;
    const char *root=gcode_internal_root,*error="Invalid multipart upload";
    int status=400;const char *status_text="Bad Request";
    int output=-1,reserve=-1;
    char spool[PATH_MAX_LOCAL*2]="",temporary[PATH_MAX_LOCAL*2]="",destination[PATH_MAX_LOCAL*2]="";
    char filename[PATH_MAX_LOCAL]="",saved[PATH_MAX_LOCAL]="";
    int copy=0;
    FILE *input=NULL;
    size_t bytes=0;long file_start=-1,file_end=-1;
    char boundary[80];
    char reply[PATH_MAX_LOCAL*5];int reply_len=0;
    if(!gcode_storage_writable("internal",root)){status=507;status_text="Insufficient Storage";error="Internal storage unavailable";goto fail;}
    if(!orca_get_boundary((const char *)job->initial,boundary)){error="Missing multipart boundary";goto fail;}
    if(snprintf(spool,sizeof(spool),"%s/.cc2-orca-body-XXXXXX",root)>=(int)sizeof(spool)){error="Storage path too long";goto fail;}
    if(!upload_has_space(root,job->content_length,2)){status=507;status_text="Insufficient Storage";error="Insufficient free space for multipart upload";goto fail;}
    output=mkstemp(spool);
    if(output<0){status=507;status_text="Insufficient Storage";error="Cannot spool upload";goto fail;}
    bytes=job->initial_length-job->header_length;
    if(bytes>job->content_length){error="Invalid request body";goto fail;}
    {size_t off=0;while(off<bytes){ssize_t n=write(output,job->initial+job->header_length+off,bytes-off);
       if(n<0&&errno==EINTR)continue;
       if(n<=0){error="Cannot write upload";goto fail;}off+=(size_t)n;}}
    unsigned char chunk[UPLOAD_CHUNK];
    while(bytes<job->content_length){
        size_t want=job->content_length-bytes;
        if(want>sizeof(chunk))want=sizeof(chunk);
        ssize_t n=upload_receive(job,chunk,want);
        if(n<0&&errno==EINTR)continue;
        if(n<=0){if(n<0&&errno==ETIMEDOUT){status=408;status_text="Request Timeout";}error="Incomplete or timed out upload";goto fail;}
        size_t off=0;while(off<(size_t)n){ssize_t w=write(output,chunk+off,(size_t)n-off);
            if(w<0&&errno==EINTR)continue;
            if(w<=0){error="Cannot write upload";goto fail;}off+=(size_t)w;}
        bytes+=(size_t)n;
    }
    if(close(output)!=0){output=-1;error="Cannot close upload";goto fail;}output=-1;
    input=fopen(spool,"rb");if(!input){error="Cannot read upload";goto fail;}
    char first[96];int flen=snprintf(first,sizeof(first),"--%s\r\n",boundary);
    if(flen<=0||(size_t)flen>=sizeof(first)||fread(chunk,1,(size_t)flen,input)!=(size_t)flen||
       memcmp(chunk,first,(size_t)flen)){error="Invalid multipart opening";goto fail;}
    long pos=flen;
    int saw_file=0,print_requested=0;
    for(int part=0;part<16;part++){
        char field[32],partname[PATH_MAX_LOCAL];long start,end,next,final;
        if(!orca_part_headers(input,pos,&start,field,partname)||
           !orca_next_boundary(input,start,boundary,&end,&next,&final)||end<start){error="Invalid multipart part";goto fail;}
        if(!strcmp(field,"file")){
            if(saw_file || !orca_file_name_ok(partname) || end==start){error="Invalid or duplicate G-code file";goto fail;}
            snprintf(filename,sizeof(filename),"%s",partname);
            file_start=start;file_end=end;saw_file=1;
        }else if(!strcmp(field,"print") || !strcmp(field,"select")){
            if(end-start>16){error="Invalid print or select field";goto fail;}
            char value[20]={0};
            if(fseek(input,start,SEEK_SET)!=0||fread(value,1,(size_t)(end-start),input)!=(size_t)(end-start)){error="Cannot read multipart field";goto fail;}
            if(!strcmp(field,"print") && (!strcasecmp(value,"true")||!strcmp(value,"1")))print_requested=1;
        }else if(!strcmp(field,"path")){
            if(end>start){error="Upload subdirectories are not supported";goto fail;}
        }
        pos=next;
        if(final)break;
        if(part==15){error="Too many multipart fields";goto fail;}
    }
    if(!saw_file){error="Missing file field";goto fail;}
    if((unsigned long)(file_end-file_start)>FILE_UPLOAD_MAX){status=413;status_text="Payload Too Large";error="G-code file too large";goto fail;}
    if(print_requested){
        if(!gcode_idle_for_mutation(job->mqtt)){status=409;status_text="Conflict";error="Printer must be idle for upload-and-print";goto fail;}
        pthread_mutex_lock(&orca_pending_mutex);
        orca_pending_expire_locked();
        int occupied=orca_pending_filename[0]!=0;
        pthread_mutex_unlock(&orca_pending_mutex);
        if(occupied){status=409;status_text="Conflict";error="Another upload-and-print awaits Canvas confirmation";goto fail;}
    }
    if(snprintf(temporary,sizeof(temporary),"%s/.cc2-orca-file-XXXXXX",root)>=(int)sizeof(temporary)){error="Storage path too long";goto fail;}
    copy=orca_free_name(root,filename,0,saved,destination,sizeof(destination));
    if(copy==-2){error="Cannot inspect destination";goto fail;}
    if(copy<0){status=409;status_text="Conflict";error="File already exists";goto fail;}
    if(!upload_has_space(root,(size_t)(file_end-file_start),1)){status=507;status_text="Insufficient Storage";error="Insufficient free space for G-code file";goto fail;}
    output=mkstemp(temporary);
    if(output<0){status=507;status_text="Insufficient Storage";error="Cannot create G-code file";goto fail;}
    (void)fchmod(output,0644);
    if(fseek(input,file_start,SEEK_SET)!=0){error="Cannot seek file data";goto fail;}
    long left=file_end-file_start;
    while(left>0){if(!upload_seconds_left(job)){error="Upload deadline exceeded";goto fail;}size_t want=left>(long)sizeof(chunk)?sizeof(chunk):(size_t)left;
        if(fread(chunk,1,want,input)!=want){error="Cannot read file data";goto fail;}
        size_t off=0;while(off<want){ssize_t w=write(output,chunk+off,want-off);
            if(w<0&&errno==EINTR)continue;
            if(w<=0){status=507;status_text="Insufficient Storage";error="Cannot write G-code file";goto fail;}
            off+=(size_t)w;}
        left-=(long)want;
    }
    if(fsync(output)!=0 || close(output)!=0){output=-1;status=507;status_text="Insufficient Storage";error="Cannot finalize G-code file";goto fail;}output=-1;
    /* Recheck before publication; upload-only may continue during printing. */
    if(!(print_requested ? gcode_idle_for_mutation(job->mqtt) : gcode_ready_for_upload(job->mqtt))){status=409;status_text="Conflict";error="Printer state changed during upload";goto fail;}
    /* O_EXCL is the authoritative check: a name taken since the scan moves
     * the file on to the next free copy name. */
    while((reserve=open(destination,O_WRONLY|O_CREAT|O_EXCL,0600))<0){
        if(errno!=EEXIST){status=507;status_text="Insufficient Storage";error="Cannot reserve destination";goto fail;}
        copy=orca_free_name(root,filename,(unsigned)copy+1,saved,destination,sizeof(destination));
        if(copy==-2){error="Cannot inspect destination";goto fail;}
        if(copy<0){status=409;status_text="Conflict";error="File already exists";goto fail;}
    }
    close(reserve);reserve=-1;
    if(rename(temporary,destination)!=0){unlink(destination);status=507;status_text="Insufficient Storage";error="Cannot publish file";goto fail;}
    temporary[0]=0;
    layer_store_note(destination);
    unsigned long pending_generation=0;
    if(print_requested){
        pthread_mutex_lock(&orca_pending_mutex);
        orca_pending_expire_locked();
        if(orca_pending_filename[0]){
            pthread_mutex_unlock(&orca_pending_mutex);
            /* The file is safely uploaded; never silently print or replace an
             * unrelated pending operator confirmation. */
            error="Upload finished, but another print is awaiting Canvas confirmation";
            status=409;status_text="Conflict";goto fail;
        }
        snprintf(orca_pending_filename,sizeof(orca_pending_filename),"%s",saved);
        orca_pending_created=time(NULL);
        pending_generation=++orca_pending_generation;
        if(!pending_generation)pending_generation=++orca_pending_generation;
        pthread_mutex_unlock(&orca_pending_mutex);
    }
    {char safe_name[PATH_MAX_LOCAL*2];
     json_escape(safe_name,sizeof(safe_name),saved);
     int n=snprintf(reply,sizeof(reply),"{\"files\":{\"local\":{\"name\":\"%s\",\"origin\":\"local\",\"size\":%ld,\"refs\":{\"resource\":\"/api/files/local/%s\"}}},\"done\":true,\"uploaded\":true,\"printed\":false,\"awaiting_canvas\":%s,\"generation\":%lu}\n",safe_name,file_end-file_start,safe_name,print_requested?"true":"false",pending_generation);
     if(n>0&&(size_t)n<sizeof(reply)){reply_len=n;status=201;status_text="Created";}}
    goto cleanup;
fail:
    reply_len=snprintf(reply,sizeof(reply),"{\"error\":\"%s\"}\n",error);
cleanup:
    if(input)fclose(input);
    if(output>=0)close(output);
    if(reserve>=0)close(reserve);
    if(temporary[0])unlink(temporary);
    if(spool[0])unlink(spool);
    /* Free the upload slot before answering: OrcaSlicer may start its next
     * upload as soon as it reads this response. */
    upload_slot_release();
    if(reply_len>0&&(size_t)reply_len<sizeof(reply))
        respond(job->fd,status,status_text,"application/json",reply,(size_t)reply_len);
    close(job->fd);free(job);
    return NULL;
}
static int orca_expect_continue(const char *request){
    const char *p=request;
    while(*p){
        const char *e=strstr(p,"\r\n");
        if(!e || e==p)break;
        if((size_t)(e-p)>7 && !strncasecmp(p,"Expect:",7)){
            const char *v=p+7;
            while(v<e && (*v==' '||*v=='\t'))v++;
            return (size_t)(e-v)==12 && !strncasecmp(v,"100-continue",12);
        }
        p=e+2;
    }
    return 0;
}
static int orca_upload_start(int fd,const char *request,size_t used,size_t header_length,const mqtt_client *mqtt){
    if(!gcode_ready_for_upload(mqtt)){
        const char *msg="{\"error\":\"Printer must be idle or printing and connected\"}\n";
        respond(fd,409,"Conflict","application/json",msg,strlen(msg));return 0;
    }
    char boundary[80];
    if(!orca_get_boundary(request,boundary)){
        const char *msg="{\"error\":\"Expected multipart/form-data\"}\n";
        respond(fd,415,"Unsupported Media Type","application/json",msg,strlen(msg));return 0;
    }
    size_t length=content_length_from_headers(request);
    if(!length||length>FILE_UPLOAD_MAX+8192||header_length>used||used-header_length>length){
        const char *msg="{\"error\":\"Invalid upload length\"}\n";
        respond(fd,413,"Payload Too Large","application/json",msg,strlen(msg));return 0;
    }
    if(!upload_space_or_room(fd,mqtt,gcode_internal_root,length,2))return 0;
    if(!upload_slot_acquire()){
        const char *msg="{\"error\":\"Another upload is running\"}\n";
        respond(fd,409,"Conflict","application/json",msg,strlen(msg));return 0;
    }
    gcode_upload_job *job=calloc(1,sizeof(*job));
    if(!job){upload_slot_release();return 0;}
    clock_gettime(CLOCK_MONOTONIC,&job->started);
    job->fd=fd;job->initial_length=used;job->header_length=header_length;
    job->content_length=length;job->mqtt=mqtt;memcpy(job->initial,request,used);
    struct timeval timeout={20,0};
    setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    if(orca_expect_continue(request)){
        const char *interim="HTTP/1.1 100 Continue\r\n\r\n";
        if(send_all(fd,interim,strlen(interim))!=0){
            free(job);upload_slot_release();return 0;
        }
    }
    pthread_t worker;
    if(pthread_create(&worker,NULL,orca_upload_worker,job)!=0){
        free(job);upload_slot_release();return 0;
    }
    pthread_detach(worker);
    return 1;
}
static void orca_version_response(int fd){
    const char *body="{\"api\":\"0.1\",\"server\":\"1.11.0\",\"text\":\"OctoPrint 1.11.0 (CC2 Control compatibility)\"}\n";
    respond(fd,200,"OK","application/json",body,strlen(body));
}

static unsigned long gcode_path_hash(const char *text) {
    unsigned long hash = 2166136261UL;
    while (*text) {
        hash ^= (unsigned char)*text++;
        hash *= 16777619UL;
    }
    return hash & 0xffffffffUL;
}

/* USB printing on the touchscreen uses a private import stage.  Method 1020
 * reliably accepts local files, so mirror that workflow before publishing. */
/* The internal name a USB file is imported under: always the same for the same USB path. */
static int gcode_usb_import_name(const char *relative, char imported[PATH_MAX_LOCAL]) {
    const char *base = strrchr(relative, '/');
    base = base ? base + 1 : relative;
    char safe_base[241]; size_t used = 0;
    for (const unsigned char *cursor = (const unsigned char *)base;
         *cursor && used + 1 < sizeof(safe_base); ++cursor) {
        unsigned char value = *cursor;
        safe_base[used++] = (value == '/' || value == '\\' || value < 32) ? '_' : (char)value;
    }
    safe_base[used] = '\0';
    if (!is_gcode_filename(safe_base)) return -1;

    int length = snprintf(imported, PATH_MAX_LOCAL, GCODE_USB_IMPORT_PREFIX "%08lx_%s",
                          gcode_path_hash(relative), safe_base);
    return length < 0 || length >= PATH_MAX_LOCAL ? -1 : 0;
}

/* USB imports are kept for the touchscreen and for a restart of the same file, but not without
 * end: after a USB start only the newest GCODE_USB_IMPORTS_KEPT stay, the one just started among
 * them. An older copy is removed only where deleting it from the file list would be allowed
 * (gcode_delete_guard: never the running, paused or recoverable print, nothing while the printer
 * state is unclear or an upload or Orca start is pending) and no queued job names it. */
#define GCODE_USB_IMPORTS_KEPT 3
/* All USB imports together: above this the oldest go first, until the rest fits or only protected
 * copies and the one just started are left (which may exceed it on their own). A starting value. */
#define GCODE_USB_IMPORTS_MAX_BYTES (1024ULL * 1024 * 1024)
static unsigned long long gcode_usb_imports_max_bytes = GCODE_USB_IMPORTS_MAX_BYTES; /* test seam */
static int queue_uses_internal_file(const char *name); /* queue.h */
typedef struct { char name[256]; struct timespec mtime; unsigned long long size; int gone; } gcode_usb_import_entry;
static int gcode_usb_import_newer(const void *a, const void *b) {
    const gcode_usb_import_entry *x = a, *y = b;
    if (x->mtime.tv_sec != y->mtime.tv_sec) return x->mtime.tv_sec < y->mtime.tv_sec ? 1 : -1;
    if (x->mtime.tv_nsec != y->mtime.tv_nsec) return x->mtime.tv_nsec < y->mtime.tv_nsec ? 1 : -1;
    return strcmp(x->name, y->name);
}
/* Removes one older copy where the file list's delete guard allows it and no queued job names it. */
static int gcode_usb_import_remove(const mqtt_client *mqtt, const char *name) {
    if (gcode_delete_guard(mqtt, name) || queue_uses_internal_file(name)) return 0;
    char path[PATH_MAX_LOCAL * 2]; struct stat info;
    snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, name);
    /* As a delete from the file list: the same regular, singly linked file, or nothing. */
    if (lstat(path, &info) || !S_ISREG(info.st_mode) || info.st_nlink != 1 || unlink(path)) return 0;
    layer_store_forget(path); /* the copy's layer map goes with it */
    fprintf(stderr, "USB import cleanup: removed %s\n", name);
    return 1;
}
/* Returns the number of copies removed. */
static int gcode_usb_prune(const mqtt_client *mqtt, const char *keep) {
    DIR *dir = opendir(gcode_internal_root);
    if (!dir) return 0;
    gcode_usb_import_entry *found = NULL; size_t count = 0, cap = 0; struct dirent *entry;
    while ((entry = readdir(dir))) {
        size_t length = strlen(entry->d_name);
        if (strncmp(entry->d_name, GCODE_USB_IMPORT_PREFIX, strlen(GCODE_USB_IMPORT_PREFIX)) ||
            length >= sizeof(found->name) || !is_gcode_filename(entry->d_name)) continue;
        char path[PATH_MAX_LOCAL * 2]; struct stat info;
        if (snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, entry->d_name) >= (int)sizeof(path) ||
            lstat(path, &info) != 0 || !S_ISREG(info.st_mode)) continue;
        if (count == cap) {
            size_t next = cap ? cap * 2 : 16;
            gcode_usb_import_entry *grown = realloc(found, next * sizeof(*found));
            if (!grown) break;
            found = grown; cap = next;
        }
        snprintf(found[count].name, sizeof(found[count].name), "%s", entry->d_name);
        found[count].size = (unsigned long long)info.st_size; found[count].gone = 0;
        found[count++].mtime = info.st_mtim;
    }
    closedir(dir);
    if (count) qsort(found, count, sizeof(*found), gcode_usb_import_newer);
    int kept = keep && *keep ? 1 : 0, removed = 0;
    unsigned long long total = 0;
    for (size_t i = 0; i < count; i++) total += found[i].size;
    /* First the count: the newest three stay. */
    for (size_t i = 0; i < count; i++) {
        if (keep && !strcmp(found[i].name, keep)) continue;
        if (kept < GCODE_USB_IMPORTS_KEPT) { kept++; continue; }
        if (gcode_usb_import_remove(mqtt, found[i].name)) { found[i].gone = 1; total -= found[i].size; removed++; }
    }
    /* Then the size: oldest first while all copies together exceed the limit. */
    for (size_t i = count; i-- > 0 && total > gcode_usb_imports_max_bytes;) {
        if (found[i].gone || (keep && !strcmp(found[i].name, keep))) continue;
        if (gcode_usb_import_remove(mqtt, found[i].name)) { found[i].gone = 1; total -= found[i].size; removed++; }
    }
    free(found);
    return removed;
}

/* Removes the CC2_USB_*.part files a copy leaves behind when CC2 Control ends during it (update, crash, power
 * loss; procd starts it again at once, so such a file is fresh). A running copy holds an flock on its .part
 * until it is renamed or removed (gcode_import_usb), and the kernel drops that lock when the process ends,
 * however it ends; so a .part without a lock has no copy behind it, whatever its age, and one with a lock is a
 * running copy, also of another instance on the same folders. Only regular, singly linked files. Runs at start
 * and before every USB copy (on the worker, before its own copy). */
static int gcode_usb_part_cleanup(void) {
    DIR *dir = opendir(gcode_internal_root);
    if (!dir) return 0;
    int removed = 0; struct dirent *entry;
    while ((entry = readdir(dir))) {
        size_t length = strlen(entry->d_name);
        if (strncmp(entry->d_name, GCODE_USB_IMPORT_PREFIX, strlen(GCODE_USB_IMPORT_PREFIX)) ||
            length < 5 || strcmp(entry->d_name + length - 5, ".part")) continue;
        char path[PATH_MAX_LOCAL * 2]; struct stat info, held;
        if (snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, entry->d_name) >= (int)sizeof(path) ||
            lstat(path, &info) || !S_ISREG(info.st_mode) || info.st_nlink != 1) continue;
        int fd = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK);
        if (fd < 0) continue;
        /* The same file as listed, and no copy holds it: removed while this lock keeps a new copy off it. */
        if (!fstat(fd, &held) && held.st_dev == info.st_dev && held.st_ino == info.st_ino &&
            !flock(fd, LOCK_EX | LOCK_NB) && !lstat(path, &info) && info.st_ino == held.st_ino &&
            info.st_dev == held.st_dev && !unlink(path)) {
            fprintf(stderr, "USB import cleanup: removed leftover %s\n", entry->d_name);
            removed++;
        }
        close(fd);
    }
    closedir(dir);
    return removed;
}

/* Why an import was not completed; the start answers each one with its own message. */
enum { GCODE_IMPORT_FAILED = -1, GCODE_IMPORT_NO_SPACE = -2, GCODE_IMPORT_CHANGED = -3,
       GCODE_IMPORT_UNVERIFIED = -4, GCODE_IMPORT_CANCELLED = -5 };
/* The USB file as it was before it was scanned: the copy must be of that same file. */
typedef struct { int known; off_t size; dev_t dev; ino_t ino; struct timespec mtime; } gcode_source_stamp;
static void gcode_source_stamp_of(gcode_source_stamp *stamp, const struct stat *info) {
    stamp->known = 1; stamp->size = info->st_size; stamp->dev = info->st_dev; stamp->ino = info->st_ino;
    stamp->mtime = info->st_mtim;
}
static int gcode_source_stamp_same(const gcode_source_stamp *a, const gcode_source_stamp *b) {
    return a->size == b->size && a->dev == b->dev && a->ino == b->ino &&
           a->mtime.tv_sec == b->mtime.tv_sec && a->mtime.tv_nsec == b->mtime.tv_nsec;
}
static int usb_import_has_space(uint64_t size, uint64_t replaced) {
    struct statvfs st;
    if (upload_statvfs(gcode_internal_root, &st)) return 0;
    uint64_t block = st.f_frsize ? st.f_frsize : st.f_bsize;
    if (!block) return 0;
    uint64_t available = st.f_bavail > UINT64_MAX / block ? UINT64_MAX : (uint64_t)st.f_bavail * block;
    uint64_t reserve = replaced >= UPLOAD_STORAGE_MARGIN ? 0 : UPLOAD_STORAGE_MARGIN - replaced;
    return available >= size && available - size >= reserve;
}
/* Room for a new USB copy of `size` bytes: when it does not fit, the oldest older copies go first (as the
 * cleanup after a start would remove them, gcode_usb_import_remove), but only when removing all of them
 * that may go would be enough; otherwise nothing is removed and the start is refused for lack of space.
 * `name` is the new copy's own name: an earlier copy of it is replaced, not removed. Main loop only. */
static void gcode_usb_make_room(const mqtt_client *mqtt, uint64_t size, const char *name) {
    char path[PATH_MAX_LOCAL * 2]; struct stat earlier;
    snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, name);
    uint64_t replaced = lstat(path, &earlier) == 0 && S_ISREG(earlier.st_mode) ? (uint64_t)earlier.st_size : 0;
    if (usb_import_has_space(size, replaced)) return;
    DIR *dir = opendir(gcode_internal_root);
    if (!dir) return;
    gcode_usb_import_entry *found = NULL; size_t count = 0, cap = 0; struct dirent *entry;
    unsigned long long removable = 0;
    while ((entry = readdir(dir))) {
        if (strncmp(entry->d_name, GCODE_USB_IMPORT_PREFIX, strlen(GCODE_USB_IMPORT_PREFIX)) ||
            strlen(entry->d_name) >= sizeof(found->name) || !is_gcode_filename(entry->d_name) ||
            !strcmp(entry->d_name, name)) continue;
        struct stat info;
        if (snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, entry->d_name) >= (int)sizeof(path) ||
            lstat(path, &info) || !S_ISREG(info.st_mode) || info.st_nlink != 1 ||
            gcode_delete_guard(mqtt, entry->d_name) || queue_uses_internal_file(entry->d_name)) continue;
        if (count == cap) {
            size_t next = cap ? cap * 2 : 16;
            gcode_usb_import_entry *grown = realloc(found, next * sizeof(*found));
            if (!grown) break;
            found = grown; cap = next;
        }
        snprintf(found[count].name, sizeof(found[count].name), "%s", entry->d_name);
        found[count].size = (unsigned long long)info.st_size; found[count].gone = 0;
        found[count++].mtime = info.st_mtim;
        removable += (unsigned long long)info.st_size;
    }
    closedir(dir);
    struct statvfs st; uint64_t block;
    if (!upload_statvfs(gcode_internal_root, &st) && (block = st.f_frsize ? st.f_frsize : st.f_bsize)) {
        uint64_t available = (uint64_t)st.f_bavail * block + removable;
        uint64_t reserve = replaced >= UPLOAD_STORAGE_MARGIN ? 0 : UPLOAD_STORAGE_MARGIN - replaced;
        if (available >= size && available - size >= reserve) {
            if (count) qsort(found, count, sizeof(*found), gcode_usb_import_newer);
            for (size_t i = count; i-- > 0 && !usb_import_has_space(size, replaced);)
                (void)gcode_usb_import_remove(mqtt, found[i].name);
        }
    }
    free(found);
}
/* FNV-1a, 64 bit: detects a copy that reads back different from the bytes read from the stick. */
static uint64_t gcode_copy_hash(uint64_t hash, const unsigned char *bytes, size_t length) {
    while (length--) { hash ^= *bytes++; hash *= 1099511628211ULL; }
    return hash;
}
#define GCODE_COPY_HASH_SEED 14695981039346656037ULL
/* A USB start copies on its worker thread at normal priority, without pauses: every USB_COPY_FLUSH_BYTES
 * it writes the copy out and drops those pages of source and copy from the cache, so the copy does not
 * pile up unwritten data in the printer's memory. The read back drops its pages the same way, every
 * USB_COPY_FLUSH_BYTES and at the end; the scan before the copy goes through the cache as any read does. Earlier versions also paused after every
 * block and lowered the worker's priority; the lowered priority also slowed the scan of internal starts,
 * and the printer's mq-deadline scheduler ignores I/O priorities. A start without the worker
 * (gcode_start_run without `usb`; the program no longer starts a USB file that way) is not written out
 * early. */
#define USB_COPY_FLUSH_BYTES ((size_t)8 << 20)
/* For tests, about the last import: early write-outs, bytes dropped from the cache. */
static unsigned long usb_copy_flushes;
static size_t usb_copy_dropped_in, usb_copy_dropped_out;
static int usb_copy_readback_dropped; /* drops during and after the read back */
/* Writes bytes [from, to) of the copy to storage and waits for them, then drops them and the same range
 * of the source from the cache. A failed write-out fails the copy, as the final fsync would. */
static int usb_copy_write_out(FILE *output, FILE *input, size_t from, size_t to) {
    if (fflush(output) != 0) return -1;
    int fd = fileno(output); off_t start = (off_t)from, length = (off_t)(to - from);
#ifdef SYNC_FILE_RANGE_WRITE
    if (sync_file_range(fd, start, length,
                        SYNC_FILE_RANGE_WAIT_BEFORE | SYNC_FILE_RANGE_WRITE | SYNC_FILE_RANGE_WAIT_AFTER) != 0 &&
        fdatasync(fd) != 0)
        return -1;
#else
    if (fdatasync(fd) != 0) return -1;
#endif
    if (posix_fadvise(fd, start, length, POSIX_FADV_DONTNEED) == 0) usb_copy_dropped_out += to - from;
    if (posix_fadvise(fileno(input), start, length, POSIX_FADV_DONTNEED) == 0) usb_copy_dropped_in += to - from;
    usb_copy_flushes++;
    return 0;
}
/* Test seams: after each block written (with the bytes copied so far), and after the copy was synced. */
static void (*usb_copy_block_hook)(size_t copied);
static void (*usb_copy_synced_hook)(const char *path);
/* Heartbeat of the start worker: set on every block it reads or writes and on every round of its waits, so the
 * main loop sees a worker that stands still (a USB stick that stops answering inside fread, Fund 4). */
static long long monotonic_ms(void);
static atomic_llong usb_start_beat;
static void usb_start_beat_now(void) { atomic_store(&usb_start_beat, monotonic_ms()); }
static void usb_start_nap(long ms) { usb_start_beat_now(); nanosleep(&(struct timespec){0, ms * 1000000L}, NULL); }
/* Set by the start worker when a read of the file came back with an error (the copy, or a scan before it): after a
 * read that stopped answering (reason usb_unresponsive) it tells a stick that failed from one that was only slow.
 * It is noted before the cancel is checked, so a read that ends after the browser was answered still counts. */
static atomic_int usb_start_read_failed;
/* Test seam: called after each block of the one-pass scan (0) and of the read back (1). */
static void (*usb_read_block_hook)(int phase);

/* One line of the tool scan and of the adaptive-mesh scan. The file scans below (fgets with 2048 and
 * 4096 bytes) and the scan that runs along with a USB copy cut lines the same way and call these, so
 * both reach the same decision for the same bytes. */
static void gcode_filament_lengths(const char *comment, double lengths[GCODE_TOOLS_MAX]);
#define GCODE_TOOLS_LINE 2048
#define GCODE_MESH_LINE 4096
static void gcode_tools_line(char *line, int present[GCODE_TOOLS_MAX], double *lengths) {
    char *comment = strchr(line, ';');
    if (comment) {
        if (lengths) gcode_filament_lengths(comment, lengths);
        *comment = '\0';
    }
    for (char *cursor = line; *cursor; ++cursor) {
        if ((*cursor != 'T' && *cursor != 't') ||
            (cursor != line && !isspace((unsigned char)cursor[-1]))) continue;
        char *number = cursor + 1, *end = number;
        if (!isdigit((unsigned char)*number)) continue;
        long tool = strtol(number, &end, 10);
        if (tool < 0 || tool >= GCODE_TOOLS_MAX) continue;
        if (*end && !isspace((unsigned char)*end) && *end != '*') continue;
        present[tool] = 1;
        cursor = end - 1;
    }
}
static int gcode_mesh_line(const char *line) {
    char upper[GCODE_MESH_LINE]; size_t index = 0;
    for (; line[index] && index + 1 < sizeof(upper); ++index)
        upper[index] = (char)toupper((unsigned char)line[index]);
    upper[index] = '\0';
    char *comment = strchr(upper, ';');
    if (comment) *comment = '\0';
    return strstr(upper, "BED_MESH_CALIBRATE") &&
           (strstr(upper, "FROM_SLICER=1") ||
            (strstr(upper, "MESH_MIN=") && strstr(upper, "MESH_MAX=")) ||
            strstr(upper, "ADAPTIVE=1"));
}
/* The tools present, in ascending order; tool 0 when none is named (as the file scan reports). */
static void gcode_tools_list(const int present[GCODE_TOOLS_MAX], int tools[GCODE_TOOLS_MAX], size_t *count) {
    *count = 0;
    for (int tool = 0; tool < GCODE_TOOLS_MAX; ++tool)
        if (present[tool]) tools[(*count)++] = tool;
    if (!*count) tools[(*count)++] = 0;
}
/* Both scans over bytes as they are copied, lines cut exactly as fgets cuts them: a line ends after
 * its newline or after size - 1 bytes. */
typedef struct {
    char mesh[GCODE_MESH_LINE]; size_t mesh_used; int adaptive;
    char tools[GCODE_TOOLS_LINE]; size_t tools_used; int present[GCODE_TOOLS_MAX];
} gcode_stream_scan;
static void gcode_stream_scan_byte(gcode_stream_scan *scan, char byte) {
    scan->mesh[scan->mesh_used++] = byte;
    if (byte == '\n' || scan->mesh_used == sizeof(scan->mesh) - 1) {
        scan->mesh[scan->mesh_used] = '\0';
        if (!scan->adaptive && gcode_mesh_line(scan->mesh)) scan->adaptive = 1;
        scan->mesh_used = 0;
    }
    scan->tools[scan->tools_used++] = byte;
    if (byte == '\n' || scan->tools_used == sizeof(scan->tools) - 1) {
        scan->tools[scan->tools_used] = '\0';
        gcode_tools_line(scan->tools, scan->present, NULL);
        scan->tools_used = 0;
    }
}
static void gcode_stream_scan_feed(gcode_stream_scan *scan, const char *bytes, size_t length) {
    for (size_t i = 0; i < length; i++) gcode_stream_scan_byte(scan, bytes[i]);
}
static void gcode_stream_scan_finish(gcode_stream_scan *scan) {
    if (scan->mesh_used) {
        scan->mesh[scan->mesh_used] = '\0';
        if (!scan->adaptive && gcode_mesh_line(scan->mesh)) scan->adaptive = 1;
        scan->mesh_used = 0;
    }
    if (scan->tools_used) {
        scan->tools[scan->tools_used] = '\0';
        gcode_tools_line(scan->tools, scan->present, NULL);
        scan->tools_used = 0;
    }
}
/* The decision a USB start took before the copy, from the cached file analysis; the copy scans
 * along and must reach the same one, or it is not printed. */
typedef struct { int adaptive; int tools[GCODE_TOOLS_MAX]; size_t tool_count; } gcode_scan_expect;
static int gcode_stream_scan_matches(const gcode_stream_scan *scan, const gcode_scan_expect *expect) {
    int tools[GCODE_TOOLS_MAX]; size_t count;
    gcode_tools_list(scan->present, tools, &count);
    return !scan->adaptive == !expect->adaptive && count == expect->tool_count &&
           !memcmp(tools, expect->tools, count * sizeof(tools[0]));
}

/* Copies a USB file into internal memory as <imported>. The copy needs room for itself and the
 * upload reserve, is read back from storage and compared with the bytes read from the stick, and
 * is published (renamed from .part) only when it matches. `expected`, when set, is the file as it
 * was before the scan: a different or changed file is not copied. `cancel`, when set, stops the
 * copy after the current block and the read back after the current block. Returns 0 or a GCODE_IMPORT_* reason; nothing is left behind on
 * failure, and an earlier import of the same name stays as it was. */
static int gcode_import_usb(const char *relative, char imported[PATH_MAX_LOCAL],
                            const gcode_source_stamp *expected, const atomic_int *cancel,
                            size_t *copied_out, int write_out, const gcode_scan_expect *decided,
                            int *unpublished) {
    char source[PATH_MAX_LOCAL * 2], destination[PATH_MAX_LOCAL * 2];
    char temporary[PATH_MAX_LOCAL * 2];
    if (copied_out) *copied_out = 0;
    usb_copy_flushes = 0; usb_copy_dropped_in = usb_copy_dropped_out = 0;
    if (!gcode_resolved_path(gcode_usb_root, relative, source, sizeof(source))) return GCODE_IMPORT_FAILED;
    if (gcode_usb_import_name(relative, imported) != 0) return GCODE_IMPORT_FAILED;
    int length = snprintf(destination, sizeof(destination), "%s/%s",
                      gcode_internal_root, imported);
    if (length < 0 || (size_t)length >= sizeof(destination)) return GCODE_IMPORT_FAILED;
    length = snprintf(temporary, sizeof(temporary), "%s.part", destination);
    if (length < 0 || (size_t)length >= sizeof(temporary)) return GCODE_IMPORT_FAILED;

    FILE *input = fopen(source, "rb");
    if (!input) return GCODE_IMPORT_FAILED;
    struct stat info; gcode_source_stamp opened, closed;
    if (fstat(fileno(input), &info) != 0 || !S_ISREG(info.st_mode) || info.st_size < 0 ||
        (uintmax_t)info.st_size > SIZE_MAX) { fclose(input); return GCODE_IMPORT_FAILED; }
    gcode_source_stamp_of(&opened, &info);
    if (expected && expected->known && !gcode_source_stamp_same(expected, &opened)) {
        fclose(input); return GCODE_IMPORT_CHANGED;
    }
    /* Room for the copy, and the storage reserve uploads keep once it is in place. An earlier import
     * of the same name is replaced by the rename only after the copy, so it counts towards the
     * reserve, not towards the room the copy needs while it is written. */
    struct stat earlier;
    off_t replaced = lstat(destination, &earlier) == 0 && S_ISREG(earlier.st_mode) ? earlier.st_size : 0;
    if (!usb_import_has_space((uint64_t)info.st_size, (uint64_t)replaced)) { fclose(input); return GCODE_IMPORT_NO_SPACE; }
    if (cancel && atomic_load(cancel)) { fclose(input); return GCODE_IMPORT_CANCELLED; }
    /* The .part is locked before it is emptied and stays locked until it is renamed or removed (part_lock
     * keeps the lock past fclose): gcode_usb_part_cleanup leaves a locked .part alone, and a copy of the same
     * file still running in another instance is not overwritten. */
    int part_fd = open(temporary, O_WRONLY | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0644);
    if (part_fd < 0) { fclose(input); return GCODE_IMPORT_FAILED; }
    if (flock(part_fd, LOCK_EX | LOCK_NB) || ftruncate(part_fd, 0)) { close(part_fd); fclose(input); return GCODE_IMPORT_FAILED; }
    int part_lock = dup(part_fd);
    FILE *output = part_lock < 0 ? NULL : fdopen(part_fd, "wb");
    if (!output) { if (part_lock >= 0) close(part_lock); close(part_fd); fclose(input); return GCODE_IMPORT_FAILED; }
    char buffer[65536]; int result = 0; size_t copied = 0, written_out = 0;
    uint64_t hash = GCODE_COPY_HASH_SEED;
    /* On the heap, not in thread-local storage: glibc places static TLS on every thread's stack,
     * which leaves the 64 KiB download and history workers too little to start. */
    gcode_stream_scan *scan = decided ? calloc(1, sizeof(*scan)) : NULL;
    if (decided && !scan) result = GCODE_IMPORT_FAILED;
    while (!result) {
        size_t count = fread(buffer, 1, sizeof(buffer), input);
        if (cancel && count < sizeof(buffer) && ferror(input)) atomic_store(&usb_start_read_failed, 1);
        if (count && fwrite(buffer, 1, count, output) != count) { result = GCODE_IMPORT_FAILED; break; }
        copied += count;
        hash = gcode_copy_hash(hash, (const unsigned char *)buffer, count);
        if (decided) gcode_stream_scan_feed(scan, buffer, count);
        if (usb_copy_block_hook) usb_copy_block_hook(copied);
        if (cancel) usb_start_beat_now();
        if (cancel && atomic_load(cancel)) { result = GCODE_IMPORT_CANCELLED; break; }
        if (count < sizeof(buffer)) {
            if (ferror(input)) result = GCODE_IMPORT_FAILED;
            break;
        }
        if (write_out && copied - written_out >= USB_COPY_FLUSH_BYTES) {
            if (usb_copy_write_out(output, input, written_out, copied) != 0) { result = GCODE_IMPORT_FAILED; break; }
            written_out = copied;
            if (cancel) usb_start_beat_now();
            if (cancel && atomic_load(cancel)) { result = GCODE_IMPORT_CANCELLED; break; }
        }
    }
    if (copied_out) *copied_out = copied;
    /* A file shortened, grown or rewritten while it was copied is not the file that was scanned. */
    /* A start decided from the cached analysis: the copied bytes must give the same decision. */
    if (!result && decided) {
        gcode_stream_scan_finish(scan);
        if (!gcode_stream_scan_matches(scan, decided)) result = GCODE_IMPORT_CHANGED;
    }
    free(scan);
    if (!result) {
        if (fstat(fileno(input), &info) != 0) result = GCODE_IMPORT_FAILED;
        else {
            gcode_source_stamp_of(&closed, &info);
            if (!gcode_source_stamp_same(&opened, &closed) || (uintmax_t)copied != (uintmax_t)opened.size)
                result = GCODE_IMPORT_CHANGED;
        }
    }
    if (!result && fflush(output) != 0) result = GCODE_IMPORT_FAILED;
    if (!result && fsync(fileno(output)) != 0) result = GCODE_IMPORT_FAILED;
    if (cancel) usb_start_beat_now();
    /* Drop the synced pages, so the read back below comes from storage where the kernel allows it. */
    if (!result) (void)posix_fadvise(fileno(output), 0, 0, POSIX_FADV_DONTNEED);
    if (!result && write_out) (void)posix_fadvise(fileno(input), 0, 0, POSIX_FADV_DONTNEED); /* the rest of the source */
    if (fclose(output) != 0 && !result) result = GCODE_IMPORT_FAILED;
    fclose(input);
    if (!result) {
        if (usb_copy_synced_hook) usb_copy_synced_hook(temporary);
        FILE *check = fopen(temporary, "rb");
        uint64_t back = GCODE_COPY_HASH_SEED; size_t read_back = 0, dropped_at = 0; size_t count;
        if (cancel && atomic_load(cancel)) result = GCODE_IMPORT_CANCELLED;
        else if (!check) result = GCODE_IMPORT_UNVERIFIED;
        else {
            while ((count = fread(buffer, 1, sizeof(buffer), check)) > 0) {
                if (cancel) usb_start_beat_now();
                if (cancel && atomic_load(cancel)) { result = GCODE_IMPORT_CANCELLED; break; }
                read_back += count;
                back = gcode_copy_hash(back, (const unsigned char *)buffer, count);
                if (usb_read_block_hook) usb_read_block_hook(1);
                /* Every USB_COPY_FLUSH_BYTES the pages read back so far leave the cache again. */
                if (write_out && read_back - dropped_at >= USB_COPY_FLUSH_BYTES) {
                    if (posix_fadvise(fileno(check), (off_t)dropped_at, (off_t)(read_back - dropped_at),
                                      POSIX_FADV_DONTNEED) == 0) usb_copy_readback_dropped++;
                    dropped_at = read_back;
                }
            }
            if (!result && (ferror(check) || read_back != copied || back != hash)) result = GCODE_IMPORT_UNVERIFIED;
        }
        /* And the rest at the end, so the read back never fills the cache with the whole copy. */
        if (check) {
            if (write_out && posix_fadvise(fileno(check), 0, 0, POSIX_FADV_DONTNEED) == 0) usb_copy_readback_dropped++;
            fclose(check);
        }
    }
    /* `unpublished`: the verified copy stays the locked .part, and the caller publishes it (usb_start_publish) only
     * right before the start is sent, so it never replaces an earlier copy under a print started meanwhile. */
    if (!result && unpublished) { *unpublished = part_lock; return 0; }
    if (result || rename(temporary, destination) != 0) {
        unlink(temporary);
        close(part_lock);
        return result ? result : GCODE_IMPORT_FAILED;
    }
    close(part_lock);
    chmod(destination, 0644);
    layer_store_note(destination);
    return 0;
}

/* "; filament used [mm] = a, b, ...": the slicer's length per tool (OrcaSlicer and
 * PrusaSlicer write it near the end). A later line replaces an earlier one. */
static void gcode_filament_lengths(const char *comment, double lengths[GCODE_TOOLS_MAX]) {
    static const char marker[] = "filament used [mm]";
    double values[GCODE_TOOLS_MAX];
    int count = 0;
    for (comment++; *comment == ' ' || *comment == '\t'; comment++) {}
    if (strncmp(comment, marker, sizeof(marker) - 1)) return;
    for (comment += sizeof(marker) - 1; *comment == ' ' || *comment == '\t'; comment++) {}
    if (*comment++ != '=') return;
    while (count < GCODE_TOOLS_MAX) {
        char *end; errno = 0;
        double value = strtod(comment, &end);
        if (end == comment || errno || !isfinite(value) || value < 0 || value > 1e9) return;
        values[count++] = value;
        while (*end == ' ' || *end == '\t') end++;
        if (*end != ',') { if (*end && *end != '\r' && *end != '\n') return; break; }
        comment = end + 1;
    }
    for (int tool = 0; tool < GCODE_TOOLS_MAX; ++tool) lengths[tool] = tool < count ? values[tool] : -1;
}

/* `lengths`, when given, receives each tool's slicer filament length in mm, or -1. */
/* Set on the start worker: a scan ends early (as failed) once the start was cancelled. */
static _Thread_local const atomic_int *gcode_scan_cancel;
/* Test seams: full passes over a G-code file by the start checks; whether the read back dropped the copy. */
static atomic_int gcode_scan_passes;

static void gcode_scan_read_error(FILE *file) {
    if (gcode_scan_cancel && ferror(file)) atomic_store(&usb_start_read_failed, 1); /* only on the start worker */
}
static int gcode_scan_cancelled(void) {
    if (gcode_scan_cancel) usb_start_beat_now(); /* only the start worker sets gcode_scan_cancel */
    return gcode_scan_cancel && atomic_load(gcode_scan_cancel);
}
static int gcode_detect_tools(const char *root, const char *relative,
                              int tools[GCODE_TOOLS_MAX], size_t *tool_count, double *lengths) {
    char path[PATH_MAX_LOCAL * 2], line[GCODE_TOOLS_LINE];
    if (!gcode_resolved_path(root, relative, path, sizeof(path))) return -1;
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    int present[GCODE_TOOLS_MAX] = {0};
    if (lengths) for (int tool = 0; tool < GCODE_TOOLS_MAX; ++tool) lengths[tool] = -1;
    atomic_fetch_add(&gcode_scan_passes, 1);
    int failed = 0;
    while (fgets(line, sizeof(line), file)) {
        if (gcode_scan_cancelled()) { failed = 1; break; }
        gcode_tools_line(line, present, lengths);
    }
    failed |= ferror(file);
    gcode_scan_read_error(file);
    fclose(file);
    if (failed) return -1;
    gcode_tools_list(present, tools, tool_count);
    return 0;
}

/* Slicer filament lists use tool indices, not physical Canvas slot indices.
 * Read bounded comment metadata only; never interpret it as commands. */
typedef struct { char color[10]; char material[65]; } gcode_filament_info;

#define GCODE_FILAMENT_SCAN_BYTES (256L * 1024)

static void gcode_scan_filaments(FILE *file, size_t budget,
                                 gcode_filament_info info[GCODE_TOOLS_MAX]) {
    char line[4096];
    size_t scanned = 0;
    while (scanned < budget && fgets(line, sizeof(line), file)) {
        scanned += strlen(line);
        /* Discard truncated lines rather than assigning partial metadata. */
        if (!strchr(line, '\n') && !feof(file)) {
            int ch; while (scanned < budget && (ch = fgetc(file)) != EOF && ch != '\n') scanned++;
            continue;
        }
        char *cursor = line;
        while (isspace((unsigned char)*cursor)) cursor++;
        if (*cursor++ != ';') continue;
        while (isspace((unsigned char)*cursor)) cursor++;
        char *equals = strchr(cursor, '=');
        if (!equals) continue;
        char *key_end = equals;
        while (key_end > cursor && isspace((unsigned char)key_end[-1])) key_end--;
        *key_end = '\0';
        int color = strcmp(cursor, "filament_colour") == 0 || strcmp(cursor, "filament_color") == 0;
        if (!color && strcmp(cursor, "filament_type") != 0) continue;
        cursor = equals + 1;
        for (int tool = 0; tool < GCODE_TOOLS_MAX; tool++) {
            char *end = strpbrk(cursor, ";,\r\n");
            if (!end) end = cursor + strlen(cursor);
            char *next = (*end == ';' || *end == ',') ? end + 1 : NULL;
            while (cursor < end && isspace((unsigned char)*cursor)) cursor++;
            while (end > cursor && isspace((unsigned char)end[-1])) end--;
            if (end - cursor >= 2 && *cursor == '"' && end[-1] == '"') { cursor++; end--; }
            size_t length = (size_t)(end - cursor);
            if (color) {
                int valid = (length == 7 || length == 9) && *cursor == '#';
                for (size_t i = 1; valid && i < length; i++) valid = isxdigit((unsigned char)cursor[i]);
                if (valid) { memcpy(info[tool].color, cursor, length); info[tool].color[length] = '\0'; }
            } else if (length && length < sizeof(info[tool].material)) {
                memcpy(info[tool].material, cursor, length); info[tool].material[length] = '\0';
            }
            if (!next) break;
            cursor = next;
        }
    }
}

static int gcode_read_filaments(const char *root, const char *relative,
                                gcode_filament_info info[GCODE_TOOLS_MAX]) {
    char path[PATH_MAX_LOCAL * 2];
    memset(info, 0, sizeof(*info) * GCODE_TOOLS_MAX);
    if (!gcode_resolved_path(root, relative, path, sizeof(path))) return -1;
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    gcode_scan_filaments(file, GCODE_FILAMENT_SCAN_BYTES, info);
    int failed = ferror(file);
    /* Orca/Prusa-style config comments can follow the entire print. Seek to a
     * bounded footer rather than scanning large files again. Later valid values
     * take precedence, and a partial first line is never treated as metadata. */
    if (!failed && fseeko(file, 0, SEEK_END) == 0) { /* off_t: files over 2 GiB on the 32-bit printer */
        off_t size = ftello(file);
        if (size > GCODE_FILAMENT_SCAN_BYTES) {
            off_t start = size - GCODE_FILAMENT_SCAN_BYTES;
            if (start < GCODE_FILAMENT_SCAN_BYTES) start = GCODE_FILAMENT_SCAN_BYTES;
            if (fseeko(file, start - 1, SEEK_SET) != 0) failed = 1;
            else {
                int ch = fgetc(file);
                if (ch != '\n') {
                    while ((ch = fgetc(file)) != EOF && ch != '\n') {}
                }
                off_t position = ftello(file);
                if (position < 0) failed = 1;
                else if (position < size) gcode_scan_filaments(file, (size_t)(size - position), info);
            }
        } else if (size < 0) failed = 1;
    } else if (!failed) failed = 1;
    failed |= ferror(file);
    fclose(file);
    return failed ? -1 : 0;
}

/* The first-layer bed temperature (the first M190/M140 with S above 0) and the
 * slicer's nozzle diameter (its configuration block at the end of the file).
 * Either stays -1 when the file does not state it. */
static int gcode_read_setup(const char *root, const char *relative, double *bed, double *nozzle) {
    char path[PATH_MAX_LOCAL * 2], line[4096];
    *bed = -1; *nozzle = -1;
    if (!gcode_resolved_path(root, relative, path, sizeof(path))) return -1;
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    size_t scanned = 0;
    while (*bed < 0 && scanned < 4 * 1024 * 1024 && fgets(line, sizeof(line), file)) {
        scanned += strlen(line);
        const char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if ((p[0] != 'M' && p[0] != 'm') || (strncmp(p + 1, "190", 3) && strncmp(p + 1, "140", 3)) ||
            (p[4] != ' ' && p[4] != '\t')) continue;
        for (p += 4; *p && *p != ';'; p++) {
            if ((*p != 'S' && *p != 's') || (p[-1] != ' ' && p[-1] != '\t')) continue;
            char *end; double value = strtod(p + 1, &end);
            if (end != p + 1 && isfinite(value) && value > 0 && value <= 200) *bed = value;
            break;
        }
    }
    off_t size = fseeko(file, 0, SEEK_END) == 0 ? ftello(file) : -1; /* files over 2 GiB on the 32-bit printer */
    if (size > 0 && fseeko(file, size > 256 * 1024 ? size - 256 * 1024 : 0, SEEK_SET) == 0) {
        if (size > 256 * 1024 && !fgets(line, sizeof(line), file)) line[0] = 0; /* skip a partial line */
        while (fgets(line, sizeof(line), file)) {
            const char *p = line;
            while (*p == ' ' || *p == '\t') p++;
            if (*p++ != ';') continue;
            while (*p == ' ' || *p == '\t') p++;
            if (strncmp(p, "nozzle_diameter", 15)) continue;
            for (p += 15; *p == ' ' || *p == '\t'; p++) {}
            if (*p++ != '=') continue;
            char *end; double value = strtod(p, &end);
            if (end != p && isfinite(value) && value >= 0.1 && value <= 2.0) *nozzle = value;
        }
    }
    int failed = ferror(file); fclose(file);
    return failed ? -1 : 0;
}

static int gcode_has_adaptive_mesh(const char *root, const char *relative, int *adaptive) {
    char path[PATH_MAX_LOCAL * 2], line[GCODE_MESH_LINE];
    if (!adaptive || !gcode_resolved_path(root, relative, path, sizeof(path))) return -1;
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    *adaptive = 0;
    atomic_fetch_add(&gcode_scan_passes, 1);
    int failed = 0;
    while (fgets(line, sizeof(line), file)) {
        if (gcode_scan_cancelled()) { failed = 1; break; }
        if (gcode_mesh_line(line)) {
            *adaptive = 1;
            break;
        }
    }
    failed |= ferror(file);
    gcode_scan_read_error(file);
    fclose(file);
    return failed ? -1 : 0;
}

/* The mesh and the tool check in one pass, lines cut as the two fgets scans cut them (gcode_stream_scan).
 * For the start worker; ends as failed on a cancel. */
static int gcode_scan_both(const char *root, const char *relative, int *adaptive,
                           int tools[GCODE_TOOLS_MAX], size_t *tool_count) {
    char path[PATH_MAX_LOCAL * 2];
    if (!gcode_resolved_path(root, relative, path, sizeof(path))) return -1;
    FILE *file = fopen(path, "rb");
    if (!file) return -1;
    atomic_fetch_add(&gcode_scan_passes, 1);
    /* On the heap, not in thread-local storage (see gcode_import_usb). */
    struct { gcode_stream_scan scan; char buffer[65536]; } *work = calloc(1, sizeof(*work));
    if (!work) { fclose(file); return -1; }
    size_t count; int failed = 0;
    while ((count = fread(work->buffer, 1, sizeof(work->buffer), file)) > 0) {
        if (gcode_scan_cancelled()) { failed = 1; break; }
        gcode_stream_scan_feed(&work->scan, work->buffer, count);
        if (usb_read_block_hook) usb_read_block_hook(0);
    }
    failed |= ferror(file);
    gcode_scan_read_error(file);
    fclose(file);
    if (!failed) {
        gcode_stream_scan_finish(&work->scan);
        *adaptive = work->scan.adaptive;
        gcode_tools_list(work->scan.present, tools, tool_count);
    }
    free(work);
    return failed ? -1 : 0;
}

static int gcode_request_file(const char *body, size_t body_len,
                              char storage[16], char filename[PATH_MAX_LOCAL],
                              const char **extra, size_t *extra_len,
                              const char **root, const char **media) {
    const char *first = memchr(body, '\n', body_len);
    if (!first) return 0;
    size_t storage_length = (size_t)(first - body);
    const char *file_start = first + 1;
    size_t remaining = body_len - storage_length - 1;
    const char *second = memchr(file_start, '\n', remaining);
    size_t filename_length = second ? (size_t)(second - file_start) : remaining;
    if (!storage_length || storage_length >= 16 || !filename_length ||
        filename_length >= PATH_MAX_LOCAL) return 0;
    memcpy(storage, body, storage_length); storage[storage_length] = '\0';
    memcpy(filename, file_start, filename_length); filename[filename_length] = '\0';
    *root = NULL; *media = NULL;
    if (strcmp(storage, "internal") == 0) { *root = gcode_internal_root; *media = "local"; }
    else if (strcmp(storage, "usb") == 0) { *root = gcode_usb_root; *media = "u-disk"; }
    if (!*root) return 0;
    if (extra && extra_len) {
        *extra = second ? second + 1 : body + body_len;
        *extra_len = second ? body_len - (size_t)(*extra - body) : 0;
    }
    return 1;
}

typedef struct { int valid; struct stat stamp; char path[PATH_MAX_LOCAL*2]; size_t length; char response[4096]; } analysis_cache;
static analysis_cache analysis_cached[2];
static _Thread_local analysis_cache *analysis_capture;
static void analysis_respond(int fd,int code,const char *status,const char *type,const char *body,size_t length) {
    if(analysis_capture && code==200 && length<sizeof(analysis_capture->response)) {
        memcpy(analysis_capture->response,body,length);analysis_capture->length=length;
    }
    respond(fd,code,status,type,body,length);
}

static void gcode_inspect_response(int fd, const char *body, size_t body_len) {
    char storage[16], filename[PATH_MAX_LOCAL];
    const char *root, *media;
    if (!gcode_request_file(body, body_len, storage, filename, NULL, NULL, &root, &media) ||
        !gcode_file_is_printable(root, filename)) {
        const char *error = "{\"error\":\"File is unavailable or unsafe\"}\n";
        analysis_respond(fd, 404, "Not Found", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    (void)media;
    int tools[GCODE_TOOLS_MAX], adaptive = 0; size_t count = 0;
    double lengths[GCODE_TOOLS_MAX];
    if (gcode_detect_tools(root, filename, tools, &count, lengths) != 0) {
        const char *error = "{\"error\":\"Cannot inspect the G-code file\"}\n";
        analysis_respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    if (gcode_has_adaptive_mesh(root, filename, &adaptive) != 0) {
        const char *error = "{\"error\":\"Cannot inspect bed leveling commands\"}\n";
        analysis_respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    gcode_filament_info filaments[GCODE_TOOLS_MAX];
    if (gcode_read_filaments(root, filename, filaments) != 0) {
        const char *error = "{\"error\":\"Cannot inspect filament metadata\"}\n";
        analysis_respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    char response[4096]; size_t used = 0;
    int length = snprintf(response, sizeof(response), "{\"tools\":[");
    if (length < 0 || (size_t)length >= sizeof(response)) return;
    used = (size_t)length;
    for (size_t index = 0; index < count; ++index) {
        length = snprintf(response + used, sizeof(response) - used,
                          "%s%d", index ? "," : "", tools[index]);
        if (length < 0 || (size_t)length >= sizeof(response) - used) return;
        used += (size_t)length;
    }
    length = snprintf(response + used, sizeof(response) - used, "],\"filaments\":[");
    if (length < 0 || (size_t)length >= sizeof(response) - used) return;
    used += (size_t)length;
    for (size_t index = 0; index < count; index++) {
        int tool = tools[index]; char material[130], mm[32] = "";
        json_escape(material, sizeof(material), filaments[tool].material);
        /* The slicer's filament length is only sent when the file states it. */
        if (lengths[tool] >= 0) snprintf(mm, sizeof(mm), ",\"mm\":%.1f", lengths[tool]);
        length = snprintf(response + used, sizeof(response) - used,
            "%s{\"tool\":%d,\"color\":\"%s\",\"material\":\"%s\"%s}",
            index ? "," : "", tool, filaments[tool].color, material, mm);
        if (length < 0 || (size_t)length >= sizeof(response) - used) return;
        used += (size_t)length;
    }
    double bed = -1, nozzle = -1;
    char bed_value[24] = "null", nozzle_value[24] = "null";
    if (gcode_read_setup(root, filename, &bed, &nozzle) == 0) {
        if (bed > 0) snprintf(bed_value, sizeof(bed_value), "%.0f", bed);
        if (nozzle > 0) snprintf(nozzle_value, sizeof(nozzle_value), "%.2f", nozzle);
    }
    length = snprintf(response + used, sizeof(response) - used,
                      "],\"multicolour\":%s,\"adaptive_mesh\":%s,\"bed_temperature\":%s,\"nozzle_diameter\":%s}\n",
                      count > 1 ? "true" : "false", adaptive ? "true" : "false", bed_value, nozzle_value);
    if (length > 0 && (size_t)length < sizeof(response) - used)
        analysis_respond(fd, 200, "OK", "application/json; charset=utf-8", response, used + (size_t)length);
}

static int parse_slot_map(const char *text, size_t length,
                          int tools[GCODE_TOOLS_MAX], int trays[GCODE_TOOLS_MAX],
                          size_t *count) {
    *count = 0;
    if (!length) return 1;
    char map[256];
    if (length >= sizeof(map)) return 0;
    memcpy(map, text, length); map[length] = '\0';
    char *cursor = map;
    while (*cursor) {
        if (*count >= GCODE_TOOLS_MAX) return 0;
        char *tool_end, *tray_end;
        long tool = strtol(cursor, &tool_end, 10);
        if (tool_end == cursor || *tool_end != ':') return 0;
        long tray = strtol(tool_end + 1, &tray_end, 10);
        if (tray_end == tool_end + 1 || (tray_end[0] && tray_end[0] != ',')) return 0;
        if (tool < 0 || tool >= GCODE_TOOLS_MAX || tray < 0 || tray > 3) return 0;
        for (size_t index = 0; index < *count; ++index)
            if (tools[index] == tool) return 0;
        tools[*count] = (int)tool; trays[*count] = (int)tray; (*count)++;
        cursor = *tray_end ? tray_end + 1 : tray_end;
        if (!*cursor) break;
    }
    return 1;
}

static int base64_value(unsigned char ch) {
    if (ch >= 'A' && ch <= 'Z') return ch - 'A';
    if (ch >= 'a' && ch <= 'z') return ch - 'a' + 26;
    if (ch >= '0' && ch <= '9') return ch - '0' + 52;
    if (ch == '+') return 62;
    if (ch == '/') return 63;
    return -1;
}

static unsigned char *decode_base64(const char *input, size_t length, size_t *decoded_length) {
    size_t capacity = length / 4 * 3 + 3, used = 0;
    unsigned char *output = malloc(capacity ? capacity : 1);
    int quartet[4]; size_t count = 0;
    if (!output) return NULL;
    for (size_t index = 0; index < length; ++index) {
        unsigned char ch = (unsigned char)input[index];
        if (isspace(ch)) continue;
        if (ch == '=') quartet[count++] = -2;
        else {
            int value = base64_value(ch);
            if (value < 0) { free(output); return NULL; }
            quartet[count++] = value;
        }
        if (count == 4) {
            if (quartet[0] < 0 || quartet[1] < 0 ||
                (quartet[2] == -2 && quartet[3] != -2)) { free(output); return NULL; }
            output[used++] = (unsigned char)((quartet[0] << 2) | (quartet[1] >> 4));
            if (quartet[2] >= 0) {
                output[used++] = (unsigned char)((quartet[1] << 4) | (quartet[2] >> 2));
                if (quartet[3] >= 0)
                    output[used++] = (unsigned char)((quartet[2] << 6) | quartet[3]);
                else if (quartet[3] != -2) { free(output); return NULL; }
            }
            count = 0;
        }
    }
    if (count != 0) { free(output); return NULL; }
    *decoded_length = used;
    return output;
}

static void gcode_thumbnail_response(int fd, const char *body, size_t body_len) {
    char storage[16], filename[PATH_MAX_LOCAL], path[PATH_MAX_LOCAL * 2], line[4096];
    const char *root, *media;
    if (!gcode_request_file(body, body_len, storage, filename, NULL, NULL, &root, &media) ||
        !gcode_resolved_path(root, filename, path, sizeof(path))) {
        const char *error = "{\"error\":\"File is unavailable or unsafe\"}\n";
        respond(fd, 404, "Not Found", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    (void)media;
    FILE *file = fopen(path, "rb");
    char *current = NULL, *best = NULL;
    size_t current_used = 0, best_used = 0, scanned = 0;
    unsigned long current_pixels = 0, best_pixels = 0;
    int collecting = 0;
    if (!file) {
        const char *error = "{\"error\":\"Cannot open G-code file\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    current = malloc(GCODE_THUMBNAIL_BASE64_MAX + 1);
    best = malloc(GCODE_THUMBNAIL_BASE64_MAX + 1);
    if (!current || !best) { fclose(file); free(current); free(best); return; }
    while (scanned < GCODE_THUMBNAIL_SCAN_MAX && fgets(line, sizeof(line), file)) {
        size_t line_length = strlen(line); scanned += line_length;
        unsigned int width = 0, height = 0; unsigned long declared = 0;
        char *text = line;
        while (*text == ' ' || *text == '\t' || *text == ';') text++;
        if (sscanf(text, "thumbnail begin %ux%u %lu", &width, &height, &declared) >= 2 ||
            sscanf(text, "thumbnail_JPG begin %ux%u %lu", &width, &height, &declared) >= 2) {
            (void)declared;
            collecting = width > 0 && height > 0;
            current_pixels = (unsigned long)width * (unsigned long)height;
            current_used = 0;
            continue;
        }
        if (collecting && (strncasecmp(text, "thumbnail end", 13) == 0 ||
                           strncasecmp(text, "thumbnail_JPG end", 17) == 0)) {
            if (current_used && current_pixels > best_pixels) {
                memcpy(best, current, current_used); best_used = current_used; best_pixels = current_pixels;
            }
            collecting = 0; current_used = 0; current_pixels = 0;
            continue;
        }
        if (collecting) {
            while (*text && isspace((unsigned char)*text)) text++;
            size_t chunk = strcspn(text, "\r\n");
            if (current_used + chunk > GCODE_THUMBNAIL_BASE64_MAX) {
                collecting = 0; current_used = 0; current_pixels = 0;
            } else {
                memcpy(current + current_used, text, chunk); current_used += chunk;
            }
        }
    }
    fclose(file);
    if (!best_used) {
        free(current); free(best);
        const char *error = "{\"error\":\"No embedded thumbnail\"}\n";
        respond(fd, 404, "Not Found", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    size_t image_length = 0;
    unsigned char *image = decode_base64(best, best_used, &image_length);
    free(current); free(best);
    if (!image || image_length < 8) {
        free(image);
        const char *error = "{\"error\":\"Invalid embedded thumbnail\"}\n";
        respond(fd, 422, "Unprocessable Content", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    const char *content_type = NULL;
    static const unsigned char png_signature[8] = {137,80,78,71,13,10,26,10};
    if (memcmp(image, png_signature, sizeof(png_signature)) == 0) content_type = "image/png";
    else if (image[0] == 0xff && image[1] == 0xd8) content_type = "image/jpeg";
    if (!content_type) {
        free(image);
        const char *error = "{\"error\":\"Unsupported thumbnail image\"}\n";
        respond(fd, 415, "Unsupported Media Type", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    respond(fd, 200, "OK", content_type, (const char *)image, image_length);
    free(image);
}


/* SLICE_CFG_MODEL=0 enters the vendor preliminary print calibration.
 * Enable the file's FROM_SLICER calibration independently, while bypassing
 * that preliminary stage with SLICE_CFG_MODEL=1. Full CC2 calibration is
 * already performed explicitly below and must not be repeated either. */
static int build_calibrated_start_script(char *script, size_t cap, int force_full_mesh,
                                         char print_layout, const char *print_media,
                                         const char *print_filename, const int *tools,
                                         const int *trays, size_t slot_count) {
    size_t used = 0;
    if (!script || !cap || !print_media || !print_filename ||
        strchr(print_filename, '\"') || strchr(print_filename, '\\') ||
        (slot_count && (!tools || !trays))) return -1;
    int length;
    if (force_full_mesh) {
        length = snprintf(script, cap,
            "BED_MESH_CALIBRATE_SET EXECUTE_CALIBRATE_FROM_SLICER=0\n"
            "PRINT_SURFACE_SET PLANE=%d\n"
            "BED_MESH_CALIBRATE PROFILE=%s BED_TEMP=60\n",
            print_layout == 'B' ? 1 : 0,
            print_layout == 'B' ? "default1" : "default");
    } else {
        length = snprintf(script, cap,
            "BED_MESH_CALIBRATE_SET EXECUTE_CALIBRATE_FROM_SLICER=1\n"
            "PRINT_SURFACE_SET PLANE=%d\n", print_layout == 'B' ? 1 : 0);
    }
    if (length > 0 && (size_t)length < cap) used = (size_t)length;
    /* One command for the whole map, as the firmware's own method 1020 sends it
     * (APIPrinter::set_print_tray_map): each CANVAS_SET_COLOR_TABLE replaces the
     * whole table, so one command per tool would keep only the last tool. */
    static const char *const map_keys[] = {"CANVAS_SET_COLOR_TABLE T=", " ID=", " CHANNEL="};
    for (size_t key = 0; used && slot_count && key < 3; ++key) {
        for (size_t index = 0; used && index < slot_count; ++index) {
            length = snprintf(script + used, cap - used, "%s%d", index ? "," : map_keys[key],
                              key == 0 ? tools[index] : key == 1 ? 0 : trays[index]);
            if (length <= 0 || (size_t)length >= cap - used) used = 0;
            else used += (size_t)length;
        }
    }
    if (used && slot_count) {
        length = snprintf(script + used, cap - used, "\n");
        if (length <= 0 || (size_t)length >= cap - used) used = 0;
        else used += (size_t)length;
    }
    if (used) {
        length = snprintf(script + used, cap - used,
            "SDCARD_PRINT_FILE FILENAME=%s/\"%s\" SLICE_CFG_MODEL=1",
            print_media, print_filename);
        if (length <= 0 || (size_t)length >= cap - used) used = 0;
    }
    return used ? 0 : -1;
}

static int canvas_color_table_clear(void);

/* A print dialog start from USB (#344) runs in two calls of gcode_start_run(): USB_START_CHECK parses
 * the request and checks the printer without touching the file, then a worker thread scans the USB file
 * and copies it into internal memory, then USB_START_PREPARED repeats every check with the worker's
 * results and sends the start. Reading, scanning and copying a large file from the USB stick takes
 * many seconds; none of it runs on the main loop. */
enum { USB_START_CHECK = 1, USB_START_PREPARED };
typedef struct {
    int stage;
    /* From USB_START_CHECK, for the worker. */
    char filename[PATH_MAX_LOCAL], leveling[16];
    int tools[GCODE_TOOLS_MAX]; size_t slot_count;
    /* From the worker. */
    int scan_failed, adaptive, detect_failed, detected[GCODE_TOOLS_MAX]; size_t detected_count;
    int import_failed, imported_ok, replaced; char imported[PATH_MAX_LOCAL];
    int unpublished; /* lock fd of the verified copy still waiting as .part to be published, or -1 */
    gcode_source_stamp source; int import_error; size_t import_copied;
    int from_cache; /* the decision came from the dialog's cached inspection of the same file */
    int internal;   /* a start from internal memory: checked on the worker, nothing to copy */
} gcode_usb_start;
/* Publishes the verified copy of a USB start (renames its .part over the copy's name) and drops its lock. Main loop,
 * right before the start is sent, after the printer was confirmed idle. Without a publish the .part is removed
 * again (usb_start_unpublish), and an earlier copy of the same name stays as it was. */
static int usb_start_part_path(const gcode_usb_start *usb, char *final, size_t final_size, char *part, size_t part_size) {
    return snprintf(final, final_size, "%s/%s", gcode_internal_root, usb->imported) < (int)final_size &&
           snprintf(part, part_size, "%s/%s.part", gcode_internal_root, usb->imported) < (int)part_size;
}
static int usb_start_publish(gcode_usb_start *usb) {
    if (usb->unpublished < 0) return 0;
    char final[PATH_MAX_LOCAL * 2], part[PATH_MAX_LOCAL * 2 + 8];
    int ok = usb_start_part_path(usb, final, sizeof(final), part, sizeof(part)) && rename(part, final) == 0;
    if (ok) chmod(final, 0644); else unlink(part);
    close(usb->unpublished); usb->unpublished = -1;
    return ok ? 0 : -1;
}
static void usb_start_unpublish(gcode_usb_start *usb) {
    if (usb->unpublished < 0) return;
    char final[PATH_MAX_LOCAL * 2], part[PATH_MAX_LOCAL * 2 + 8];
    if (usb_start_part_path(usb, final, sizeof(final), part, sizeof(part))) unlink(part);
    close(usb->unpublished); usb->unpublished = -1;
}

/* Every tool the G-code uses must be mapped, and nothing else. */
static int gcode_tools_conflict(const int *tools, size_t slot_count, int detect_failed,
                                const int *detected, size_t detected_count) {
    if (detect_failed || detected_count != slot_count) return 1;
    for (size_t expected = 0; expected < detected_count; ++expected) {
        int found = 0;
        for (size_t supplied = 0; supplied < slot_count; ++supplied)
            if (tools[supplied] == detected[expected]) found = 1;
        if (!found) return 1;
    }
    return 0;
}

/* The printer program (elegoo_printer, 32-bit ARM) checks a print file with the 32-bit stat(): from 2 GiB on that
 * fails with EOVERFLOW and it reports the file as missing (read in its disassembly; on the printer a 2.5 GiB start was
 * answered 202 after a 434.5 s copy and never began, measured). Such a file is started only when the request carries
 * the confirmation line "large_ok" (open system: the operator decides, perhaps for an adapted firmware); without it
 * the start is refused with reason file_too_large_for_printer before anything is copied. */
#define PRINTER_FILE_LIMIT 2147483648LL
static long long printer_file_limit = PRINTER_FILE_LIMIT; /* test seam */
/* The file's size, or -1 when it cannot be read. */
static long long gcode_file_size(const char *root, const char *filename) {
    char path[PATH_MAX_LOCAL * 2]; struct stat info;
    if (!gcode_resolved_path(root, filename, path, sizeof(path)) || stat(path, &info) != 0 || !S_ISREG(info.st_mode))
        return -1;
    return (long long)info.st_size;
}
/* After an accepted start of such a confirmed file, CC2 Control watches whether the printer begins it: a job running
 * (machine status 2 with print state "printing") or a job uuid other than the one before the start counts as begun;
 * a refusal of the start request (method 1020 in printer_error) or a printer idle again after PRINT_WATCH_MS counts
 * as failed. While the printer is busy (a calibrated start levels the bed first, without a 1020 reply) the watch goes
 * on, up to PRINT_WATCH_CAP_MS. In the measured 2.5 GiB run the printer stayed idle and silent after the start. A
 * failed start removes the internal CC2_USB_ copy it was given, where the
 * file list's delete guard allows it and no queued job names it (gcode_usb_import_remove). The outcome is reported in
 * the status (print_watch) and, for a queued copy, as its last_result "not_opened". */
#define PRINT_WATCH_MS 30000
#define PRINT_WATCH_CAP_MS 1800000
enum { PRINT_WATCH_NONE, PRINT_WATCH_WATCHING, PRINT_WATCH_STARTED, PRINT_WATCH_FAILED };
typedef struct {
    unsigned long sequence;
    int state, imported, queue_id, code;
    long long armed_ms;
    unsigned long errors;       /* mqtt->reply_errors when the start went out */
    char uuid[128];             /* mqtt->uuid when the start went out: the previous job's */
    char file[PATH_MAX_LOCAL];  /* the file the printer was given */
} print_watch_state;
static print_watch_state print_watch;
static long long print_watch_ms = PRINT_WATCH_MS, print_watch_cap_ms = PRINT_WATCH_CAP_MS; /* test seams */
static long long monotonic_ms(void);
static void print_watch_arm(const mqtt_client *mqtt, const char *file, int imported) {
    print_watch.sequence++;
    print_watch.state = PRINT_WATCH_WATCHING;
    print_watch.imported = imported; print_watch.queue_id = 0; print_watch.code = 0;
    print_watch.armed_ms = monotonic_ms();
    print_watch.errors = mqtt->reply_errors;
    snprintf(print_watch.uuid, sizeof(print_watch.uuid), "%s", mqtt->uuid);
    snprintf(print_watch.file, sizeof(print_watch.file), "%s", file);
}

/* Answers the client and returns the HTTP status it sent. With `started` (PATH_MAX_LOCAL bytes), an
 * accepted start also reports the file the printer was given, which differs from the request for a
 * USB import. `usb` selects a stage of the threaded USB start above (NULL: everything in this call);
 * USB_START_CHECK answers only a refusal and returns 0 when the request may go on to the worker. */
static int gcode_start_run(int fd, mqtt_client *mqtt, const char *body, size_t body_len,
                           char *started, gcode_usb_start *usb) {
    char storage[16], filename[PATH_MAX_LOCAL];
    const char *mapping, *root, *media; size_t mapping_len = 0;
    if (!gcode_request_file(body, body_len, storage, filename, &mapping, &mapping_len,
                            &root, &media)) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid print request\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return 400;
    }
    if (!gcode_file_is_printable(root, filename)) {
        const char *error = "{\"accepted\":false,\"error\":\"File is unavailable or unsafe\"}\n";
        respond(fd, 404, "Not Found", "application/json; charset=utf-8", error, strlen(error));
        return 404;
    }
    const char *layout_line = memchr(mapping, '\n', mapping_len);
    size_t map_len = layout_line ? (size_t)(layout_line - mapping) : mapping_len;
    const char *level_line = NULL, *video_line = NULL, *measure_line = NULL, *nozzle_line = NULL, *large_line = NULL;
    size_t layout_len = 0, level_len = 0, video_len = 0, measure_len = 0, nozzle_len = 0, large_len = 0;
    if (layout_line) {
        layout_line++;
        size_t remaining = mapping_len - (size_t)(layout_line - mapping);
        level_line = memchr(layout_line, '\n', remaining);
        layout_len = level_line ? (size_t)(level_line - layout_line) : remaining;
        if (level_line) {
            level_line++;size_t rest=mapping_len-(size_t)(level_line-mapping);
            video_line=memchr(level_line,'\n',rest);
            level_len=video_line?(size_t)(video_line-level_line):rest;
            if(video_line){
                video_line++;size_t left=mapping_len-(size_t)(video_line-mapping);
                measure_line=memchr(video_line,'\n',left);
                video_len=measure_line?(size_t)(measure_line-video_line):left;
                if(measure_line){
                    measure_line++;left=mapping_len-(size_t)(measure_line-mapping);
                    nozzle_line=memchr(measure_line,'\n',left);
                    measure_len=nozzle_line?(size_t)(nozzle_line-measure_line):left;
                    if(nozzle_line){
                        nozzle_line++;left=mapping_len-(size_t)(nozzle_line-mapping);
                        large_line=memchr(nozzle_line,'\n',left);
                        nozzle_len=large_line?(size_t)(large_line-nozzle_line):left;
                        if(large_line){large_line++;large_len=mapping_len-(size_t)(large_line-mapping);}
                    }
                }
            }
        }
    }
    /* Optional: the build-plate measurement and nozzle from the print dialog. */
    char measure[24] = "", nozzle[24] = "";
    while (nozzle_len && (nozzle_line[nozzle_len - 1] == '\n' || nozzle_line[nozzle_len - 1] == '\r')) nozzle_len--;
    if (measure_len >= sizeof(measure) || nozzle_len >= sizeof(nozzle)) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid build plate measurement\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return 400;
    }
    if (measure_len) memcpy(measure, measure_line, measure_len);
    if (nozzle_len) memcpy(nozzle, nozzle_line, nozzle_len);
    /* Optional ninth line: "large_ok", the operator's confirmation to start a file of 2 GiB or more anyway. */
    while (large_len && (large_line[large_len - 1] == '\n' || large_line[large_len - 1] == '\r')) large_len--;
    if (large_len && (large_len != 8 || memcmp(large_line, "large_ok", 8))) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid large file confirmation\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return 400;
    }
    long long file_size = gcode_file_size(root, filename);
    int large = file_size >= printer_file_limit;
    if (large && !large_len) {
        const char *error = "{\"accepted\":false,\"reason\":\"file_too_large_for_printer\",\"error\":\"The printer has not opened files of 2 GiB or more; confirm the start to try anyway\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        return 409;
    }
    char print_layout = 'A';
    if (layout_len) {
        if (layout_len != 1 || (layout_line[0] != 'A' && layout_line[0] != 'B')) {
            const char *error = "{\"accepted\":false,\"error\":\"Invalid build plate side\"}\n";
            respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
            return 400;
        }
        print_layout = layout_line[0];
    }
    int timelapse=0;
    if(video_line){
        if(video_len!=1||(video_line[0]!='0'&&video_line[0]!='1')){
            const char *error="{\"accepted\":false,\"error\":\"Invalid timelapse option\"}\n";
            respond(fd,400,"Bad Request","application/json",error,strlen(error));return 400;
        }
        timelapse=video_line[0]=='1';
    }
    char leveling[16] = "saved";
    if (level_len) {
        if (level_len >= sizeof(leveling)) {
            const char *error = "{\"accepted\":false,\"error\":\"Invalid bed leveling mode\"}\n";
            respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
            return 400;
        }
        memcpy(leveling, level_line, level_len); leveling[level_len] = '\0';
        if (strcmp(leveling, "saved") != 0 && strcmp(leveling, "calibrate") != 0 &&
            strcmp(leveling, "adaptive") != 0 && strcmp(leveling, "full") != 0) {
            const char *error = "{\"accepted\":false,\"error\":\"Invalid bed leveling mode\"}\n";
            respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
            return 400;
        }
    }
    int tools[GCODE_TOOLS_MAX], trays[GCODE_TOOLS_MAX]; size_t slot_count = 0;
    if (!parse_slot_map(mapping, map_len, tools, trays, &slot_count)) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid Canvas slot mapping\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return 400;
    }
    if (usb && usb->stage == USB_START_CHECK) {
        usb->internal = strcmp(storage, "usb") != 0;
        /* A USB start is refused here, before the stick is read, as develop refuses it; so is an internal start on
         * a linked printer that is not idle. An internal start without a printer link never gets here
         * (usb_start_begin_for answers it synchronously, as develop). */
        if (!usb->internal && (!mqtt->connected || !mqtt->registered)) {
            const char *error = "{\"accepted\":false,\"error\":\"Printer MQTT is not ready\"}\n";
            respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
            return 503;
        }
        if ((!usb->internal || (mqtt->connected && mqtt->registered)) &&
            (!mqtt->have_machine_status || mqtt->machine_status != 1)) {
            const char *error = "{\"accepted\":false,\"error\":\"Starting a file requires an idle printer\"}\n";
            respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
            return 409;
        }
        snprintf(usb->filename, sizeof(usb->filename), "%s", filename);
        snprintf(usb->leveling, sizeof(usb->leveling), "%s", leveling);
        memcpy(usb->tools, tools, sizeof(usb->tools)); usb->slot_count = slot_count;
        return 0;
    }
    int adaptive = 0;
    if (usb) adaptive = usb->adaptive;
    if (usb ? usb->scan_failed : gcode_has_adaptive_mesh(root, filename, &adaptive) != 0) {
        const char *error = "{\"accepted\":false,\"error\":\"Cannot inspect bed leveling commands\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return 500;
    }
    if (strcmp(leveling, "adaptive") == 0 && !adaptive) {
        const char *error = "{\"accepted\":false,\"error\":\"Selected leveling mode does not match this G-code\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        return 409;
    }
    if (slot_count) {
        int detected[GCODE_TOOLS_MAX]; size_t detected_count = 0; int detect_failed;
        if (usb) {
            detect_failed = usb->detect_failed; detected_count = usb->detected_count;
            memcpy(detected, usb->detected, sizeof(detected));
        } else {
            detect_failed = gcode_detect_tools(root, filename, detected, &detected_count, NULL) != 0;
        }
        if (gcode_tools_conflict(tools, slot_count, detect_failed, detected, detected_count)) {
            const char *error = "{\"accepted\":false,\"error\":\"Canvas mapping does not match this G-code\"}\n";
            respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
            return 409;
        }
    }
    if (!mqtt->connected || !mqtt->registered) {
        const char *error = "{\"accepted\":false,\"error\":\"Printer MQTT is not ready\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        return 503;
    }
    if (!mqtt->have_machine_status || mqtt->machine_status != 1) {
        const char *error = "{\"accepted\":false,\"error\":\"Starting a file requires an idle printer\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        return 409;
    }
    int missing_plate_mesh = !saved_plate_mesh_exists(print_layout);
    int calibration_requested = strcmp(leveling, "calibrate") == 0;
    int force_full_mesh = strcmp(leveling, "full") == 0 || missing_plate_mesh ||
                          (calibration_requested && !adaptive);
    int calibrated_start = strcmp(leveling, "saved") != 0 || missing_plate_mesh;
    char late[24] = "";
    const char *plate_problem = plates_print_prepare(mqtt, print_layout, !calibrated_start, measure, nozzle, late);
    if (plate_problem) {
        char escaped[256], error[384];
        json_escape(escaped, sizeof(escaped), plate_problem);
        snprintf(error, sizeof(error), "{\"accepted\":false,\"error\":\"%s\"}\n", escaped);
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        return 409;
    }
    char print_filename[PATH_MAX_LOCAL];
    const char *print_media = media;
    if (strcmp(storage, "usb") == 0) {
        if (usb) snprintf(print_filename, sizeof(print_filename), "%s", usb->imported);
        int import_error = usb ? (usb->import_failed || !usb->imported_ok
                                      ? (usb->import_error ? usb->import_error : GCODE_IMPORT_FAILED) : 0)
                               : gcode_import_usb(filename, print_filename, NULL, NULL, NULL, 0, NULL, NULL);
        if (!import_error && usb && usb_start_publish(usb) != 0) import_error = GCODE_IMPORT_FAILED;
        if (import_error) {
            const char *error =
                import_error == GCODE_IMPORT_NO_SPACE
                    ? "{\"accepted\":false,\"error\":\"Insufficient free space for the USB copy and storage reserve\"}\n"
                : import_error == GCODE_IMPORT_CHANGED
                    ? "{\"accepted\":false,\"error\":\"The USB file changed while it was copied\"}\n"
                : import_error == GCODE_IMPORT_UNVERIFIED
                    ? "{\"accepted\":false,\"error\":\"The internal copy of the USB file failed verification\"}\n"
                    : "{\"accepted\":false,\"error\":\"Cannot import the USB file into internal memory\"}\n";
            respond(fd, 507, "Insufficient Storage", "application/json; charset=utf-8", error, strlen(error));
            return 507;
        }
        print_media = "local";
    } else {
        snprintf(print_filename, sizeof(print_filename), "%s", filename);
        /* Checked on the worker: the start goes out only for the file that was checked. */
        if (usb && usb->stage == USB_START_PREPARED && usb->internal) {
            char path[PATH_MAX_LOCAL * 2]; struct stat now; gcode_source_stamp current; int same = 0;
            if (usb->source.known && gcode_resolved_path(root, filename, path, sizeof(path)) && stat(path, &now) == 0) {
                gcode_source_stamp_of(&current, &now);
                same = gcode_source_stamp_same(&usb->source, &current);
            }
            if (!same) {
                const char *error = "{\"accepted\":false,\"error\":\"The file changed while the start was prepared\"}\n";
                respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
                return 409;
            }
        }
    }
    int start_result = -1;
    if (calibrated_start && (strchr(print_filename, '"') || strchr(print_filename, '\\'))) {
        const char *error = "{\"accepted\":false,\"error\":\"Filename is incompatible with calibrated printing\"}\n";
        respond(fd, 422, "Unprocessable Content", "application/json; charset=utf-8", error, strlen(error));
        return 422;
    }
    if (!slot_count && canvas_color_table_clear() != 0) {
        const char *error = "{\"accepted\":false,\"error\":\"Cannot clear the Canvas colour table for the external feed\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        return 503;
    }
    if (calibrated_start) {
        char script[4096];
        if (mqtt_prepare_timelapse(mqtt,timelapse)==0 &&
            build_calibrated_start_script(script, sizeof(script), force_full_mesh,
                                          print_layout, print_media, print_filename,
                                          tools, trays, slot_count) == 0)
            start_result = send_local_gcode_script(script);
    } else {
        start_result = mqtt_start_print(mqtt, print_media, print_filename, tools, trays,
                                        slot_count, print_layout, 0, timelapse);
    }
    if (start_result != 0) {
        const char *error = "{\"accepted\":false,\"error\":\"Cannot send the printer start request\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        return 503;
    }
    plates_print_arm(late, print_layout);
    if (large) print_watch_arm(mqtt, print_filename, strcmp(storage, "usb") == 0);
    char watch[48] = "";
    if (large) snprintf(watch, sizeof(watch), ",\"watch\":%lu", print_watch.sequence);
    char accepted[PATH_MAX_LOCAL * 2 + 176], escaped[PATH_MAX_LOCAL * 2];
    json_escape(escaped, sizeof(escaped), print_filename);
    int accepted_len = snprintf(accepted, sizeof(accepted),
        "{\"accepted\":true,\"method\":1020,\"storage_media\":\"%s\",\"filename\":\"%s\",\"imported_from_usb\":%s,\"print_layout\":\"%c\",\"leveling\":\"%s\",\"timelapse\":%s,\"late_mesh\":\"%s\"%s}\n",
        print_media, escaped, strcmp(storage, "usb") == 0 ? "true" : "false",
        print_layout, leveling, timelapse ? "true" : "false", late, watch);
    /* The start request is on its way whatever happens to the reply below. */
    if (started) snprintf(started, PATH_MAX_LOCAL, "%s", print_filename);
    if (accepted_len > 0 && (size_t)accepted_len < sizeof(accepted))
        respond(fd, 202, "Accepted", "application/json; charset=utf-8", accepted, (size_t)accepted_len);
    if (strcmp(storage, "usb") == 0) (void)gcode_usb_prune(mqtt, print_filename);
    return 202;
}

static int gcode_start_response(int fd, mqtt_client *mqtt,
                                 const char *body, size_t body_len, char *started) {
    return gcode_start_run(fd, mqtt, body, body_len, started, NULL);
}

/* The names say USB, but since the internal start moved here too (it only skips the copy), this is
 * the one print-start worker for both media; the queue uses it as well.
 * One threaded USB start at a time. The main loop owns the socket and `usb_start` except between
 * usb_start_begin() and the worker's `usb_start_done`, when only the worker writes the results. */
static gcode_usb_start usb_start;
static int usb_start_fd = -1;
static atomic_int usb_start_done;
static char usb_start_body[PATH_MAX_LOCAL + 512];
static size_t usb_start_length;
/* Set by the main loop only: the client left (1) or the emergency stop was pressed (2) before
 * the start was dispatched. The worker stops copying after the current block and leaves
 * nothing behind; the print is never sent. */
static atomic_int usb_start_cancelled;
/* Room for the copy, made right before it is written: the worker sets 1 with the size and name once the
 * checks before the copy passed and the copy does not fit; the main loop (which may consult the printer
 * state for gcode_delete_guard) takes it up (3), removes old copies and sets 2. The worker waits at most
 * USB_START_ROOM_WAIT_MS for it to be taken up and stops waiting on a cancel; then it withdraws the wish
 * (1 -> 0), so nothing is removed for a start that went on without room; the copy checks the room itself. */
#define USB_START_ROOM_WAIT_MS 2000
static atomic_int usb_start_room;
static uint64_t usb_start_room_size;
static char usb_start_room_name[PATH_MAX_LOCAL];
static int usb_start_canvas_waiting;
/* A start with a slot mapping that began before the Canvas had reported its trays: it asks for a report at once
 * and waits for it up to usb_start_canvas_wait_ms (as after the copy, see usb_start_canvas_wait); the report that
 * comes is kept as the trays at the start. Without one the start is refused, never sent unprotected. */
static int usb_start_trays_known; /* queue.h */
static atomic_int usb_start_trays_late; /* read by the worker before it copies */
static unsigned long usb_start_trays_late_seen;
static long long usb_start_trays_late_until;
static long long monotonic_ms(void);
static long long usb_start_canvas_wait_ms;
static int usb_start_mapped(const char *body, size_t length);
/* Test seam: runs on the worker right before the copy. */
static void (*usb_start_copy_hook)(void);

static int usb_start_active(void) { return usb_start_fd >= 0; }
/* The file list does not delete a file (or its name on the other medium) while its start is prepared. */
static int print_start_preparing(const char *file) {
    return usb_start_active() && gcode_same_job_name(file, usb_start.filename);
}

/* The emergency stop drops a USB start that has not been dispatched yet. */
static void usb_start_cancel(void) { if (usb_start_active()) usb_start_cancelled = 2; }
/* Whether a start on the worker still reads the file a request names ("storage\nname..."): the dialog's analysis of
 * that same file is then refused at once (reason start_reading) instead of reading the stick in parallel. Main loop. */
static int usb_start_reading_file(const char *body, size_t length) {
    if (!usb_start_active() || atomic_load(&usb_start_done)) return 0;
    const char *newline = memchr(body, '\n', length);
    if (!newline) return 0;
    size_t storage_len = (size_t)(newline - body), name_len = length - storage_len - 1;
    const char *name = newline + 1, *end = memchr(name, '\n', name_len);
    if (end) name_len = (size_t)(end - name);
    int usb = storage_len == 3 && !memcmp(body, "usb", 3);
    return usb == !usb_start.internal && name_len == strlen(usb_start.filename) &&
           !memcmp(name, usb_start.filename, name_len);
}

/* The request was read in full, so any readable state on the socket means the peer closed it. */
static int usb_start_client_gone(int fd) {
    char byte;
    ssize_t n = recv(fd, &byte, 1, MSG_PEEK | MSG_DONTWAIT);
    return n == 0 || (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR);
}


static int analysis_cached_scan(const char *path, const struct stat *now, gcode_scan_expect *out);
static int analysis_reading_file(const char *path); /* the dialog's analysis reads this file right now */
static void *usb_start_worker(void *unused) {
    (void)unused;
    gcode_usb_start *job = &usb_start;
    /* A start from internal memory runs the same checks here, so a large file does not hold up the
     * main loop either; it has nothing to copy, and the main loop compares the file's stamp again
     * before the start is sent. */
    const char *root = job->internal ? gcode_internal_root : gcode_usb_root;
    /* The file as it is before the scan: the copy below must be of this same file. It stays open
     * until the copy is done, so a FAT stick keeps the inode number it reported here. */
    char source[PATH_MAX_LOCAL * 2]; struct stat before; int pinned = -1;
    if (gcode_resolved_path(root, job->filename, source, sizeof(source)) &&
        (pinned = open(source, O_RDONLY | O_CLOEXEC)) >= 0 && fstat(pinned, &before) == 0)
        gcode_source_stamp_of(&job->source, &before);
    /* The dialog's own inspection of this same file decides before the copy, without reading it again;
     * the copy then scans along and must agree. Otherwise the file is scanned first, as before. */
    /* The dialog's analysis of this same file still reads it: wait for it (an emergency stop or a browser that
     * leaves ends the wait), then take its decision from the cache below instead of reading the stick in parallel. */
    while (pinned >= 0 && analysis_reading_file(source) && !atomic_load(&usb_start_cancelled))
        usb_start_nap(20);
    gcode_scan_expect decided;
    job->from_cache = pinned >= 0 && job->source.known && analysis_cached_scan(source, &before, &decided);
    if (job->from_cache) {
        job->adaptive = decided.adaptive;
        job->detected_count = decided.tool_count;
        memcpy(job->detected, decided.tools, decided.tool_count * sizeof(decided.tools[0]));
    } else {
        gcode_scan_cancel = &usb_start_cancelled;
        if (job->slot_count) /* both checks read the whole file: one pass */
            job->scan_failed = job->detect_failed =
                gcode_scan_both(root, job->filename, &job->adaptive, job->detected, &job->detected_count) != 0;
        else /* the mesh check alone stops at the first leveling line */
            job->scan_failed = gcode_has_adaptive_mesh(root, job->filename, &job->adaptive) != 0;
        gcode_scan_cancel = NULL;
    }
    /* A start the scan already refuses is answered without copying the file. */
    int refused = job->scan_failed || (strcmp(job->leveling, "adaptive") == 0 && !job->adaptive) ||
        (job->slot_count && gcode_tools_conflict(job->tools, job->slot_count, job->detect_failed,
                                                  job->detected, job->detected_count));
    if (job->internal) {
        if (usb_start_copy_hook) usb_start_copy_hook(); /* test seam: the point where a copy would start */
    } else if (!refused) {
        /* A start with a mapping that began before the Canvas reported waits for that report here, before anything
         * is copied: the main loop ends the wait with the report, or without one after usb_start_canvas_wait_ms with
         * cancel reason 3, so a silent Canvas is answered after the wait, not after a whole copy. */
        while (atomic_load(&usb_start_trays_late) && !atomic_load(&usb_start_cancelled))
            usb_start_nap(5);
        if (atomic_load(&usb_start_cancelled)) {
            job->import_error = GCODE_IMPORT_CANCELLED; job->import_failed = 1; job->imported_ok = 0;
            goto copied;
        }
        (void)gcode_usb_part_cleanup(); /* leftovers of a copy that ended with its process, before this one */
        /* An earlier import of the same USB file may still be in use (the touchscreen can print it). */
        char existing[PATH_MAX_LOCAL], path[PATH_MAX_LOCAL * 2]; struct stat info;
        if (gcode_usb_import_name(job->filename, existing) == 0 &&
            snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, existing) < (int)sizeof(path))
            job->replaced = lstat(path, &info) == 0;
        if (job->source.known && (uint64_t)job->source.size > 0 &&
            !usb_import_has_space((uint64_t)job->source.size, 0) &&
            gcode_usb_import_name(job->filename, usb_start_room_name) == 0) {
            usb_start_room_size = (uint64_t)job->source.size;
            atomic_store(&usb_start_room, 1);
            for (int waited = 0; waited < USB_START_ROOM_WAIT_MS && atomic_load(&usb_start_room) == 1 &&
                                 !atomic_load(&usb_start_cancelled); waited += 5)
                usb_start_nap(5);
            /* Given up (1 -> 0): the main loop no longer makes room for this start. Taken up (3): it is removing
             * old copies right now, so the copy waits for it to finish; that takes no stick reads. */
            int asked = 1;
            if (!atomic_compare_exchange_strong(&usb_start_room, &asked, 0))
                while (atomic_load(&usb_start_room) == 3) usb_start_nap(5);
        }
        if (usb_start_copy_hook) usb_start_copy_hook();
        job->import_error = gcode_import_usb(job->filename, job->imported, &job->source,
                                             &usb_start_cancelled, &job->import_copied, 1,
                                             job->from_cache ? &decided : NULL, &job->unpublished);
        job->import_failed = job->import_error != 0;
        job->imported_ok = !job->import_failed;
    }
copied:
    if (pinned >= 0) close(pinned);
    atomic_store(&usb_start_done, 1);
    return NULL;
}

/* A copy for a queued job (U10): the queue sets the job to "starting" and sends the start only
 * after the copy, from the main loop; until then the queue file keeps it "pending", so a restart of
 * CC2 Control during the copy leaves it to be started again. An automatic start has no browser
 * waiting: it passes one end of a socket pair and keeps the other here, so it never looks gone. */
static int usb_start_queue_id, usb_start_queue_auto, usb_start_peer = -1;
static int queue_usb_copied(int fd, mqtt_client *mqtt, int id, int automatic, const char *body, size_t length,
                            gcode_usb_start *usb); /* queue.h */
static void queue_usb_dropped(int id, int automatic); /* queue.h */

/* Every start on the worker notes the Canvas trays when it begins and compares the trays its mapping names
 * after the copy (queue.h): a spool changed meanwhile must not be printed with the mapping chosen before. A queued
 * start (`from_queue`) keeps exactly the trays its mapping was chosen from (queue_start_item), not a second
 * reading of the cache. */
static void usb_start_trays_note(const mqtt_client *mqtt, int from_queue);
static int usb_start_trays_changed(const mqtt_client *mqtt, const char *body, size_t length);

/* Returns 1 when the worker took the socket, 0 when the request has been answered (`*status`). */
static int usb_start_begin_for(int fd, mqtt_client *mqtt, const char *body, size_t body_len,
                               int queue_id, int automatic, int peer, int *status) {
    int refused = 0; if (!status) status = &refused;
    if (usb_start_active()) {
        const char *error = usb_start.internal
            ? "{\"accepted\":false,\"error\":\"Another print start is still being prepared\"}\n"
            : "{\"accepted\":false,\"error\":\"A USB file is still being copied for another start\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        *status = 409; return 0;
    }
    if (body_len >= sizeof(usb_start_body)) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid print request\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        *status = 400; return 0;
    }
    /* A start that cannot go out anyway: USB_START_CHECK below refuses it before any file is read, except an
     * internal start without a printer link. That one gets develop's synchronous checks, in develop's order (file
     * checks first) and at once, without a worker: nothing prints without a link, and the queue records such a
     * refusal in the same tick (tests/test_gcode_files.py, tests/test_queue_tracking.c). */
    const char *storage_end = memchr(body, '\n', body_len);
    size_t storage_len = storage_end ? (size_t)(storage_end - body) : body_len;
    int internal = !(storage_len == 3 && memcmp(body, "usb", 3) == 0);
    if (internal && (!mqtt->connected || !mqtt->registered)) {
        *status = gcode_start_run(fd, mqtt, body, body_len, NULL, NULL);
        return 0;
    }
    memset(&usb_start, 0, sizeof(usb_start));
    usb_start.unpublished = -1;
    usb_start.stage = USB_START_CHECK;
    if ((*status = gcode_start_run(fd, mqtt, body, body_len, NULL, &usb_start)) != 0) return 0;
    memcpy(usb_start_body, body, body_len); usb_start_body[body_len] = 0;
    usb_start_length = body_len;
    usb_start_trays_note(mqtt, queue_id != 0);
    /* A queued USB start with a mapping was assigned from the fresh report it asked for (queue_check_state). Without
     * that report it is refused, never compared with a later one: the comparison value is the report the mapping
     * came from, or nothing is started. */
    if (queue_id && !usb_start.internal && !usb_start_trays_known && usb_start_mapped(body, body_len)) {
        const char *error = "{\"accepted\":false,\"reason\":\"canvas_unreported\",\"error\":\"The Canvas did not report its trays when the start began; check that the Canvas is connected, then start the print again\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        *status = 409; return 0;
    }
    usb_start_trays_late = !queue_id && !usb_start.internal && !usb_start_trays_known && usb_start_mapped(body, body_len);
    if (usb_start_trays_late) {
        usb_start_trays_late_seen = mqtt->canvas_revision;
        usb_start_trays_late_until = monotonic_ms() + usb_start_canvas_wait_ms;
        mqtt->canvas_refresh_due = 1;
    }
    atomic_store(&usb_start_room, 0);
    usb_start_canvas_waiting = 0;
    usb_start_cancelled = 0;
    atomic_store(&usb_start_read_failed, 0);
    usb_start_beat_now();
    atomic_store(&usb_start_done, 0);
    pthread_attr_t attr; pthread_t thread;
    int failed = pthread_attr_init(&attr);
    if (!failed) {
        failed = pthread_attr_setstacksize(&attr, 256 * 1024);
        if (!failed) failed = pthread_create(&thread, &attr, usb_start_worker, NULL);
        pthread_attr_destroy(&attr);
    }
    if (failed) {
        const char *error = "{\"accepted\":false,\"error\":\"Cannot start the USB import\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        *status = 503; return 0;
    }
    pthread_detach(thread);
    struct timeval timeout = {5, 0};
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    usb_start_fd = fd;
    usb_start_queue_id = queue_id; usb_start_queue_auto = automatic; usb_start_peer = peer;
    *status = 0;
    return 1;
}
static int usb_start_begin(int fd, mqtt_client *mqtt, const char *body, size_t body_len) {
    return usb_start_begin_for(fd, mqtt, body, body_len, 0, 0, -1, NULL);
}

/* Main loop: once the copy is complete, every check runs again (the printer may have started
 * something meanwhile) and the start is sent. A refused start removes the copy it made, unless
 * an earlier import had the same name: that file is left as the synchronous start left it.
 * A client that disconnects before then, or an emergency stop, cancels the start: the browser
 * has reported a failure, so the print must not begin behind its back. */
/* After the copy of a USB file (print dialog or queue) whose start names Canvas trays, and when the Canvas
 * reported its trays when the start began, the trays are compared only with a fresh report: the main loop
 * asks the printer for one (canvas_refresh_due, sent by mqtt_tick) and waits up to USB_START_CANVAS_WAIT_MS
 * for a new canvas_revision, without blocking. An emergency stop or a client that leaves ends the wait. */
#define USB_START_CANVAS_WAIT_MS 10000
/* No progress of the start worker for this long counts as a stick that stopped answering (Fund 4). Measured on the
 * printer: the slowest 64-KiB block of two healthy sticks took 0.21 s; the kernel gives a USB disk command 30 s
 * (eh_timeout 10 s). 15 s is over 70 times the slowest healthy block and answers the browser before the kernel. */
#define USB_START_STALL_MS 15000
static long long usb_start_stall_ms = USB_START_STALL_MS; /* test seam */
/* A read that stopped answering (reason usb_unresponsive), for the page: while the worker still hangs in it, whether the
 * stick has been removed since (its mount is gone from /proc/mounts, read without touching the stick: a stat() of a
 * stick that does not answer could hold the main loop), and once the worker is back, whether the read came back with
 * an error or only late. A read still hanging USB_STALL_REMOVED_MS after the stick was removed will not end without a
 * power cycle: the page then says so (untested and very unlikely: a stick that stops answering could not be
 * reproduced on the printer). The worker is never cancelled by force; it ends on its own. */
#define USB_STALL_REMOVED_MS 60000
enum { USB_STALL_NONE, USB_STALL_READ_ERROR, USB_STALL_SLOW };
static struct { unsigned long sequence; int hanging, outcome; long long removed_ms, probed_ms; } usb_stall;
static long long usb_stall_removed_ms = USB_STALL_REMOVED_MS; /* test seam */
static const char *usb_mounts_path = "/proc/mounts"; /* test seam */
/* Whether gcode_usb_root is a mount point in usb_mounts_path; -1 when the table cannot be read. */
static int usb_root_mounted(void) {
    FILE *mounts = fopen(usb_mounts_path, "re");
    if (!mounts) return -1;
    char line[1024]; int found = 0;
    while (!found && fgets(line, sizeof(line), mounts)) {
        char *field = strchr(line, ' ');
        if (!field) continue;
        char *end = strchr(++field, ' ');
        if (!end) continue;
        *end = 0;
        char point[PATH_MAX_LOCAL]; size_t n = 0;
        for (const char *p = field; *p && n + 1 < sizeof(point); ++p) {
            if (p[0] == '\\' && p[1] >= '0' && p[1] <= '3' && p[2] >= '0' && p[2] <= '7' && p[3] >= '0' && p[3] <= '7') {
                point[n++] = (char)((p[1] - '0') * 64 + (p[2] - '0') * 8 + (p[3] - '0')); p += 3;
            } else point[n++] = *p;
        }
        point[n] = 0;
        found = !strcmp(point, gcode_usb_root);
    }
    fclose(mounts);
    return found;
}
static void usb_stall_probe(long long now) {
    if (!usb_stall.hanging || usb_stall.removed_ms || now - usb_stall.probed_ms < 1000) return;
    usb_stall.probed_ms = now;
    if (usb_root_mounted() == 0) usb_stall.removed_ms = now;
}
static void usb_stall_json(char *out, size_t cap) {
    if (!usb_stall.sequence) { snprintf(out, cap, "null"); return; }
    int power_cycle = usb_stall.hanging && usb_stall.removed_ms &&
                      monotonic_ms() - usb_stall.removed_ms >= usb_stall_removed_ms;
    snprintf(out, cap, "{\"sequence\":%lu,\"hanging\":%s,\"outcome\":%s,\"removed\":%s,\"power_cycle\":%s}",
             usb_stall.sequence, usb_stall.hanging ? "true" : "false",
             usb_stall.outcome == USB_STALL_READ_ERROR ? "\"read_error\"" : usb_stall.outcome == USB_STALL_SLOW ? "\"slow\"" : "null",
             usb_stall.removed_ms ? "true" : "false", power_cycle ? "true" : "false");
}
/* A queued start asks for a fresh report before it assigns its slots (queue_check_state); usb_start_trays_note keeps
 * the trays of exactly that report as the comparison value, and the request after the copy is the second report. */
/* No fresh report within the wait: 1 refuses the start (the safe side), 0 compares with the stored report
 * as before. The one place to change this. */
#define USB_START_CANVAS_SILENT_REFUSES 1
static long long usb_start_canvas_wait_ms = USB_START_CANVAS_WAIT_MS; /* test seam; also the wait at the start */
static unsigned long usb_start_canvas_seen;
static long long usb_start_canvas_until;
static int usb_start_trays_known; /* queue.h: the trays were noted when the start began */
static int usb_start_mapped(const char *body, size_t length) {
    char storage[16], filename[PATH_MAX_LOCAL];
    const char *mapping, *root, *media;
    size_t mapping_len = 0, count = 0;
    int tools[GCODE_TOOLS_MAX], slots[GCODE_TOOLS_MAX];
    if (!gcode_request_file(body, length, storage, filename, &mapping, &mapping_len, &root, &media)) return 0;
    const char *line_end = memchr(mapping, '\n', mapping_len);
    return parse_slot_map(mapping, line_end ? (size_t)(line_end - mapping) : mapping_len, tools, slots, &count) && count > 0;
}
/* Returns 1 while the start still waits for the report, 0 when it may be judged, -1 when no report came. */
static int usb_start_canvas_wait(mqtt_client *mqtt) {
    /* Only a copy that is there waits: a start the check already refused is answered with that refusal at once. */
    if (usb_start.internal || !usb_start.imported_ok || !usb_start_trays_known ||
        !usb_start_mapped(usb_start_body, usb_start_length)) return 0;
    long long now = monotonic_ms();
    if (!usb_start_canvas_waiting) {
        usb_start_canvas_waiting = 1;
        usb_start_canvas_seen = mqtt->canvas_revision;
        usb_start_canvas_until = now + usb_start_canvas_wait_ms;
        mqtt->canvas_refresh_due = 1;
        return 1;
    }
    if (mqtt->canvas_revision != usb_start_canvas_seen) return 0;
    if (now < usb_start_canvas_until) return 1;
    return USB_START_CANVAS_SILENT_REFUSES ? -1 : 0;
}
static int usb_start_trays_refuse(int fd) {
    const char *error = "{\"accepted\":false,\"error\":\"The Canvas trays changed while the file was copied; start the print again\"}\n";
    respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
    return 409;
}
static void usb_start_tick(mqtt_client *mqtt) {
    if (!usb_start_active()) return;
    if (!usb_start_cancelled && usb_start_client_gone(usb_start_fd)) usb_start_cancelled = 1;
    int room_asked = 1; /* 1 -> 3: taken up, unless the worker gave up waiting (1 -> 0) first */
    if (atomic_compare_exchange_strong(&usb_start_room, &room_asked, 3)) {
        if (!usb_start_cancelled) gcode_usb_make_room(mqtt, usb_start_room_size, usb_start_room_name);
        atomic_store(&usb_start_room, 2);
    }
    if (usb_start_trays_late && mqtt->canvas_revision != usb_start_trays_late_seen) {
        usb_start_trays_late_seen = mqtt->canvas_revision;
        usb_start_trays_note(mqtt, 0);
        usb_start_trays_late = !usb_start_trays_known; /* a report without the trays: keep waiting */
    }
    /* No report within the wait while the worker still waits (or scans): it stops before it copies (reason 3). */
    if (usb_start_trays_late && !usb_start_cancelled && !atomic_load(&usb_start_done) &&
        monotonic_ms() >= usb_start_trays_late_until) usb_start_cancelled = 3;
    /* A worker without progress for usb_start_stall_ms stands in a read the stick does not answer (Fund 4): the
     * browser is answered now (reason 4); the start stays busy until the worker comes back, then it is cleaned up
     * without a second answer. */
    if (!usb_start_cancelled && !atomic_load(&usb_start_done) &&
        monotonic_ms() - atomic_load(&usb_start_beat) > usb_start_stall_ms) {
        usb_start_cancelled = 4;
        usb_stall.sequence++; usb_stall.hanging = 1; usb_stall.outcome = USB_STALL_NONE;
        usb_stall.removed_ms = usb_stall.probed_ms = 0;
        char error[224];
        snprintf(error, sizeof(error), "{\"accepted\":false,\"reason\":\"usb_unresponsive\",\"stall\":%lu,\"error\":\"The USB stick does not respond; remove it, then start the print again\"}\n",
                 usb_stall.sequence);
        respond(usb_start_fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
        shutdown(usb_start_fd, SHUT_WR);
    }
    if (!atomic_load(&usb_start_done)) { usb_stall_probe(monotonic_ms()); return; }
    if (usb_start_cancelled == 4 && usb_stall.hanging) {
        usb_stall.hanging = 0;
        usb_stall.outcome = atomic_load(&usb_start_read_failed) ? USB_STALL_READ_ERROR : USB_STALL_SLOW;
    }
    int fd = usb_start_fd, status = 409;
    if (usb_start_cancelled == 2) {
        const char *error = "{\"accepted\":false,\"error\":\"Print start cancelled by the emergency stop\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
    } else if (usb_start_cancelled == 4) { /* answered when the stick stopped responding; the queue is told below */
    } else if (usb_start_cancelled == 3) { /* the queue is told below, with the other cancels */
        const char *error = "{\"accepted\":false,\"reason\":\"canvas_unreported\",\"error\":\"The Canvas did not report its trays when the start began; check that the Canvas is connected, then start the print again\"}\n";
        respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
    } else if (!usb_start_cancelled) {
        int waited = usb_start_canvas_wait(mqtt);
        if (waited > 0) return;
        usb_start.stage = USB_START_PREPARED;
        if (waited < 0) {
            const char *error = "{\"accepted\":false,\"reason\":\"canvas_unreported\",\"error\":\"The Canvas did not report its trays after the copy; check that the Canvas is connected, then start the print again\"}\n";
            respond(fd, 409, "Conflict", "application/json; charset=utf-8", error, strlen(error));
            if (usb_start_queue_id) queue_usb_dropped(usb_start_queue_id, usb_start_queue_auto);
        } else if (usb_start_trays_changed(mqtt, usb_start_body, usb_start_length)) {
            status = usb_start_trays_refuse(fd);
            if (usb_start_queue_id) queue_usb_dropped(usb_start_queue_id, usb_start_queue_auto);
        } else status = usb_start_queue_id
                     ? queue_usb_copied(fd, mqtt, usb_start_queue_id, usb_start_queue_auto, usb_start_body,
                                        usb_start_length, &usb_start)
                     : gcode_start_run(fd, mqtt, usb_start_body, usb_start_length, NULL, &usb_start);
    }
    if (usb_start_cancelled && usb_start_queue_id) queue_usb_dropped(usb_start_queue_id, usb_start_queue_auto);
    usb_start_unpublish(&usb_start); /* not sent: the new copy never replaces the earlier one */
    if (status != 202 && usb_start.imported_ok && !usb_start.replaced) {
        char path[PATH_MAX_LOCAL * 2];
        int length = snprintf(path, sizeof(path), "%s/%s", gcode_internal_root, usb_start.imported);
        if (length > 0 && (size_t)length < sizeof(path) && !unlink(path)) layer_store_forget(path);
    }
    usb_start_fd = -1; usb_start_canvas_waiting = 0; usb_start_trays_late = 0;
    close(fd);
    if (usb_start_peer >= 0) close(usb_start_peer);
    usb_start_peer = -1; usb_start_queue_id = usb_start_queue_auto = 0;
}

/* Main loop: the outcome of a watched start (see print_watch_arm). */
static void queue_watch_failed(int id); /* queue.h */
static void print_watch_tick(mqtt_client *mqtt) {
    if (print_watch.state != PRINT_WATCH_WATCHING) return;
    long long waited = monotonic_ms() - print_watch.armed_ms;
    int refused = mqtt->reply_errors != print_watch.errors && mqtt->reply_error_method == 1020;
    int begun = (mqtt->have_machine_status && mqtt->machine_status == 2 && !strcmp(mqtt->print_state, "printing")) ||
                (mqtt->uuid[0] && strcmp(mqtt->uuid, print_watch.uuid));
    if (!refused && begun) { print_watch.state = PRINT_WATCH_STARTED; return; }
    int idle = mqtt->have_machine_status && mqtt->machine_status == 1;
    if (!refused && (waited < print_watch_ms || (!idle && waited < print_watch_cap_ms))) return;
    print_watch.state = PRINT_WATCH_FAILED;
    print_watch.code = refused ? mqtt->reply_error_code : 0;
    fprintf(stderr, "Print start: the printer did not open %s (%s)\n", print_watch.file,
            refused ? "refused" : "no print began");
    if (print_watch.queue_id) queue_watch_failed(print_watch.queue_id);
    if (print_watch.imported) (void)gcode_usb_import_remove(mqtt, print_watch.file);
}

static const char *machine_status_name(int status) {
    static const char *names[]={"Initializing","Idle","Printing","Loading","Unloading","Auto leveling","PID calibration","Resonance test","Self check","Upgrade","Manual homing","File sending","Timelapse generation","Extruding","Emergency stop","Power-loss recovery","Component upgrade","Foreign-object detection"};
    if(status<0)return "Offline";
    return status<(int)(sizeof(names)/sizeof(names[0]))?names[status]:"Unknown";
}

static const char *find_case_insensitive(const char *text, const char *needle) {
    size_t length = strlen(needle);
    if (!length) return text;
    for (; *text; ++text)
        if (strncasecmp(text, needle, length) == 0) return text;
    return NULL;
}

static int positive_integer_after(const char *line, const char *marker) {
    const char *match = find_case_insensitive(line, marker);
    if (!match) return 0;
    match += strlen(marker);
    while (*match && !isdigit((unsigned char)*match)) match++;
    if (!*match) return 0;
    long value = strtol(match, NULL, 10);
    return value > 0 && value <= 1000000 ? (int)value : 0;
}

static double number_after_marker(const char *line, const char *marker) {
    const char *match = find_case_insensitive(line, marker);
    if (!match) return -1.0;
    match += strlen(marker);
    while (*match && !isdigit((unsigned char)*match) && *match != '.' && *match != '-' && *match != '+') match++;
    if (!*match) return -1.0;
    char *end = NULL; double value = strtod(match, &end);
    return end != match && value >= 0.0 ? value : -1.0;
}

#include "gcode_metadata.h"

static long duration_after_marker(const char *line, const char *marker) {
    const char *cursor = find_case_insensitive(line, marker);
    if (!cursor) return -1;
    cursor += strlen(marker);
    long seconds = 0; int found_unit = 0;
    while (*cursor) {
        while (*cursor && !isdigit((unsigned char)*cursor) && *cursor != '.') cursor++;
        if (!*cursor) break;
        char *end = NULL; double value = strtod(cursor, &end);
        if (end == cursor) break;
        while (*end && isspace((unsigned char)*end)) end++;
        if (*end == 'h' || *end == 'H') { seconds += (long)(value * 3600.0); found_unit = 1; }
        else if (*end == 'm' || *end == 'M') { seconds += (long)(value * 60.0); found_unit = 1; }
        else if (*end == 's' || *end == 'S') { seconds += (long)value; found_unit = 1; }
        else if (!found_unit) return (long)value;
        cursor = *end ? end + 1 : end;
    }
    return found_unit ? seconds : -1;
}

static void gcode_metadata_response(int fd, const char *body, size_t body_len) {
    char storage[16], filename[PATH_MAX_LOCAL], path[PATH_MAX_LOCAL * 2], line[4096];
    const char *root, *media;
    if (!gcode_request_file(body, body_len, storage, filename, NULL, NULL, &root, &media) ||
        !gcode_resolved_path(root, filename, path, sizeof(path))) {
        const char *error = "{\"error\":\"File is unavailable or unsafe\"}\n";
        analysis_respond(fd, 404, "Not Found", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    (void)media;
    FILE *file = fopen(path, "r");
    if (!file) {
        const char *error = "{\"error\":\"Cannot open G-code file\"}\n";
        analysis_respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    int layers = 0, maximum_layer = -1; long estimated = -1;
    double filament = -1.0, nozzle = -1.0, bed = -1.0;
    double first_nozzle = -1.0, first_bed = -1.0;
    double commanded_bed = -1.0, waited_bed = -1.0;
    while (fgets(line, sizeof(line), file)) {
        const char *comment=line;while(isspace((unsigned char)*comment))comment++;
        if(*comment!=';') {
            if (waited_bed < 0) {
                int wait = 0;
                double value = gcode_metadata_bed_command(line, &wait);
                if (value >= 0) {
                    if (wait) waited_bed = value;
                    else if (commanded_bed < 0) commanded_bed = value;
                }
            }
            continue;
        }
        static const char *layer_markers[] = {"total layer number", "total_layer_count", "total layers count", "total layers", "layer_count:"};
        for (size_t index = 0; index < sizeof(layer_markers)/sizeof(layer_markers[0]); ++index) {
            int value = positive_integer_after(line, layer_markers[index]); if (value > layers) layers = value;
        }
        const char *layer = find_case_insensitive(line, ";LAYER:");
        if (layer) { int value = positive_integer_after(layer, ";LAYER:"); if (value > maximum_layer) maximum_layer = value; }
        if (estimated < 0) {
            static const char *markers[] = {"estimated printing time", "estimated print time", "total print time"};
            for (size_t index = 0; index < sizeof(markers)/sizeof(markers[0]) && estimated < 0; ++index) estimated = duration_after_marker(line, markers[index]);
        }
        /* Slicers may write an initial zero estimate before the final footer.
         * Keep the latest valid total, summing every tool rather than tool 0. */
        double grams = gcode_metadata_grams(line);
        if (grams >= 0) filament = grams;
        if (nozzle < 0) {
            nozzle = gcode_metadata_number(line, "nozzle_temperature", 500.0);
        }
        if (bed < 0) {
            bed = gcode_metadata_number(line, "bed_temperature", 200.0);
        }
        if (first_nozzle < 0) first_nozzle = gcode_metadata_number(line, "first_layer_temperature", 500.0);
        if (first_bed < 0) first_bed = gcode_metadata_number(line, "first_layer_bed_temperature", 200.0);
        if (first_nozzle < 0) first_nozzle = gcode_metadata_number(line, "nozzle_temperature_initial_layer", 500.0);
        if (first_bed < 0) first_bed = gcode_metadata_number(line, "bed_temperature_initial_layer", 200.0);
    }
    fclose(file);
    if (first_nozzle >= 0) nozzle = first_nozzle;
    if (first_bed >= 0) bed = first_bed;
    if (bed < 0) bed = waited_bed >= 0 ? waited_bed : commanded_bed;
    if (!layers && maximum_layer >= 0) layers = maximum_layer + 1;
    char layer_value[32], time_value[32], filament_value[32], nozzle_value[32], bed_value[32], response[512];
    if (layers > 0) snprintf(layer_value, sizeof(layer_value), "%d", layers); else snprintf(layer_value, sizeof(layer_value), "null");
    if (estimated >= 0) snprintf(time_value, sizeof(time_value), "%ld", estimated); else snprintf(time_value, sizeof(time_value), "null");
    if (filament >= 0) snprintf(filament_value, sizeof(filament_value), "%.3f", filament); else snprintf(filament_value, sizeof(filament_value), "null");
    if (nozzle >= 0) snprintf(nozzle_value, sizeof(nozzle_value), "%.1f", nozzle); else snprintf(nozzle_value, sizeof(nozzle_value), "null");
    if (bed >= 0) snprintf(bed_value, sizeof(bed_value), "%.1f", bed); else snprintf(bed_value, sizeof(bed_value), "null");
    int length = snprintf(response, sizeof(response), "{\"layers\":%s,\"estimated_seconds\":%s,\"filament_grams\":%s,\"nozzle_temperature\":%s,\"bed_temperature\":%s}\n", layer_value, time_value, filament_value, nozzle_value, bed_value);
    if (length > 0 && (size_t)length < sizeof(response)) analysis_respond(fd, 200, "OK", "application/json; charset=utf-8", response, (size_t)length);
}

/* Four pending requests and one 128-KiB worker stack, independent of file size.
 * The worker owns each accepted socket. No MQTT or printer state is accessed. */
#define ANALYSIS_QUEUE_MAX 4
typedef struct {int fd,kind;unsigned generation;size_t length;char body[PATH_MAX_LOCAL+32];} analysis_job;
static analysis_job analysis_queue[ANALYSIS_QUEUE_MAX];
static pthread_mutex_t analysis_mutex=PTHREAD_MUTEX_INITIALIZER;
static size_t analysis_head,analysis_count;
static int analysis_running;
static char active_analysis_filename[PATH_MAX_LOCAL];
/* The file the analysis worker reads right now (resolved path, under analysis_mutex), so a start of the same file
 * waits instead of reading a USB stick from a second thread at the same time. */
static char analysis_reading[PATH_MAX_LOCAL * 2];
static int analysis_reading_file(const char *path) {
    pthread_mutex_lock(&analysis_mutex);
    int same = analysis_reading[0] && !strcmp(analysis_reading, path);
    pthread_mutex_unlock(&analysis_mutex);
    return same;
}
/* Test seam, and what the worker below does around each inspection. */
static void analysis_reading_set(const char *root, const char *name) {
    char path[PATH_MAX_LOCAL * 2] = "";
    if (root && name && !gcode_resolved_path(root, name, path, sizeof(path))) path[0] = 0;
    pthread_mutex_lock(&analysis_mutex);
    snprintf(analysis_reading, sizeof(analysis_reading), "%s", path);
    pthread_mutex_unlock(&analysis_mutex);
}
static int active_analysis_pending, active_analysis_ready, active_analysis_layers;
static unsigned active_analysis_generation;
static long active_analysis_seconds = -1;
static int active_gcode_scan(const char *filename,unsigned generation,int *layers,long *seconds);
static void gcode_read_count_stopped(void);
/* The scan of the running print's file runs at the layer path's lower priority (LAYER_PATH_NICE, idle I/O) on this
 * worker, which also serves inspect and metadata; those keep the priority they had. So the priority is lowered only
 * when it can be set back (root, or RLIMIT_NICE allows it), and set back after the scan. Linux only. */
typedef struct { int lowered, nice, io; } analysis_priority;
static analysis_priority analysis_priority_lower(void) {
    analysis_priority old = {0, 0, -1};
#if defined(__linux__) && defined(SYS_gettid)
    pid_t tid = (pid_t)syscall(SYS_gettid);
    errno = 0;
    int nice_now = getpriority(PRIO_PROCESS, (id_t)tid);
    if (nice_now == -1 && errno) return old;
    int restorable = geteuid() == 0;
#ifdef RLIMIT_NICE
    struct rlimit limit;
    if (!restorable && getrlimit(RLIMIT_NICE, &limit) == 0)
        restorable = limit.rlim_cur == RLIM_INFINITY || 20 - (long)limit.rlim_cur <= nice_now;
#endif
    if (!restorable || nice_now >= LAYER_PATH_NICE) return old;
    if (setpriority(PRIO_PROCESS, (id_t)tid, LAYER_PATH_NICE) != 0) return old;
    old.lowered = 1; old.nice = nice_now;
#ifdef SYS_ioprio_get
    old.io = (int)syscall(SYS_ioprio_get, 1 /* IOPRIO_WHO_PROCESS */, (int)tid);
    if (old.io >= 0) (void)syscall(SYS_ioprio_set, 1, (int)tid, 3 << 13 /* IOPRIO_CLASS_IDLE */);
#endif
#endif
    return old;
}
static void analysis_priority_restore(analysis_priority old) {
#if defined(__linux__) && defined(SYS_gettid)
    if (!old.lowered) return;
    pid_t tid = (pid_t)syscall(SYS_gettid);
#ifdef SYS_ioprio_set
    if (old.io >= 0) (void)syscall(SYS_ioprio_set, 1, (int)tid, old.io);
#endif
    if (setpriority(PRIO_PROCESS, (id_t)tid, old.nice) != 0)
        fprintf(stderr, "File analysis: cannot restore the worker priority\n");
#else
    (void)old;
#endif
}
static int analysis_same_file(const struct stat *a,const struct stat *b) {
    return a->st_dev==b->st_dev && a->st_ino==b->st_ino && a->st_size==b->st_size &&
        a->st_mtim.tv_sec==b->st_mtim.tv_sec && a->st_mtim.tv_nsec==b->st_mtim.tv_nsec &&
        a->st_ctim.tv_sec==b->st_ctim.tv_sec && a->st_ctim.tv_nsec==b->st_ctim.tv_nsec;
}
static void *analysis_worker(void *unused) {
    (void)unused;
    for(;;) {
        pthread_mutex_lock(&analysis_mutex);
        if(!analysis_count){analysis_running=0;pthread_mutex_unlock(&analysis_mutex);return NULL;}
        analysis_job job=analysis_queue[analysis_head];
        analysis_head=(analysis_head+1)%ANALYSIS_QUEUE_MAX;analysis_count--;
        pthread_mutex_unlock(&analysis_mutex);
        if(job.kind==2) {
            int layers=0;long seconds=-1;
            analysis_priority priority=analysis_priority_lower();
            int complete=active_gcode_scan(job.body,job.generation,&layers,&seconds);
            analysis_priority_restore(priority);
            pthread_mutex_lock(&analysis_mutex);
            /* Ended by the read hold: no result; the next /api/printer after the hold starts it again. */
            if(complete && job.generation==active_analysis_generation && !strcmp(job.body,active_analysis_filename)) {
                active_analysis_layers=layers;active_analysis_seconds=seconds;active_analysis_ready=1;
            }
            active_analysis_pending=0;
            pthread_mutex_unlock(&analysis_mutex);
            continue;
        }
        char storage[16],name[PATH_MAX_LOCAL],path[PATH_MAX_LOCAL*2];
        const char *root,*media;struct stat before,after;
        int keyed=gcode_request_file(job.body,job.length,storage,name,NULL,NULL,&root,&media) &&
            gcode_resolved_path(root,name,path,sizeof(path)) && stat(path,&before)==0;
        analysis_cache *cache=&analysis_cached[job.kind];
        if(keyed && cache->valid && !strcmp(path,cache->path) && analysis_same_file(&before,&cache->stamp)) {
            respond(job.fd,200,"OK","application/json; charset=utf-8",cache->response,cache->length);
        } else {
            /* Under the lock: a USB start reads the inspect cache from its own thread. */
            pthread_mutex_lock(&analysis_mutex);cache->valid=0;cache->length=0;pthread_mutex_unlock(&analysis_mutex);
            analysis_capture=cache;
            if(keyed)analysis_reading_set(root,name);
            if(job.kind)gcode_metadata_response(job.fd,job.body,job.length);
            else gcode_inspect_response(job.fd,job.body,job.length);
            if(keyed)analysis_reading_set(NULL,NULL);
            analysis_capture=NULL;
            if(keyed && cache->length && stat(path,&after)==0 && analysis_same_file(&before,&after)) {
                pthread_mutex_lock(&analysis_mutex);
                snprintf(cache->path,sizeof(cache->path),"%s",path);cache->stamp=after;cache->valid=1;
                pthread_mutex_unlock(&analysis_mutex);
            }
        }
        close(job.fd);
    }
}
/* The print dialog inspects the file before it starts it (POST /api/gcode-files/inspect). When that
 * analysis is cached for this very file (same device, inode, size, modification and change time), a
 * USB start takes its leveling and tool decision from it instead of reading the file once more, so a
 * refused start still copies nothing. Returns 1 with `out` filled, 0 when there is no usable entry. */
static int analysis_cached_scan(const char *path, const struct stat *now, gcode_scan_expect *out) {
    char response[sizeof(analysis_cached[0].response) + 1]; int hit = 0;
    pthread_mutex_lock(&analysis_mutex);
    const analysis_cache *cache = &analysis_cached[0];
    if (cache->valid && !strcmp(cache->path, path) && analysis_same_file(now, &cache->stamp) &&
        cache->length < sizeof(response)) {
        memcpy(response, cache->response, cache->length); response[cache->length] = '\0'; hit = 1;
    }
    pthread_mutex_unlock(&analysis_mutex);
    if (!hit) return 0;
    const char *at = strstr(response, "{\"tools\":[");
    if (!at) return 0;
    at += strlen("{\"tools\":[");
    out->tool_count = 0;
    while (*at != ']') {
        char *end = NULL; long tool = strtol(at, &end, 10);
        if (end == at || tool < 0 || tool >= GCODE_TOOLS_MAX || out->tool_count == GCODE_TOOLS_MAX ||
            (out->tool_count && tool <= out->tools[out->tool_count - 1])) return 0;
        out->tools[out->tool_count++] = (int)tool;
        at = end;
        if (*at == ',') at++;
        else if (*at != ']') return 0;
    }
    if (!out->tool_count) return 0;
    if (strstr(response, ",\"adaptive_mesh\":true,")) out->adaptive = 1;
    else if (strstr(response, ",\"adaptive_mesh\":false,")) out->adaptive = 0;
    else return 0;
    return 1;
}
static int analysis_start(int fd,int kind,const char *body,size_t length) {
    if(length>=sizeof(analysis_queue[0].body)) {
        const char *error="{\"error\":\"File request too large\"}\n";
        respond(fd,400,"Bad Request","application/json",error,strlen(error));return 0;
    }
    if(usb_start_reading_file(body,length)) {
        const char *error="{\"reason\":\"start_reading\",\"error\":\"A print start is reading this file right now; open it again once the start is answered\"}\n";
        respond(fd,409,"Conflict","application/json",error,strlen(error));return 0;
    }
    pthread_mutex_lock(&analysis_mutex);
    if(analysis_count==ANALYSIS_QUEUE_MAX) {
        pthread_mutex_unlock(&analysis_mutex);
        const char *error="{\"error\":\"File analysis busy; retry shortly\"}\n";
        respond(fd,503,"Service Unavailable","application/json",error,strlen(error));return 0;
    }
    analysis_job *job=&analysis_queue[(analysis_head+analysis_count)%ANALYSIS_QUEUE_MAX];
    job->fd=fd;job->kind=kind;job->generation=active_analysis_generation;job->length=length;memcpy(job->body,body,length);job->body[length]=0;
    struct timeval timeout={5,0};setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    analysis_count++;
    if(!analysis_running) {
        pthread_attr_t attr;pthread_t thread;
        int ok=pthread_attr_init(&attr);
        if(ok==0){ok=pthread_attr_setstacksize(&attr,128*1024);if(ok==0)ok=pthread_create(&thread,&attr,analysis_worker,NULL);pthread_attr_destroy(&attr);}
        if(ok){analysis_count--;pthread_mutex_unlock(&analysis_mutex);const char *error="{\"error\":\"Cannot start file analysis\"}\n";respond(fd,503,"Service Unavailable","application/json",error,strlen(error));return 0;}
        analysis_running=1;pthread_detach(thread);
    }
    pthread_mutex_unlock(&analysis_mutex);return 1;
}

/* Elegoo's print_status does not consistently expose the total layer count.
 * Cache it from the active local G-code instead of leaving demo data in the UI. */
static long active_gcode_estimated_seconds = -1;

/* The scan of the active print reads the whole file once. It ends early when that print is no longer the active one
 * (finished, stopped, deleted, another print), so a stale scan never keeps a removed file open and its space taken;
 * a job already stale does not open the file at all. A file of 2 GiB or more is not read: the printer program
 * (32-bit stat) cannot open it, so there is no print to describe. While the printer homes, levels, probes or starts a
 * print (gcode_read_hold, see gcode_read_blocked) the scan ends at the next check as well, without a result: seen on
 * the printer (18.11.2026), this scan of a 52 MB file running into the homing of a print start, then the MCU's
 * "Timer too close" (error 803). Returns 0 only then; the scan is started again after the hold. */
#define ACTIVE_SCAN_CHECK_BYTES (64 * 1024)
#define ACTIVE_SCAN_FILE_MAX 2147483647LL
static void (*active_scan_check_hook)(void); /* test seam: called at each check while reading */
static int active_scan_current(unsigned generation) {
    pthread_mutex_lock(&analysis_mutex); int current = generation == active_analysis_generation;
    pthread_mutex_unlock(&analysis_mutex); return current;
}
static int active_gcode_scan(const char *filename,unsigned generation,int *layers,long *seconds) {
    char path[PATH_MAX_LOCAL * 2], line[4096]; struct stat info;
    if (!gcode_resolved_path(gcode_internal_root, filename, path, sizeof(path))) return 1;
    if (!active_scan_current(generation)) return 1;
    if (atomic_load(&gcode_read_hold)) { gcode_read_count_stopped(); return 0; } /* queued before the hold came on */
    if (stat(path, &info) != 0 || (long long)info.st_size > ACTIVE_SCAN_FILE_MAX) return 1;
    FILE *file = fopen(path, "r");
    if (!file) return 1;
    int maximum_layer = -1; size_t unchecked = 0;
    while (fgets(line, sizeof(line), file)) {
        unchecked += strlen(line);
        if (unchecked >= ACTIVE_SCAN_CHECK_BYTES) {
            unchecked = 0;
            if (active_scan_check_hook) active_scan_check_hook();
            if (!active_scan_current(generation)) { fclose(file); *layers = 0; *seconds = -1; return 1; }
            if (atomic_load(&gcode_read_hold)) {
                fclose(file); *layers = 0; *seconds = -1; gcode_read_count_stopped(); return 0;
            }
        }
        const char *comment=line;while(isspace((unsigned char)*comment))comment++;
        if(*comment!=';')continue;
        if(*seconds < 0){
            static const char *time_markers[]={"estimated printing time","estimated print time","total print time"};
            for(size_t i=0;i<sizeof(time_markers)/sizeof(time_markers[0])&&*seconds<0;i++)
                *seconds=duration_after_marker(line,time_markers[i]);
        }
        static const char *markers[] = {
            "total layer number", "total_layer_count", "total layers count",
            "total layers", "layer_count:"
        };
        for (size_t index = 0; index < sizeof(markers)/sizeof(markers[0]); ++index) {
            int value = positive_integer_after(line, markers[index]);
            if (value > *layers) *layers = value;
        }
        const char *layer = find_case_insensitive(line, ";LAYER:");
        if (layer) {
            layer += 7;
            while (*layer && isspace((unsigned char)*layer)) layer++;
            if (isdigit((unsigned char)*layer)) {
                long value = strtol(layer, NULL, 10);
                if (value >= 0 && value < 1000000 && value > maximum_layer)
                    maximum_layer = (int)value;
            }
        }
    }
    fclose(file);
    if (!*layers && maximum_layer >= 0) *layers = maximum_layer + 1;
    return 1;
}

/* `held`: the read hold is on (gcode_read_blocked). Then a result already there is still given, but no scan is
 * started and nothing stays pending; the first call after the hold starts it. Counted once per withheld scan. */
static void gcode_read_count_blocked(void);
static int active_scan_withheld; /* under analysis_mutex */
static int active_gcode_total_layers_at(const char *filename,int held) {
    int layers=0,submit=0,withheld=0;active_gcode_estimated_seconds=-1;
    pthread_mutex_lock(&analysis_mutex);
    if(!filename || !filename[0]) {
        if(active_analysis_filename[0])active_analysis_generation++;
        active_analysis_filename[0]=0;active_analysis_ready=0;
    } else {
        if(strcmp(filename,active_analysis_filename)) {
            active_analysis_generation++;
            snprintf(active_analysis_filename,sizeof(active_analysis_filename),"%s",filename);
            active_analysis_ready=0;active_scan_withheld=0;
        }
        if(active_analysis_ready) {
            layers=active_analysis_layers;active_gcode_estimated_seconds=active_analysis_seconds;
        } else if(!active_analysis_pending && held) {
            if(!active_scan_withheld)withheld=1;
            active_scan_withheld=1;
        } else if(!active_analysis_pending) {
            active_analysis_pending=1;submit=1;active_scan_withheld=0;
        }
    }
    pthread_mutex_unlock(&analysis_mutex);
    if(withheld)gcode_read_count_blocked();
    if(submit && !analysis_start(-1,2,filename,strlen(filename))) {
        pthread_mutex_lock(&analysis_mutex);active_analysis_pending=0;pthread_mutex_unlock(&analysis_mutex);
    }
    return layers;
}
/* The hold as the main loop last passed it on (it also covers this service's console jobs). */
static inline int active_gcode_total_layers(const char *filename) {
    return active_gcode_total_layers_at(filename,atomic_load(&gcode_read_hold));
}
static int gcode_read_blocked(const mqtt_client *mqtt,console_state *console);
/* /api/printer and the layer path's guard: also the printer state of this very moment. */
static int active_gcode_total_layers_now(const mqtt_client *mqtt,const char *filename) {
    return active_gcode_total_layers_at(filename,atomic_load(&gcode_read_hold)||gcode_read_blocked(mqtt,NULL));
}

/* A print of that file is running while the printer reports it printing or paused (or reports no state at all, as
 * before). Once it reports another state (cancelled, complete, standby) or no file, the active scan ends: from the
 * main loop after every MQTT message, so it does not wait for someone to ask /api/printer, and /api/printer starts no
 * scan for a print that is over. */
static int active_scan_print_running(const mqtt_client *mqtt) {
    return mqtt->filename[0] && (!mqtt->print_state[0] || !strcmp(mqtt->print_state, "printing") ||
                                 !strcmp(mqtt->print_state, "paused"));
}
static void active_scan_follow(const mqtt_client *mqtt) {
    if (active_scan_print_running(mqtt)) return;
    pthread_mutex_lock(&analysis_mutex);
    if (active_analysis_filename[0]) { active_analysis_generation++; active_analysis_filename[0] = 0; active_analysis_ready = 0; }
    pthread_mutex_unlock(&analysis_mutex);
}

#include "recovery.h"

/* The page that last started live view. The UI streams the camera from one
 * page at a time: a page that sees another viewer in /api/printer stops its own
 * stream. Only the main loop touches it, so it needs no lock. */
static char camera_viewer[41];

static int camera_viewer_valid(const char *id, size_t length) {
    if (length < 8 || length >= sizeof(camera_viewer)) return 0;
    for (size_t i = 0; i < length; ++i)
        if (!(isdigit((unsigned char)id[i]) || (id[i] >= 'a' && id[i] <= 'z') || id[i] == '-')) return 0;
    return 1;
}

static void camera_claim_response(int fd, const char *body, size_t length) {
    while (length && isspace((unsigned char)body[length - 1])) length--;
    if (!camera_viewer_valid(body, length)) {
        static const char error[] = "{\"error\":\"Invalid camera viewer\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, sizeof(error) - 1);
        return;
    }
    memcpy(camera_viewer, body, length);
    camera_viewer[length] = '\0';
    char reply[64];
    int n = snprintf(reply, sizeof(reply), "{\"viewer\":\"%s\"}\n", camera_viewer);
    if (n > 0 && (size_t)n < sizeof(reply))
        respond(fd, 200, "OK", "application/json; charset=utf-8", reply, (size_t)n);
}

static void spools_summary(char *out, size_t cap);

static void printer_report_json(char *out,size_t size,unsigned long sequence,int code,int level,
                                const char *message,struct timespec identity,struct timespec received) {
    if(!sequence){snprintf(out,size,"null");return;}
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC,&now);
    long age=now.tv_sec-received.tv_sec;
    snprintf(out,size,
        "{\"event_id\":\"%ld.%09ld-%lu\",\"sequence\":%lu,\"code\":%d,\"level\":%d,\"message\":%s,\"age\":%ld}",
        (long)identity.tv_sec,identity.tv_nsec,sequence,sequence,code,level,message,age<0?0:age);
}

/* GET /api/printer: the hold time before a screw measurement (screws_soak below). */
static void screws_soak_json(char *out, size_t cap);
static void printer_response(int fd, const mqtt_client *mqtt) {
    /* Render from the two caches without copying MQTT transport/history buffers. */
    double live;
    int progress=mqtt->progress,current_layer=mqtt->current_layer;
    long duration=mqtt->print_duration;
    if(uds_job_matches(&telemetry,mqtt->filename)){
        if(uds_value(&telemetry,U_PROGRESS,&live))progress=(int)(live*100);
        if(uds_value(&telemetry,U_LAYER,&live))current_layer=(int)live;
        if(uds_value(&telemetry,U_DURATION,&live))duration=(long)live;
    }
    char et[32], eg[32], bt[32], bg[32], ct[32], cf[32], hf[32], pf[32];
    char body[10496],filename[520],state[140],uuid[260],axes[40],drying_status[1024];
    drying_status_json(drying_status,sizeof(drying_status),mqtt);
    char native_job[1400]="null",native_filename[1100],native_state[40],native_seconds[40];
    const char *native=uds_print_state(&telemetry);double native_duration;
    if(native){
        json_escape(native_filename,sizeof(native_filename),telemetry.have_filename?telemetry.filename:"");
        int have_native_duration=uds_value(&telemetry,U_DURATION,&native_duration);
        json_number(native_seconds,sizeof(native_seconds),have_native_duration,have_native_duration?native_duration:0);
        json_escape(native_state,sizeof(native_state),native);
        snprintf(native_job,sizeof(native_job),"{\"state\":\"%s\",\"filename\":\"%s\",\"duration\":%s}",native_state,native_filename,native_seconds);
    }
    if(uds_value(&telemetry,U_ET,&live))json_number(et,sizeof(et),1,live);
    else json_number(et,sizeof(et),mqtt->have_extruder_temp,mqtt->extruder_temp);
    if(uds_value(&telemetry,U_EG,&live))json_number(eg,sizeof(eg),1,live);
    else json_number(eg,sizeof(eg),mqtt->have_extruder_target,mqtt->extruder_target);
    if(uds_value(&telemetry,U_BT,&live))json_number(bt,sizeof(bt),1,live);
    else json_number(bt,sizeof(bt),mqtt->have_bed_temp,mqtt->bed_temp);
    if(uds_value(&telemetry,U_BG,&live))json_number(bg,sizeof(bg),1,live);
    else json_number(bg,sizeof(bg),mqtt->have_bed_target,mqtt->bed_target);
    json_number(ct,sizeof(ct),mqtt->have_chamber_temp,mqtt->chamber_temp);
    char screws_bed[16]="null"; /* the bed target of a running screw session, whole degrees */
    if(control_screws_session_active())snprintf(screws_bed,sizeof(screws_bed),"%d",control_screws_bed());
    char screws_soak_state[320];
    screws_soak_json(screws_soak_state,sizeof(screws_soak_state));
    if(uds_value(&telemetry,U_CF,&live))json_number(cf,sizeof(cf),1,live*255);
    else json_number(cf,sizeof(cf),mqtt->have_controller_fan,mqtt->controller_fan);
    if(uds_value(&telemetry,U_HF,&live))json_number(hf,sizeof(hf),1,live*255);
    else json_number(hf,sizeof(hf),mqtt->have_heater_fan,mqtt->heater_fan);
    if(uds_value(&telemetry,U_PF,&live))json_number(pf,sizeof(pf),1,live*255);
    else json_number(pf,sizeof(pf),mqtt->have_part_fan,mqtt->part_fan);
    json_escape(filename,sizeof(filename),mqtt->filename);json_escape(state,sizeof(state),mqtt->print_state);
    json_escape(uuid,sizeof(uuid),mqtt->uuid);json_escape(axes,sizeof(axes),mqtt->homed_axes);
    time_t now=time(NULL);
    long age=mqtt->last_message ? (long)(now-mqtt->last_message) : -1;
    int file_layers=active_gcode_total_layers_now(mqtt,active_scan_print_running(mqtt)?mqtt->filename:NULL);
    int total_layers=mqtt->have_total_layers ? mqtt->total_layers : file_layers;
    long remaining=mqtt->remaining_time;
    const char *remaining_source=remaining>0 ? "mqtt" : "unavailable";
    int active_job=mqtt->connected&&mqtt->registered&&mqtt->last_message>0&&
        now-mqtt->last_message<=15&&mqtt->have_machine_status&&mqtt->machine_status==2&&
        mqtt->filename[0]&&(!strcmp(mqtt->print_state,"printing")||!strcmp(mqtt->print_state,"paused"));
    if(active_job&&remaining<=0&&active_gcode_estimated_seconds>0&&duration>=0){
        remaining=active_gcode_estimated_seconds>duration ? active_gcode_estimated_seconds-duration : 0;
        remaining_source="gcode";
    }
    char speed_percent[40],flow_percent[40],live_velocity[40],pressure_advance[40];double tune;
    int have_speed=uds_value(&telemetry,U_SPEED_FACTOR,&tune);
    json_number(speed_percent,sizeof(speed_percent),have_speed,have_speed?tune*100:0);
    int have_flow=uds_value(&telemetry,U_FLOW_FACTOR,&tune);
    json_number(flow_percent,sizeof(flow_percent),have_flow,have_flow?tune*100:0);
    int have_velocity=uds_value(&telemetry,U_LIVE_SPEED,&tune);
    json_number(live_velocity,sizeof(live_velocity),have_velocity,have_velocity?tune:0);
    int have_pressure=uds_value(&telemetry,U_PRESSURE_ADVANCE,&tune);
    if(have_pressure)snprintf(pressure_advance,sizeof(pressure_advance),"%.6f",tune);
    else snprintf(pressure_advance,sizeof(pressure_advance),"null");
    char zoffset[32],zreference[32],zadjustment[32];double offset;
    int have_offset=z_offset_readback(&offset);
    json_z_offset(zoffset,sizeof(zoffset),have_offset,have_offset?offset:0);
    double reference=z_offset_session?z_offset_reference:(have_offset?offset:0);
    json_z_offset(zreference,sizeof(zreference),have_offset,reference);
    json_z_offset(zadjustment,sizeof(zadjustment),have_offset,have_offset?offset-reference:0);
    /* The latest refusal of one of our MQTT requests (start, auto refill, history, time-lapse). */
    char printer_error[160]="null";
    if(mqtt->reply_errors)snprintf(printer_error,sizeof(printer_error),"{\"sequence\":%lu,\"method\":%d,\"code\":%d,\"age\":%ld}",
        mqtt->reply_errors,mqtt->reply_error_method,mqtt->reply_error_code,(long)(now-mqtt->reply_error_time));
    /* A watched start of a confirmed file of 2 GiB or more (print_watch_tick), and a USB read that stopped answering. */
    char watch_state[96]="null",stall_state[160];
    if(print_watch.sequence){
        static const char *names[]={"none","watching","started","failed"};
        snprintf(watch_state,sizeof(watch_state),"{\"sequence\":%lu,\"state\":\"%s\",\"code\":%d}",
            print_watch.sequence,names[print_watch.state],print_watch.code);
    }
    usb_stall_json(stall_state,sizeof(stall_state));
    char printer_report[1280],printer_alert[1280];
    printer_report_json(printer_report,sizeof(printer_report),telemetry.report_sequence,
        telemetry.report_code,telemetry.report_level,telemetry.report_message,telemetry.report_identity,telemetry.report_received);
    printer_report_json(printer_alert,sizeof(printer_alert),telemetry.alert.sequence,
        telemetry.alert.code,telemetry.alert.level,telemetry.alert.message,telemetry.alert.identity,telemetry.alert.received);
    char motor_mode[16]="null";
    if(motor_mode_requested&&telemetry.fd>=0&&telemetry.connections==motor_mode_connection)
        snprintf(motor_mode,sizeof(motor_mode),"\"%s\"",motor_mode_requested);
    char viewer[sizeof(camera_viewer)+2];
    if(camera_viewer[0])snprintf(viewer,sizeof(viewer),"\"%s\"",camera_viewer);
    else snprintf(viewer,sizeof(viewer),"null");
    char spool_state[128];
    spools_summary(spool_state,sizeof(spool_state));
    int length=snprintf(body,sizeof(body),
        "{\"connected\":%s,\"messages\":%lu,\"last_message_age\":%ld,"
        "\"extruder\":{\"temperature\":%s,\"target\":%s},"
        "\"heater_bed\":{\"temperature\":%s,\"target\":%s},"
        "\"chamber\":{\"temperature\":%s},"
        "\"fans\":{\"controller\":%s,\"heater\":%s,\"part\":%s,\"aux\":%.1f,\"box\":%.1f},"
        "\"machine\":{\"status\":%d,\"status_name\":\"%s\",\"sub_status\":%d,\"reason\":%d,\"progress\":%d},"
        "\"print\":{\"enabled\":%s,\"filename\":\"%s\",\"state\":\"%s\",\"uuid\":\"%s\",\"current_layer\":%d,\"total_layers\":%d,\"duration\":%ld,\"remaining\":%ld,\"remaining_source\":\"%s\",\"total_duration\":%ld,\"native\":%s},"
        "\"motion\":{\"x\":%.3f,\"y\":%.3f,\"z\":%.3f,\"speed\":%.1f,\"speed_mode\":%d,\"homed_axes\":\"%s\"},"
        "\"tuning\":{\"speed_percent\":%s,\"flow_percent\":%s,\"live_velocity\":%s,\"pressure_advance\":%s},"
        "\"z_offset\":{\"value\":%s,\"pending\":%s,\"timed_out\":%s,\"reference\":%s,\"adjustment\":%s},"
        "\"recovery\":{\"available\":%s,\"reboot_pending\":%s,\"error\":\"%s\"},"
        "\"hardware\":{\"camera\":%s,\"usb\":%s,\"light\":%d,\"filament_detection\":%s,\"filament_detected\":%s},"
        "\"spools\":%s,\"printer_report\":%s,\"printer_alert\":%s,\"printer_error\":%s,\"print_watch\":%s,\"usb_stall\":%s,\"camera_viewer\":%s,\"motor_mode\":%s,\"experiments\":{\"quiet_motors\":%s,\"canvas_uds\":%s,\"bed_drying\":%s},\"bed_drying\":%s,\"screws_session\":{\"active\":%s,\"xy_homed\":%s,\"bed\":%s},\"screws_soak\":%s,\"screws_after_mesh\":%s}\n",
        mqtt->connected?"true":"false",mqtt->messages,age,et,eg,bt,bg,ct,cf,hf,pf,
        mqtt->aux_fan,mqtt->box_fan,mqtt->machine_status,machine_status_name(mqtt->machine_status),mqtt->sub_status,mqtt->sub_status_reason,progress,
        mqtt->print_enabled?"true":"false",filename,state,uuid,current_layer,total_layers,duration,remaining,remaining_source,mqtt->total_duration,native_job,
        mqtt->x,mqtt->y,mqtt->z,mqtt->move_speed,mqtt->speed_mode,axes,speed_percent,flow_percent,live_velocity,pressure_advance,zoffset,z_offset_pending?"true":"false",z_offset_timed_out?"true":"false",zreference,zadjustment,recovery_available()?"true":"false",reboot_pending?"true":"false",reboot_error,mqtt->camera?"true":"false",mqtt->u_disk?"true":"false",mqtt->led_status,
        mqtt->filament_detect_enabled?"true":"false",mqtt->filament_detected?"true":"false",spool_state,printer_report,printer_alert,
        printer_error,watch_state,stall_state,viewer,motor_mode,experiments.quiet_motors?"true":"false",telemetry.canvas_enabled?"true":"false",experiments.bed_drying?"true":"false",drying_status,
        control_screws_session_active()?"true":"false",
        control_screws_xy_homed(mqtt)?"true":"false",screws_bed,screws_soak_state,
        control_screws_after_mesh_running()?"true":"false");
    if(length>0&&(size_t)length<sizeof(body))
        respond(fd,200,"OK","application/json; charset=utf-8",body,(size_t)length);
}

static void uds_response(int fd){
    static const char *names[U_FIELDS]={"nozzle_temperature","nozzle_target","bed_temperature","bed_target",
        "controller_fan","heater_fan","part_fan","fan1","controller_rpm","heater_rpm","part_rpm","fan1_rpm",
        "speed_factor","extrude_factor","live_velocity","progress","current_layer","print_duration","total_elapsed","z_offset",
        "filament_used","canvas_channel","cavity_temperature_mode","pressure_advance"};
    char body[2048];json_builder b={body,0,sizeof(body),0};
    json_builder_printf(&b,"{\"connected\":%s,\"fresh\":%s,\"messages\":%lu,\"connections\":%lu,\"disconnects\":%lu,\"last_disconnect\":\"%s\",\"last_errno\":%d,\"ignored_messages\":%lu,\"values\":{",
        telemetry.fd>=0?"true":"false",uds_fresh(&telemetry)?"true":"false",telemetry.messages,
        telemetry.connections,telemetry.disconnects,telemetry.last_disconnect?telemetry.last_disconnect:"none",telemetry.last_errno,telemetry.ignored_messages);
    for(int i=0;i<U_FIELDS;i++){
        double value;int have=uds_value(&telemetry,(enum uds_field)i,&value);
        json_builder_printf(&b,"%s\"%s\":",i?",":"",names[i]);
        if(have)json_builder_printf(&b,"%.6f",value);else json_builder_printf(&b,"null");
    }
    const char *state=uds_print_state(&telemetry);
    json_builder_printf(&b,"},\"print_state\":");
    if(state)json_builder_printf(&b,"\"%s\"",state);else json_builder_printf(&b,"null");
    json_builder_printf(&b,",\"homed_axes\":");
    if(uds_fresh(&telemetry)&&telemetry.have_homed_axes)json_builder_printf(&b,"\"%s\"",telemetry.homed_axes);
    else json_builder_printf(&b,"null");
    json_builder_printf(&b,",\"light\":");
    if(uds_fresh(&telemetry)&&telemetry.have_light)json_builder_printf(&b,"%s",telemetry.light?"true":"false");
    else json_builder_printf(&b,"null");
    json_builder_printf(&b,",\"canvas_uds_enabled\":%s,\"canvas_uds_available\":%s",
        telemetry.canvas_enabled?"true":"false",uds_canvas_available(&telemetry)?"true":"false");
    json_builder_printf(&b,"}\n");
    if(!b.failed)respond(fd,200,"OK","application/json",body,b.length);
}

static void snapshot_response(int fd, const mqtt_client *mqtt) {
    if(mqtt->snapshot_len)
        respond(fd,200,"OK","application/json; charset=utf-8",mqtt->snapshot,mqtt->snapshot_len);
    else {
        const char *body="{\"available\":false}\n";
        respond(fd,200,"OK","application/json; charset=utf-8",body,strlen(body));
    }
}

static void mqtt_diagnostic_response(int fd, const mqtt_client *mqtt) {
    size_t cap=mqtt->diagnostic_len+512;
    char *body=malloc(cap);
    if(!body){respond(fd,503,"Service Unavailable","text/plain","Diagnostic unavailable\n",23);return;}
    size_t n=mqtt_discovery_diagnostic(mqtt,body,cap);
    if(mqtt->diagnostic_len){memcpy(body+n,mqtt->diagnostic,mqtt->diagnostic_len);n+=mqtt->diagnostic_len;}
    respond(fd,200,"OK","text/plain; charset=utf-8",body,n);
    free(body);
}

/* The lifecycle verifier needs the native MQTT reply even when the UI uses UDS. */
static void canvas_lifecycle_observation_response(int fd, mqtt_client *mqtt) {
    struct sockaddr_in peer;
    socklen_t peer_size=sizeof(peer);
    if(getpeername(fd,(struct sockaddr *)&peer,&peer_size)||peer_size!=sizeof(peer)||
       peer.sin_family!=AF_INET||peer.sin_addr.s_addr!=htonl(INADDR_LOOPBACK)){
        respond(fd,403,"Forbidden","text/plain","Forbidden",9);return;
    }
    mqtt->canvas_watch_until=time(NULL)+15;
    size_t length=mqtt->canvas_snapshot_len;
    char body[sizeof(mqtt->canvas_snapshot)+160];
    json_builder b={body,0,sizeof(body),0};
    json_builder_printf(&b,"{\"available\":%s,\"machine_status\":%d,\"source\":\"mqtt\"",
        mqtt->registered&&length?"true":"false",mqtt->machine_status);
    if(length)json_builder_printf(&b,",\"telemetry\":%.*s",(int)length,mqtt->canvas_snapshot);
    json_builder_printf(&b,"}\n");
    if(!b.failed)respond(fd,200,"OK","application/json",body,b.length);
}

static void canvas_response(int fd, const mqtt_client *mqtt) {
    size_t snapshot_length;const char *snapshot=mqtt_canvas_snapshot(mqtt,&snapshot_length);
    size_t cap=snapshot_length+2304;
    char *body=malloc(cap);if(!body)return;
    json_builder b={body,0,cap,0};
    json_builder_printf(&b,"{\"available\":%s,\"active_tray_id\":%d,\"machine_status\":%d,\"auto_refill\":%s,\"source\":\"%s\",\"slots\":[",
      snapshot_length?"true":"false",mqtt->canvas_uds_ready?telemetry.canvas.active_cid:(mqtt->have_canvas_active_tray?mqtt->canvas_active_tray_id:-1),
      mqtt->machine_status,mqtt->canvas_uds_ready?(telemetry.canvas.auto_refill?"true":"false"):(mqtt->have_auto_refill?(mqtt->auto_refill?"true":"false"):"null"),mqtt->canvas_uds_ready?"uds":"mqtt");
    for(int i=0;i<4;i++){
      canvas_slot_view v=canvas_slot_policy(mqtt,i);
      json_builder_printf(&b,"%s{\"slot\":%d,\"state\":\"%s\",\"load\":%s,\"unload\":%s,\"recovery_load\":%s,\"reason_load\":\"%s\",\"reason_unload\":\"%s\"}",
        i?",":"",i,canvas_kind_name(v.state),v.load?"true":"false",v.unload?"true":"false",
        canvas_recovery_load_allowed(mqtt,i)?"true":"false",
        canvas_reason_name(v.reason_load),canvas_reason_name(v.reason_unload));
    }
    json_builder_printf(&b,"]");
    if(snapshot_length)json_builder_printf(&b,",\"telemetry\":%.*s",(int)snapshot_length,snapshot);
    json_builder_printf(&b,"}\n");
    if(!b.failed)respond(fd,200,"OK","application/json; charset=utf-8",body,b.length);
    free(body);
}

/* OrcaSlicer's Moonraker printer agent connects through /server/info and pulls
 * filament slots from the AFC lane_data namespace. Lanes are built from the
 * connected Canvas module in the cached snapshot, the same module the web UI shows. */
static const char *json_string_end(const char *p,const char *end){
    for(++p;p<end;++p){
        if(*p=='\\'){if(++p>=end)return NULL;}
        else if(*p=='"')return p+1;
    }
    return NULL;
}

static const char *json_container_end(const char *p,const char *end){
    int depth=0;
    while(p<end){
        if(*p=='"'){p=json_string_end(p,end);if(!p)return NULL;continue;}
        if(*p=='{'||*p=='[')depth++;
        else if((*p=='}'||*p==']')&&--depth==0)return p+1;
        p++;
    }
    return NULL;
}

static const char *json_skip_space(const char *p,const char *end){
    while(p<end&&isspace((unsigned char)*p))p++;
    return p;
}

/* Returns the start of the value of a top-level member of the object [obj,end). */
static const char *json_member(const char *obj,const char *end,const char *key){
    size_t key_len=strlen(key);
    const char *p=obj+1;
    while(1){
        p=json_skip_space(p,end);
        if(p<end&&*p==',')p=json_skip_space(p+1,end);
        if(p>=end||*p!='"')return NULL;
        const char *key_end=json_string_end(p,end);if(!key_end)return NULL;
        int match=(size_t)(key_end-p-2)==key_len&&memcmp(p+1,key,key_len)==0;
        p=json_skip_space(key_end,end);
        if(p>=end||*p!=':')return NULL;
        p=json_skip_space(p+1,end);
        if(p>=end)return NULL;
        if(match)return p;
        if(*p=='{'||*p=='[')p=json_container_end(p,end);
        else if(*p=='"')p=json_string_end(p,end);
        else while(p<end&&*p!=','&&*p!='}')p++;
        if(!p)return NULL;
    }
}

static const char *json_member_object(const char *obj,const char *end,const char *key,char open,const char **value_end){
    const char *value=json_member(obj,end,key);
    if(!value||*value!=open)return NULL;
    *value_end=json_container_end(value,end);
    return *value_end?value:NULL;
}

static int json_member_int(const char *obj,const char *end,const char *key,int *out){
    const char *value=json_member(obj,end,key);
    if(!value||!(isdigit((unsigned char)*value)||*value=='-'))return 0;
    /* atoi has no defined result for a number outside int (it truncated 2147483648 to -2147483648): such a number, and a
     * sign without digits, are "not present", like a missing member. */
    char *digits_end;errno=0;
    long number=strtol(value,&digits_end,10);
    if(digits_end==value||errno==ERANGE||number<INT_MIN||number>INT_MAX)return 0;
    *out=(int)number;return 1;
}

/* Raw JSON string contents without quotes; escapes stay as they are. */
static int json_member_raw_string(const char *obj,const char *end,const char *key,const char **text,int *length){
    const char *value=json_member(obj,end,key);
    if(!value||*value!='"')return 0;
    const char *value_end=json_string_end(value,end);
    if(!value_end)return 0;
    *text=value+1;*length=(int)(value_end-value-2);return 1;
}

/* Iterates the elements of the array [array,end). */
static const char *json_next_element(const char *p,const char *end){
    p=json_skip_space(p,end);
    if(p<end&&(*p=='['||*p==','))p=json_skip_space(p+1,end);
    return p<end&&*p=='{'?p:NULL;
}

static void lane_data_build(const mqtt_client *mqtt,json_builder *builder){
    size_t snapshot_length;const char *snapshot=mqtt_canvas_snapshot(mqtt,&snapshot_length),*end=snapshot+snapshot_length;
    const char *root=json_skip_space(snapshot,end),*root_end,*result_end,*info_end,*list_end,*trays_end;
    if(root>=end||*root!='{'||!(root_end=json_container_end(root,end)))return;
    const char *result=json_member_object(root,root_end,"result",'{',&result_end);
    const char *info=result?json_member_object(result,result_end,"canvas_info",'{',&info_end):NULL;
    const char *list=info?json_member_object(info,info_end,"canvas_list",'[',&list_end):NULL;
    if(!list)return;
    const char *module=NULL,*module_end=NULL;
    for(const char *item=json_next_element(list,list_end);item;){
        const char *item_end=json_container_end(item,list_end);
        if(!item_end)return;
        int connected=0,is_connected=json_member_int(item,item_end,"connected",&connected)&&connected==1;
        if(!module||is_connected){module=item;module_end=item_end;}
        if(is_connected)break;
        item=json_next_element(item_end,list_end);
    }
    const char *trays=module?json_member_object(module,module_end,"tray_list",'[',&trays_end):NULL;
    if(!trays)return;
    int count=0;
    for(const char *tray=json_next_element(trays,trays_end);tray;){
        const char *tray_end=json_container_end(tray,trays_end);
        if(!tray_end)return;
        int tray_id,nozzle=0,material_len=0,color_len=0;
        const char *material="",*color="";
        if(json_member_int(tray,tray_end,"tray_id",&tray_id)&&tray_id>=0){
            json_member_raw_string(tray,tray_end,"filament_type",&material,&material_len);
            json_member_raw_string(tray,tray_end,"filament_color",&color,&color_len);
            json_member_int(tray,tray_end,"max_nozzle_temp",&nozzle);
            json_builder_printf(builder,"%s\"lane%d\":{\"lane\":\"%d\",\"material\":\"%.*s\",\"color\":\"%.*s\",\"nozzle_temp\":%d,\"bed_temp\":0}",
                count++?",":"",tray_id+1,tray_id,material_len,material,color_len,color,nozzle);
        }
        tray=json_next_element(tray_end,trays_end);
    }
}

static void orca_server_info_response(int fd, const mqtt_client *mqtt) {
    int ready=mqtt->connected&&mqtt->registered;
    char body[160];
    int length=snprintf(body,sizeof(body),
        "{\"result\":{\"klippy_connected\":%s,\"klippy_state\":\"%s\",\"hostname\":\"CC2\",\"components\":[]}}\n",
        ready?"true":"false",ready?"ready":"disconnected");
    if(length>0&&(size_t)length<sizeof(body))
        respond(fd,200,"OK","application/json; charset=utf-8",body,(size_t)length);
}

static void orca_lane_data_response(int fd, const mqtt_client *mqtt) {
    static const char prefix[]="{\"result\":{\"namespace\":\"lane_data\",\"value\":{";
    size_t snapshot_length;(void)mqtt_canvas_snapshot(mqtt,&snapshot_length);
    size_t cap=sizeof(prefix)+snapshot_length*4+64;
    char *data=malloc(cap);
    if(!data)return;
    json_builder builder={data,0,cap,0};
    json_builder_printf(&builder,"%s",prefix);
    size_t lanes_start=builder.length;
    lane_data_build(mqtt,&builder);
    if(builder.failed){builder.failed=0;builder.length=lanes_start;}
    json_builder_printf(&builder,"}}}\n");
    if(!builder.failed)respond(fd,200,"OK","application/json; charset=utf-8",data,builder.length);
    free(data);
}

static void canvas_refresh_response(int fd, mqtt_client *mqtt) {
    if(mqtt_sync_canvas(mqtt)!=0) {
        const char *body="{\"accepted\":false,\"error\":\"MQTT API client is not ready\"}\n";
        respond(fd,503,"Service Unavailable","application/json; charset=utf-8",body,strlen(body));return;
    }
    const char *body="{\"accepted\":true,\"method\":2005}\n";
    respond(fd,202,"Accepted","application/json; charset=utf-8",body,strlen(body));
}

/* Canvas auto refill: switch to another slot with the same filament when one runs out.
 * Only offered once the printer has reported the setting (fail closed on old firmware). */
static void canvas_auto_refill_response(int fd,mqtt_client *mqtt,const char *body,size_t body_len){
    while(body_len&&isspace((unsigned char)*body)){body++;body_len--;}
    while(body_len&&isspace((unsigned char)body[body_len-1]))body_len--;
    int enabled=body_len==2&&!memcmp(body,"on",2)?1:body_len==3&&!memcmp(body,"off",3)?0:-1;
    const char *error=NULL;int status=409;
    if(enabled<0){error="{\"accepted\":false,\"error\":\"Use on or off\"}\n";status=400;}
    else if(!mqtt->have_auto_refill)error="{\"accepted\":false,\"error\":\"The printer has not reported Canvas auto refill\"}\n";
    else if(mqtt_set_auto_refill(mqtt,enabled)!=0){error="{\"accepted\":false,\"error\":\"MQTT API client is not ready\"}\n";status=503;}
    if(error){respond(fd,status,status==400?"Bad Request":status==503?"Service Unavailable":"Conflict","application/json; charset=utf-8",error,strlen(error));return;}
    const char *ok="{\"accepted\":true,\"method\":2004}\n";
    respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));
}

#include "history.h"

#define EXCLUDE_OBJECT_RESPONSE_MAX (256UL * 1024UL)

static char *exclude_objects_cache = NULL;
static size_t exclude_objects_cache_len = 0;
static char exclude_objects_cache_job[256] = "";
static long long exclude_objects_asked_ms = LLONG_MIN / 2, exclude_objects_wait_ms = 5000;

/* The object list is cached for the whole job above.  The excluded/current
 * fields come from the telemetry subscription; while it is unavailable they
 * need a synchronous UDS round trip.  Share a very short-lived copy between
 * HTTP clients so several dashboards cannot multiply that printer-side work. */
static char *exclude_dynamic_cache = NULL;
static size_t exclude_dynamic_cache_len = 0;
static char exclude_dynamic_cache_job[256] = "";
static long long exclude_dynamic_cache_ms = 0;

static long long monotonic_ms(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

/* Separate from telemetry: object replies can be much larger than subscriptions.
 * Keep successful RPC sessions open to avoid printer-side reactor churn. */
static int object_query_fd = -1;
static const char *object_query_path = "/tmp/elegoo_uds";
static long long object_query_retry_ms;
static unsigned long object_query_id = 1000;
static char *object_query_buffer;
static size_t object_query_used, object_query_capacity;

static void object_query_close(void) {
    if (object_query_fd >= 0) close(object_query_fd);
    object_query_fd = -1;
    free(object_query_buffer);
    object_query_buffer = NULL;
    object_query_used = object_query_capacity = 0;
}

static int object_query_wait(short events, long long deadline) {
    for (;;) {
        long long remaining = deadline - monotonic_ms();
        if (remaining <= 0) return -1;
        struct pollfd p = {object_query_fd, events, 0};
        int rc = poll(&p, 1, (int)remaining);
        if (rc < 0 && errno == EINTR) continue;
        if (rc <= 0 || !(p.revents & events)) return -1;
        return 0;
    }
}

static int uds_query_json(const char *query, char **result_out, size_t *length_out) {
    *result_out = NULL; *length_out = 0;
    long long now = monotonic_ms(), deadline = now + 2000;
    if (object_query_fd < 0) {
        if (now < object_query_retry_ms) return -1;
        struct sockaddr_un address; memset(&address, 0, sizeof(address));
        address.sun_family = AF_UNIX;
        if (strlen(object_query_path) >= sizeof(address.sun_path)) return -1;
        strcpy(address.sun_path, object_query_path);
        object_query_fd = socket(AF_UNIX, SOCK_STREAM, 0);
        if (object_query_fd < 0) goto failed;
        if (fcntl(object_query_fd, F_SETFL, O_NONBLOCK) < 0) goto failed;
        if (connect(object_query_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
            if (errno != EINPROGRESS || object_query_wait(POLLOUT, deadline)) goto failed;
            int error = 0; socklen_t length = sizeof(error);
            if (getsockopt(object_query_fd, SOL_SOCKET, SO_ERROR, &error, &length) || error) goto failed;
        }
    }
    /* Replace the fixed caller ID with a unique session request ID. */
    const char *rest = strchr(query, ',');
    if (!rest || object_query_id == ULONG_MAX) goto failed;
    unsigned long id = ++object_query_id;
    char request[512];
    int size = snprintf(request, sizeof(request), "{\"id\":%lu%s", id, rest);
    if (size < 0 || (size_t)size >= sizeof(request)) goto failed;
    size_t sent = 0;
    while (sent < (size_t)size) {
        if (object_query_wait(POLLOUT, deadline)) goto failed;
        ssize_t n = send(object_query_fd, request + sent, (size_t)size - sent, MSG_NOSIGNAL);
        if (n < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        if (n <= 0) goto failed;
        sent += (size_t)n;
    }
    for (;;) {
        if (monotonic_ms() >= deadline) goto failed;
        char *terminator = object_query_used ? memchr(object_query_buffer, 3, object_query_used) : NULL;
        if (terminator) {
            size_t length = (size_t)(terminator - object_query_buffer);
            const char *end = object_query_buffer + length;
            const char *root = json_skip_space(object_query_buffer, end);
            const char *root_end = root < end && *root == '{' ? json_container_end(root, end) : NULL;
            const char *value = root_end && json_skip_space(root_end, end) == end ?
                json_member(root, root_end, "id") : NULL;
            char *number_end = NULL;
            unsigned long received = value ? strtoul(value, &number_end, 10) : 0;
            int matches = value && isdigit((unsigned char)*value) && received == id &&
                number_end < root_end && (*number_end == ',' || *number_end == '}' || isspace((unsigned char)*number_end));
            char *result = matches ? malloc(length + 1) : NULL;
            if (matches && !result) goto failed;
            if (matches) { memcpy(result, object_query_buffer, length); result[length] = 0; }
            size_t consumed = length + 1;
            memmove(object_query_buffer, object_query_buffer + consumed, object_query_used - consumed);
            object_query_used -= consumed;
            if (matches) { *result_out = result; *length_out = length; return 0; }
            continue; /* Notifications and responses to other IDs are not our reply. */
        }
        if (object_query_used == object_query_capacity) {
            if (object_query_capacity >= EXCLUDE_OBJECT_RESPONSE_MAX) goto failed;
            size_t next = object_query_capacity ? object_query_capacity * 2 : 16384;
            if (next > EXCLUDE_OBJECT_RESPONSE_MAX) next = EXCLUDE_OBJECT_RESPONSE_MAX;
            char *result = object_query_buffer;
            char *grown = realloc(result, next + 1);
            if (!grown) goto failed;
            object_query_buffer = grown; object_query_capacity = next;
        }
        if (object_query_wait(POLLIN, deadline)) goto failed;
        ssize_t n = recv(object_query_fd, object_query_buffer + object_query_used,
            object_query_capacity - object_query_used, 0);
        if (n < 0 && (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)) continue;
        if (n <= 0) goto failed;
        object_query_used += (size_t)n;
        object_query_buffer[object_query_used] = 0;
    }
failed:
    object_query_close();
    object_query_retry_ms = monotonic_ms() + 5000;
    return -1;
}

/* An empty slot map selects the external feed, but the printer keeps the colour
 * table of the last Canvas print, even across reboots, and method 1020 leaves it
 * unchanged. M6211 would then switch Canvas to that print's channel. Clear the
 * table the way the touchscreen does, and start only after the printer has run
 * the command: one request per print start, never a poll (docs/UDS_TELEMETRY.md). */
static const char canvas_color_table_clear_request[] =
    "{\"id\":205,\"method\":\"gcode/script\",\"params\":{\"script\":\"CANVAS_SET_COLOR_TABLE T= CHANNEL=\"}}\003";
/* Tests replace the printer round trip. */
static int (*canvas_color_table_uds)(const char *query, char **reply, size_t *length) = uds_query_json;

static int canvas_color_table_clear(void) {
    char *reply = NULL; size_t length = 0;
    if (canvas_color_table_uds(canvas_color_table_clear_request, &reply, &length) != 0 || !reply) {
        free(reply);
        return -1;
    }
    const char *end = reply + length, *root = json_skip_space(reply, end);
    const char *root_end = root < end && *root == '{' ? json_container_end(root, end) : NULL;
    int acknowledged = root_end && json_member(root, root_end, "result") &&
                       !json_member(root, root_end, "error");
    free(reply);
    return acknowledged ? 0 : -1;
}

static const char *exclude_object_payload(char *json, size_t length) {
    const char marker[] = "\"exclude_object\"";
    char *cursor = strstr(json, marker);
    if (!cursor || (size_t)(cursor - json) >= length) return NULL;
    cursor += sizeof(marker) - 1;
    while ((size_t)(cursor - json) < length && isspace((unsigned char)*cursor)) cursor++;
    if ((size_t)(cursor - json) >= length || *cursor++ != ':') return NULL;
    while ((size_t)(cursor - json) < length && isspace((unsigned char)*cursor)) cursor++;
    return (size_t)(cursor - json) < length && *cursor == '{' ? cursor : NULL;
}

static int cache_exclude_objects(const char *job) {
    static const char query[] =
        "{\"id\":202,\"method\":\"objects/query\",\"params\":{\"objects\":{\"exclude_object\":[\"objects\"]}}}\003";
    char *response = NULL; size_t response_len = 0;
    if (uds_query_json(query, &response, &response_len) != 0) return -1;
    const char *payload = exclude_object_payload(response, response_len);
    if (!payload) { free(response); return -1; }
    const char *payload_end = json_container_end(payload, response + response_len);
    const char *objects = json_member(payload, payload_end, "objects"), *objects_end = NULL;
    /* The printer reports null until a job defines its objects. */
    if (objects && payload_end - objects >= 4 && memcmp(objects, "null", 4) == 0) {
        objects = "[]"; objects_end = objects + 2;
    } else if (objects && *objects == '[') {
        objects_end = json_container_end(objects, payload_end);
    }
    if (!objects_end) { free(response); return -1; }
    size_t objects_len = (size_t)(objects_end - objects);
    char *copy = malloc(objects_len + 1);
    if (!copy) { free(response); return -1; }
    memcpy(copy, objects, objects_len); copy[objects_len] = '\0';
    free(response);
    free(exclude_objects_cache);
    exclude_objects_cache = copy;
    exclude_objects_cache_len = objects_len;
    snprintf(exclude_objects_cache_job, sizeof(exclude_objects_cache_job), "%s", job ? job : "");
    return 0;
}

static void exclude_objects_response(int fd, const mqtt_client *mqtt) {
    const char *job = mqtt ? mqtt->filename : "";
    long long now_ms = monotonic_ms();
    /* The printer keeps every UDS request in memory, so the list is asked once
     * per job and at most every five seconds. An empty list may predate the job's
     * EXCLUDE_OBJECT_DEFINE: it is asked again after 5 s, doubling to 5 min, or
     * after 5 s once the stream reports a current object. */
    int new_job = !exclude_objects_cache || strcmp(exclude_objects_cache_job, job) != 0;
    int empty = !new_job && strcmp(exclude_objects_cache, "[]") == 0;
    int in_object = telemetry.have_current_object && telemetry.current_object[0] == '"';
    long long since = now_ms - exclude_objects_asked_ms;
    if (since >= 5000 && (new_job || (empty && (in_object || since >= exclude_objects_wait_ms)))) {
        exclude_objects_asked_ms = now_ms;
        exclude_objects_wait_ms = new_job || exclude_objects_wait_ms < 5000 ? 5000 :
            exclude_objects_wait_ms >= 150000 ? 300000 : exclude_objects_wait_ms * 2;
        if (cache_exclude_objects(job) == 0) new_job = 0;
    }
    if (new_job) {
        const char *error = "{\"available\":false,\"error\":\"Object definitions unavailable\"}\n";
        respond(fd,503,"Service Unavailable","application/json; charset=utf-8",error,strlen(error));
        return;
    }

    static const char query[] =
        "{\"id\":203,\"method\":\"objects/query\",\"params\":{\"objects\":{\"exclude_object\":[\"excluded_objects\",\"current_object\"]}}}\003";
    char *dynamic = NULL; size_t dynamic_len = 0;
    int dynamic_owned = 0;
    /* The subscription carries the excluded and current objects; the query below
     * is only the fallback while that stream is unavailable. */
    char live[sizeof(telemetry.excluded_objects) + sizeof(telemetry.current_object) + 96];
    int live_len = uds_exclude_status(&telemetry, live, sizeof(live));
    int cache_fresh = exclude_dynamic_cache &&
        strcmp(exclude_dynamic_cache_job, job) == 0 &&
        now_ms > 0 && exclude_dynamic_cache_ms > 0 &&
        now_ms - exclude_dynamic_cache_ms < 1000;
    if (live_len > 0) {
        dynamic = live;
        dynamic_len = (size_t)live_len;
    } else if (cache_fresh) {
        dynamic = exclude_dynamic_cache;
        dynamic_len = exclude_dynamic_cache_len;
    } else {
        if (uds_query_json(query, &dynamic, &dynamic_len) != 0) {
            const char *error = "{\"available\":false,\"error\":\"Object status unavailable\"}\n";
            respond(fd,503,"Service Unavailable","application/json; charset=utf-8",error,strlen(error));
            return;
        }
        dynamic_owned = 1;
        free(exclude_dynamic_cache);
        exclude_dynamic_cache = dynamic;
        exclude_dynamic_cache_len = dynamic_len;
        snprintf(exclude_dynamic_cache_job, sizeof(exclude_dynamic_cache_job), "%s", job ? job : "");
        exclude_dynamic_cache_ms = now_ms;
        dynamic_owned = 0; /* cache owns this allocation */
    }
    const char *payload = exclude_object_payload(dynamic, dynamic_len);
    if (!payload) {
        if (dynamic_owned) free(dynamic);
        const char *error = "{\"available\":false,\"error\":\"Invalid object status response\"}\n";
        respond(fd,503,"Service Unavailable","application/json; charset=utf-8",error,strlen(error));
        return;
    }

    size_t prefix_len = (size_t)(payload + 1 - dynamic);
    size_t capacity = dynamic_len + exclude_objects_cache_len + 32;
    char *body = malloc(capacity);
    if (!body) { if (dynamic_owned) free(dynamic); return; }
    memcpy(body, dynamic, prefix_len);
    int inserted = snprintf(body + prefix_len, capacity - prefix_len,
                            "\"objects\":%s,", exclude_objects_cache);
    if (inserted < 0 || (size_t)inserted >= capacity - prefix_len) {
        free(body); if (dynamic_owned) free(dynamic); return;
    }
    size_t body_len = prefix_len + (size_t)inserted;
    memcpy(body + body_len, dynamic + prefix_len, dynamic_len - prefix_len);
    body_len += dynamic_len - prefix_len;
    respond(fd,200,"OK","application/json; charset=utf-8",body,body_len);
    free(body);
    if (dynamic_owned) free(dynamic);
}

#include "external_filament.h"
static const char external_query[]="{\"id\":206,\"method\":\"objects/query\",\"params\":{\"objects\":{\"canvas_dev\":null,\"print_stats\":[\"state\"],\"filament_switch_sensor filament_sensor\":[\"filament_detected\"]}}}\003";
static int (*external_uds)(const char *,char **,size_t *)=uds_query_json;
static int external_read(char **reply,size_t *length,external_readback *state){
    return external_uds(external_query,reply,length)==0&&*reply&&external_parse(*reply,*length,state);
}
/* Selection is a UI/session preference. Native print completion may restore
 * Canvas; each connected external motor operation reasserts its own source.
 * Never infer external mode from connected=1/0 or active_cid=-1 alone. */
static int external_fresh_idle(const mqtt_client *mqtt,const external_readback *state){
    return gcode_idle_for_mutation(mqtt)&&time(NULL)>=mqtt->last_message&&state->native_idle;
}
static void external_filament_response(int fd,const mqtt_client *mqtt){
    char *reply=NULL;size_t length=0;external_readback state={0};
    int known=external_read(&reply,&length,&state);
    int fresh=mqtt->connected&&mqtt->registered&&mqtt->last_message>0&&time(NULL)>=mqtt->last_message&&time(NULL)-mqtt->last_message<=15;
    int opted=external_feed_enabled&&!state.disconnected;
    int selected=!opted||external_source_selected;
    int idle=known&&fresh&&external_fresh_idle(mqtt,&state)&&state.active_channel==-1&&selected;
    if(opted)idle=idle&&state.have_sensor;
    const char *filament=known&&state.filament?state.filament:"null";
    size_t flen=known&&state.filament?(size_t)(state.filament_end-state.filament):4;
    size_t cap=flen+512;char *body=malloc(cap);
    if(body){int n=snprintf(body,cap,
        "{\"available\":%s,\"idle\":%s,\"experiment\":%s,\"source\":\"%s\",\"can_select\":%s,\"can_unload\":%s,\"temperature\":%.1f,\"filament\":%.*s}\n",
        known&&fresh&&(state.disconnected||external_feed_enabled)?"true":"false",idle?"true":"false",
        external_feed_enabled?"true":"false",state.disconnected||external_source_selected?"external":"canvas",
        known&&fresh&&external_feed_enabled&&!state.disconnected&&external_fresh_idle(mqtt,&state)&&state.active_channel==-1&&state.have_sensor&&!state.filament_detected?"true":"false",
        idle&&(!opted||state.filament_detected)?"true":"false",known?state.temperature:0,(int)flen,filament);
        respond(fd,200,"OK","application/json; charset=utf-8",body,(size_t)n);free(body);}
    free(reply);
}
static void filament_source_response(int fd,console_state *console,mqtt_client *mqtt,const char *body,size_t length){
    int wanted=length==8&&!memcmp(body,"external",8);
    if(!wanted&&(length!=6||memcmp(body,"canvas",6))){const char *error="{\"error\":\"Invalid filament source\"}";respond(fd,400,"Bad Request","application/json",error,strlen(error));return;}
    char *reply=NULL;size_t size=0;external_readback state={0};
    pthread_mutex_lock(&console->lock);int busy=console->busy;pthread_mutex_unlock(&console->lock);
    int valid=external_feed_enabled&&!busy&&!app_update_active()&&!plates_background_active()&&external_read(&reply,&size,&state)&&
        external_fresh_idle(mqtt,&state)&&!state.disconnected&&state.active_channel==-1&&state.have_sensor&&!state.filament_detected;
    free(reply);
    if(!valid){const char *error="{\"error\":\"Source change requires the enabled experiment, fresh Idle state, connected Canvas and an empty printhead\"}";
        respond(fd,409,"Conflict","application/json",error,strlen(error));return;}
    const char *query=wanted?
        "{\"id\":207,\"method\":\"gcode/script\",\"params\":{\"script\":\"USED_CANVAS_DEV USED_CANVAS=0\"}}\003":
        "{\"id\":207,\"method\":\"gcode/script\",\"params\":{\"script\":\"USED_CANVAS_DEV USED_CANVAS=1\"}}\003";
    reply=NULL;size=0;
    int sent=external_uds(query,&reply,&size)==0&&reply;
    const char *end=sent?reply+size:NULL,*root=sent?ccv_json_skip_space(reply,end):NULL;
    const char *re=root&&root<end&&*root=='{'?ccv_json_container_end(root,end):NULL;
    int acknowledged=re&&ccv_json_skip_space(re,end)==end&&ccv_json_member(root,re,"result")&&!ccv_json_member(root,re,"error");
    free(reply);
    if(!acknowledged){const char *error="{\"error\":\"Native source command was not acknowledged; selection was not updated\"}";
        respond(fd,503,"Service Unavailable","application/json",error,strlen(error));return;}
    if(!external_feed_store(1,wanted)){
        const char *error="{\"error\":\"Source command acknowledged but preference could not be saved; select the source again\"}";
        respond(fd,503,"Service Unavailable","application/json",error,strlen(error));return;
    }
    external_filament_response(fd,mqtt);
}

/* GET /api/mesh: the printer's active mesh plus the side and adaptive profiles; see
 * mesh_response_body after the plate library, whose autosave.cfg reader it uses. */
static void mesh_response(int fd);

/* Cross-feature SAVE_CONFIG guards are implemented after both file editors. */
static int canvas_unload_pending(void);
static int canvas_unload_pending_intact(void);
static int nx_pending(void);
static int rotation_pending(void);
static int rotation_pending_intact(void);
static int cell_active(void);
static const char *pending_autosave_guard(void);
/* A hold time before a screw measurement is running (screws:soak, see screws_soak below). */
static int screws_soak_active(void);

#include "plates.h"
#include "screw_history.h"
/* Next to the UI preferences unless --screws-history names a file. */
static const char *screws_history_path = NULL;
static char screws_history_default_path[600];
static screw_history_store screws_history;

static void screws_history_init(void) {
    if (!screws_history_path) {
        const char *slash = strrchr(ui_preferences_path, '/');
        int n = slash ? snprintf(screws_history_default_path, sizeof(screws_history_default_path), "%.*s/screw-history.txt",
                                 (int)(slash - ui_preferences_path), ui_preferences_path)
                      : snprintf(screws_history_default_path, sizeof(screws_history_default_path), "screw-history.txt");
        screws_history_path = n > 0 && (size_t)n < sizeof(screws_history_default_path) ? screws_history_default_path
                                                                                       : "./screw-history.txt";
    }
    if (!screw_history_load(&screws_history, screws_history_path))
        fprintf(stderr, "Screw history unreadable, starting empty: %s\n", screws_history_path);
}

static int screws_history_store(void) {
    if (screw_history_save(&screws_history, screws_history_path)) return 1;
    fprintf(stderr, "Screw history could not be saved: %s\n", screws_history_path);
    return 0;
}

/* The actual temperatures of the measurement that runs: the main loop reads them whenever the console output
 * shows a new "Result is z=", so the last stand is the one at the last probe (within one loop cycle, about 1 s).
 * A sensor without a current value is left out; nothing is invented. gen ties the sample to one console job. */
static struct { unsigned long gen; int results; screw_ist ist; } screws_sample;
static void screws_read_ist(const mqtt_client *m, screw_ist *out) {
    double live;
    memset(out, 0, sizeof(*out));
    if (uds_value(&telemetry, U_BT, &live)) { out->v[0] = live; out->have |= 1u; }
    else if (m->have_bed_temp) { out->v[0] = m->bed_temp; out->have |= 1u; }
    if (uds_value(&telemetry, U_ET, &live)) { out->v[1] = live; out->have |= 2u; }
    else if (m->have_extruder_temp) { out->v[1] = m->extruder_temp; out->have |= 2u; }
    if (m->have_chamber_temp) { out->v[2] = m->chamber_temp; out->have |= 4u; }
}
static void screws_sample_tick(const mqtt_client *m, unsigned long generation, const char *output, size_t length) {
    if (!control_screws_measuring()) return;
    if (screws_sample.gen != generation) {
        memset(&screws_sample, 0, sizeof(screws_sample));
        screws_sample.gen = generation;
    }
    int results = screw_history_count_results(output, length);
    if (results > screws_sample.results) {
        screws_sample.results = results;
        screws_read_ist(m, &screws_sample.ist);
    }
}

static void screws_history_get_response(int fd) {
    size_t length = 0;
    char *body = screw_history_json(&screws_history, &length);
    if (!body) {
        const char *error = "{\"error\":\"Screw history is unavailable\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    respond(fd, 200, "OK", "application/json; charset=utf-8", body, length);
    free(body);
}

static void screws_history_clear_response(int fd) {
    memset(&screws_history, 0, sizeof(screws_history));
    if (!screws_history_store()) {
        const char *error = "{\"ok\":false,\"error\":\"Screw history could not be saved\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    const char *ok = "{\"ok\":true}\n";
    respond(fd, 200, "OK", "application/json; charset=utf-8", ok, strlen(ok));
}
#include "spools.h"
/* The exclusive sessions during which the request dispatcher refuses every printer change; the print
 * queue asks before an automatic start. Defined once the sessions themselves are. */
static const char *printer_change_blocked(void);
/* The same refusals for one request, as the dispatcher answers them (handle_client). */
static const char *printer_change_refusal(const char *method, const char *path, const char *body, size_t body_len, int *plates_form);
#include "queue.h"
#include "spoolman.h"
#include "sha256.h"
#include "crc32.h"
#include "canvas_unload.h"
#include "runout.h"
#include "calibration_tools.h"
#include "cavity_floor_http.h"

/* GET /api/mesh. The firmware builds `{"bed_mesh":null}` with every stored profile and all its points
 * on the thread that schedules the motors: with many profiles (29-39 KB) that took 615 ms on a CC2
 * and, during a first layer, ended in "MCU 'mcu' shutdown: Timer too close". So the printer is only
 * asked for the active mesh's measured points (not mesh_matrix, the interpolated grid: 17 KB of the
 * 18 KB answer, and the pages draw probed_matrix), and the three profiles the pages show (the two side slots and the
 * adaptive mesh) are read from autosave.cfg, where the firmware keeps them, in the same shape. */
#define MESH_REPLY_MAX (64 * 1024)
static const char mesh_query[] =
    "{\"id\":201,\"method\":\"objects/query\",\"params\":{\"objects\":{\"bed_mesh\":[\"profile_name\",\"mesh_min\",\"mesh_max\",\"probed_matrix\"]}}}\003";
static const char *const mesh_shown_profiles[] = {"default", "default1", "ADAPTIVE"};
static void mesh_profiles_json(json_builder *b) {
    size_t length = 0;
    char *text = plates_read_file(printer_autosave_path, AUTOSAVE_FILE_MAX, &length);
    json_builder_printf(b, "\"profiles\":{");
    for (size_t i = 0, first = 1; text && i < sizeof(mesh_shown_profiles) / sizeof(mesh_shown_profiles[0]); ++i) {
        plate_mesh m;
        if (autosave_find(text, length, mesh_shown_profiles[i], &m) != 1) continue;
        json_builder_printf(b, "%s\"%s\":{\"mesh_params\":{\"min_x\":%.6f,\"max_x\":%.6f,\"min_y\":%.6f,\"max_y\":%.6f,"
            "\"x_count\":%d,\"y_count\":%d,\"mesh_x_pps\":%d,\"mesh_y_pps\":%d,\"algo\":\"%s\",\"tension\":%.6f},\"points\":[",
            first ? "" : ",", mesh_shown_profiles[i], m.min_x, m.max_x, m.min_y, m.max_y, m.x_count, m.y_count,
            m.x_pps, m.y_pps, m.algo, m.tension);
        for (int r = 0; r < m.y_count; ++r) {
            json_builder_printf(b, "%s[", r ? "," : "");
            for (int c = 0; c < m.x_count; ++c) json_builder_printf(b, "%s%.6f", c ? "," : "", m.points[r * m.x_count + c]);
            json_builder_printf(b, "]");
        }
        json_builder_printf(b, "]}");
        first = 0;
    }
    json_builder_printf(b, "}");
    free(text);
}
static void mesh_fail(int fd, const char *error) {
    char body[128]; int n = snprintf(body, sizeof(body), "{\"available\":false,\"error\":\"%s\"}\n", error);
    respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", body, (size_t)n);
}
static void mesh_response(int fd) {
    int uds = socket(AF_UNIX, SOCK_STREAM, 0);
    if (uds < 0) { mesh_fail(fd, "Cannot create UDS socket"); return; }
    struct timeval timeout = {2, 0};
    setsockopt(uds, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(uds, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    struct sockaddr_un address; memset(&address, 0, sizeof(address));
    address.sun_family = AF_UNIX;
    snprintf(address.sun_path, sizeof(address.sun_path), "%s", object_query_path);
    if (connect(uds, (struct sockaddr *)&address, sizeof(address)) < 0) { close(uds); mesh_fail(fd, "Printer UDS unavailable"); return; }
    if (send_all(uds, mesh_query, sizeof(mesh_query) - 1) != 0) { close(uds); mesh_fail(fd, "Mesh query failed"); return; }
    char *reply = malloc(MESH_REPLY_MAX + 1); size_t used = 0;
    if (!reply) { close(uds); mesh_fail(fd, "Out of memory"); return; }
    while (used < MESH_REPLY_MAX) {
        ssize_t n = recv(uds, reply + used, MESH_REPLY_MAX - used, 0);
        if (n <= 0) break;
        used += (size_t)n;
        char *stop = memchr(reply, 3, used);
        if (stop) { used = (size_t)(stop - reply); break; }
    }
    close(uds); reply[used] = 0;
    /* The reply's bed_mesh object gets the profiles as its last member. */
    const char *end = reply + used, *root = json_skip_space(reply, end), *e0, *e1, *e2, *e3;
    const char *result = root < end && *root == '{' && (e0 = json_container_end(root, end)) ? json_member_object(root, e0, "result", '{', &e1) : NULL;
    const char *status = result ? json_member_object(result, e1, "status", '{', &e2) : NULL;
    const char *bed = status ? json_member_object(status, e2, "bed_mesh", '{', &e3) : NULL;
    if (!bed) { free(reply); mesh_fail(fd, used ? "Unexpected mesh response" : "No mesh response"); return; }
    json_builder b = {malloc(MESH_REPLY_MAX + 32768), 0, MESH_REPLY_MAX + 32768, 0};
    if (!b.data) { free(reply); mesh_fail(fd, "Out of memory"); return; }
    size_t head = (size_t)(e3 - 1 - reply); /* up to the bed_mesh object's closing brace */
    json_builder_printf(&b, "%.*s", (int)head, reply);
    const char *inside = json_skip_space(bed + 1, e3 - 1);
    json_builder_printf(&b, "%s", inside < e3 - 1 ? "," : "");
    mesh_profiles_json(&b);
    json_builder_printf(&b, "%.*s", (int)(used - head), reply + head);
    free(reply);
    if (b.failed) { free(b.data); mesh_fail(fd, "Mesh response too large"); return; }
    respond(fd, 200, "OK", "application/json; charset=utf-8", b.data, b.length);
    free(b.data);
}

static const char *pending_autosave_guard(void) {
    if (cell_active()) return "Finish the load-cell calibration session before changing or saving printer settings";
    if (rotation_pending())
        return "A rotation distance change needs a restart; resolve it before calibrating or saving printer settings";
    if (canvas_unload_pending())
        return "A Canvas pull-back change needs a restart; resolve it before calibrating or saving printer settings";
    if (plates.pending[0])
        return "A plate mesh change needs a restart; resolve it before calibrating or saving printer settings";
    if (nx_pending())
        return "A nozzle expansion change needs a restart; resolve it before calibrating or saving printer settings";
    return NULL;
}

/* The start page revalidates instead of using no-store: the browser asks on
   every visit, the ETag (SHA-256 of the page) tells it whether its copy is still
   the installed one, and a match is answered with a bodyless 304. Only "/" and
   "/index.html" use this; every other answer keeps the no-store header in respond().
   `encoding` is "gzip" when the body is the gzip copy (its ETag is the SHA-256 of
   those bytes, so it never equals the tag of the plain page), NULL otherwise; every
   answer names Accept-Encoding in Vary because either form can be sent. */
static void respond_revalidate(int fd, int status, const char *status_text,
                               const char *body, size_t body_len, const char *etag, const char *encoding) {
    char header[512];
    int header_len;
    if (status == 304)
        header_len = snprintf(header, sizeof(header),
            "HTTP/1.1 %d %s\r\n"
            "ETag: %s\r\n"
            "Cache-Control: no-cache\r\n"
            "Vary: Accept-Encoding\r\n"
            "X-Content-Type-Options: nosniff\r\n"
            "X-Frame-Options: DENY\r\n"
            "Connection: close\r\n\r\n",
            status, status_text, etag);
    else
        header_len = snprintf(header, sizeof(header),
            "HTTP/1.1 %d %s\r\n"
            "Content-Type: text/html; charset=utf-8\r\n"
            "%s%s%s"
            "Content-Length: %lu\r\n"
            "ETag: %s\r\n"
            "Cache-Control: no-cache\r\n"
            "Vary: Accept-Encoding\r\n"
            "X-Content-Type-Options: nosniff\r\n"
            "X-Frame-Options: DENY\r\n"
            "Connection: close\r\n\r\n",
            status, status_text, encoding ? "Content-Encoding: " : "", encoding ? encoding : "", encoding ? "\r\n" : "",
            (unsigned long)body_len, etag);
    if (header_len <= 0 || (size_t)header_len >= sizeof(header)) return;
    if (send_all(fd, header, (size_t)header_len) == 0 && status != 304)
        (void)send_all(fd, body, body_len);
}

/* Strong validator from the content: the SHA-256 of the page, in quotes. It is made from the very bytes that are
   sent, so it cannot describe another page than the body, and two different pages never share it, whatever their
   size, modification time, change time, inode or device are (a switch between installed releases or firmware
   images can give different pages the same file metadata). */
static int index_etag(const unsigned char *page, size_t length, char *out, size_t cap) {
    char digest[65];
    sha256_state state;
    sha256_init(&state);
    sha256_update(&state, page, length);
    sha256_hex(&state, digest);
    int written = snprintf(out, cap, "\"%s\"", digest);
    return written > 0 && (size_t)written < cap;
}

/* Does the If-None-Match value (comma-separated entity tags, "*", weak "W/"
   prefix compared weakly) match this ETag? */
static int if_none_match_matches(const char *value, const char *etag) {
    size_t etag_len = strlen(etag);
    const char *p = value;
    while (*p) {
        while (*p == ' ' || *p == '\t' || *p == ',') p++;
        const char *start = p;
        while (*p && *p != ',') p++;
        const char *end = p;
        while (end > start && (end[-1] == ' ' || end[-1] == '\t')) end--;
        if (end - start == 1 && *start == '*') return 1;
        if (end - start > 2 && start[0] == 'W' && start[1] == '/') start += 2;
        if ((size_t)(end - start) == etag_len && memcmp(start, etag, etag_len) == 0) return 1;
    }
    return 0;
}

/* Largest start page and locale file that are read into memory and sent (the page's boundedJson in i18n.ts refuses
   a locale above 262144 characters too). A larger file gets an HTTP 500 with a plain-text reason and one log line
   per kind of file; tests/test_web_size_limits_static.py fails while the shipped files are still below these sizes. */
#define WEB_INDEX_MAX_BYTES (1024 * 1024)
#define WEB_LOCALE_MAX_BYTES 262144

/* Answers a web file above its size limit with a reason and logs it once per process and kind of file, so a
   browser that keeps retrying cannot fill the log. The HTTP threads run in parallel, hence the atomic flag. */
static void respond_web_file_too_large(int fd, atomic_int *logged, const char *what, const char *limit_text) {
    char body[160];
    int length = snprintf(body, sizeof(body), "%s is larger than the %s limit\n", what, limit_text);
    if (!atomic_exchange(logged, 1)) {
        fprintf(stderr, "Web UI: %s is larger than the %s limit; answering with HTTP 500\n", what, limit_text);
    }
    if (length > 0 && (size_t)length < sizeof(body))
        respond(fd, 500, "Internal Server Error", "text/plain; charset=utf-8", body, (size_t)length);
}
static atomic_int index_too_large_logged, locale_too_large_logged;

/* respond() for a locale file: the same headers (no-store included) plus Vary: Accept-Encoding, and
   Content-Encoding when `encoding` is set (the body is then the gzip copy). */
static void respond_negotiated(int fd, int status, const char *status_text, const char *content_type,
                               const char *body, size_t body_len, const char *encoding) {
    char header[512];
    int header_len = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "%s%s%s"
        "Content-Length: %lu\r\n"
        "Cache-Control: no-store\r\n"
        "Vary: Accept-Encoding\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "X-Frame-Options: DENY\r\n"
        "Connection: close\r\n\r\n",
        status, status_text, content_type, encoding ? "Content-Encoding: " : "", encoding ? encoding : "",
        encoding ? "\r\n" : "", (unsigned long)body_len);
    if (header_len <= 0 || (size_t)header_len >= sizeof(header)) return;
    if (send_all(fd, header, (size_t)header_len) == 0)
        (void)send_all(fd, body, body_len);
}

/* Is a weight of zero among the parameters of one Accept-Encoding entry (";q=0", ";q=0.000")? */
static int encoding_refused(const char *p, const char *end) {
    while (p < end) {
        if (*p++ != ';') continue;
        while (p < end && (*p == ' ' || *p == '\t')) p++;
        if (end - p >= 2 && (*p == 'q' || *p == 'Q') && p[1] == '=') {
            p += 2;
            if (p >= end || *p != '0') return 0;
            for (p++; p < end && *p != ';' && *p != ' ' && *p != '\t'; p++)
                if (*p != '.' && *p != '0') return 0;
            return 1;
        }
    }
    return 0;
}

/* Does the request take a gzip body? Accept-Encoding is read like every header here (http_header: a single copy,
   value below 512 bytes). An entry "gzip" or "x-gzip" decides, otherwise "*"; weight 0 refuses. A missing, repeated
   or oversized header means no: the plain file is a valid answer to every request. */
static int accepts_gzip(const char *request) {
    char value[512];
    if (http_header(request, "Accept-Encoding", value, sizeof(value)) != 1) return 0;
    int gzip = -1, any = -1;
    for (const char *item = value; *item;) {
        const char *end = strchr(item, ',');
        if (!end) end = item + strlen(item);
        const char *name = item;
        while (name < end && (*name == ' ' || *name == '\t')) name++;
        const char *name_end = name;
        while (name_end < end && *name_end != ';' && *name_end != ' ' && *name_end != '\t') name_end++;
        size_t length = (size_t)(name_end - name);
        int taken = !encoding_refused(name_end, end);
        if ((length == 4 && !strncasecmp(name, "gzip", 4)) || (length == 6 && !strncasecmp(name, "x-gzip", 6))) gzip = taken;
        else if (length == 1 && *name == '*') any = taken;
        item = *end ? end + 1 : end;
    }
    return gzip >= 0 ? gzip : any == 1;
}

static int same_file_state(const struct stat *before, const struct stat *after) {
    return after->st_size == before->st_size &&
           after->st_mtim.tv_sec == before->st_mtim.tv_sec && after->st_mtim.tv_nsec == before->st_mtim.tv_nsec &&
           after->st_ctim.tv_sec == before->st_ctim.tv_sec && after->st_ctim.tv_nsec == before->st_ctim.tv_nsec;
}

/* CRC-32 of the next `size` bytes of `file`, read in small pieces: the plain file is never held whole for this. */
static int web_file_crc32(FILE *file, size_t size, uint32_t *crc) {
    unsigned char piece[4096];
    uint32_t value = 0;
    while (size > 0) {
        size_t want = size < sizeof(piece) ? size : sizeof(piece);
        if (fread(piece, 1, want, file) != want) return 0;
        value = cc2_crc32_update(value, piece, want);
        size -= want;
    }
    *crc = value;
    return 1;
}

static uint32_t little_endian32(const unsigned char *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

/* The gzip copy that the installer writes next to a file (<path>.gz, installer/install-on-printer.sh), read whole when it
   can stand in for the plain file: a regular file smaller than the plain one, a gzip member (1f 8b 08) whose trailer
   (its last 8 bytes) names exactly the CRC-32 and the length of the plain bytes, unchanged while it was read. A missing
   copy (an installation from before the copies), a stale one (left from another release), a cut-off one or one being
   written gives NULL, and the caller sends the plain file. The service itself compresses nothing. */
static unsigned char *web_gzip_twin(const char *path, uint32_t crc, size_t plain_size, size_t *length) {
    char twin[PATH_MAX_LOCAL];
    if (snprintf(twin, sizeof(twin), "%s.gz", path) >= (int)sizeof(twin)) return NULL;
    FILE *file = fopen(twin, "rb");
    if (!file) return NULL;
    struct stat info, after;
    unsigned char *data = NULL;
    if (fstat(fileno(file), &info) == 0 && S_ISREG(info.st_mode) && info.st_size >= 18 &&
        (unsigned long long)info.st_size < (unsigned long long)plain_size) {
        size_t size = (size_t)info.st_size;
        data = malloc(size);
        if (data && (fread(data, 1, size, file) != size || fstat(fileno(file), &after) != 0 ||
                     !same_file_state(&info, &after) || data[0] != 0x1f || data[1] != 0x8b || data[2] != 8 ||
                     little_endian32(data + size - 8) != crc || little_endian32(data + size - 4) != (uint32_t)plain_size)) {
            free(data);
            data = NULL;
        }
        if (data) *length = size;
    }
    fclose(file);
    return data;
}

/* Sends the gzip copy of the web file open in `file` (`size` bytes from its start; `measured`, when given, is its
   state before reading) and returns 1. Returns 0 with `file` back at its start when the copy cannot stand in for it,
   and the caller sends the plain file as before. The start page (index = 1) keeps its ETag and 304 answer. */
static int serve_gzip_twin(int fd, FILE *file, const char *path, size_t size, const struct stat *measured,
                           const char *request, int index) {
    uint32_t crc;
    struct stat after;
    size_t length = 0;
    unsigned char *packed = NULL;
    if (web_file_crc32(file, size, &crc) &&
        (!measured || (fstat(fileno(file), &after) == 0 && same_file_state(measured, &after))))
        packed = web_gzip_twin(path, crc, size, &length);
    char etag[80];
    if (!packed || (index && !index_etag(packed, length, etag, sizeof(etag)))) {
        free(packed);
        rewind(file);
        return 0;
    }
    if (index) {
        char sent[512]; /* A longer value is not ours; it is ignored and the page is sent. */
        if (http_header(request, "If-None-Match", sent, sizeof(sent)) == 1 && if_none_match_matches(sent, etag))
            respond_revalidate(fd, 304, "Not Modified", NULL, 0, etag, "gzip");
        else
            respond_revalidate(fd, 200, "OK", (const char *)packed, length, etag, "gzip");
    } else
        respond_negotiated(fd, 200, "OK", "application/json; charset=utf-8", (const char *)packed, length, "gzip");
    free(packed);
    return 1;
}

static void serve_index(int fd, const char *web_root, const char *request) {
    char path[PATH_MAX_LOCAL];
    if (snprintf(path, sizeof(path), "%s/index.html", web_root) >= (int)sizeof(path)) {
        const char *body = "Web root path is too long\n";
        respond(fd, 500, "Internal Server Error", "text/plain; charset=utf-8", body, strlen(body));
        return;
    }
    FILE *file = fopen(path, "rb");
    if (!file) {
        const char *body = "Dashboard file not found\n";
        respond(fd, 500, "Internal Server Error", "text/plain; charset=utf-8", body, strlen(body));
        return;
    }
    /* The length comes from one fstat of the opened file and exactly that many bytes are read. The file is measured
       again after reading: if it changed meanwhile (an update writes it in place) or was shorter than measured, the
       answer is a 503 and the next request gets the finished page. Best effort: file times move in clock ticks of a
       few milliseconds, so a same-size write inside one tick is not seen by this check (the tag below still
       describes the bytes that are sent). Without stat data the length comes from the end of the file.
       A page of length 0 is a page that is being replaced too (a copy truncates it before it writes the new content,
       measured on the printer: 59 of 93 answers had an empty body), so it gets the same 503; an empty start page is
       never a finished page and a browser would keep the white page until the next visit. A copy that is cut off
       somewhere in the middle cannot be told from a short page by its size and times when no write happens between the
       two measurements (3 of 93 in the same run); that case stays best effort. */
    struct stat info, after;
    int measured = fstat(fileno(file), &info) == 0 && S_ISREG(info.st_mode);
    long size;
    if (measured) {
        if (info.st_size < 0) { fclose(file); return; }
        if (info.st_size > WEB_INDEX_MAX_BYTES) {
            fclose(file);
            respond_web_file_too_large(fd, &index_too_large_logged, "web/index.html", "1 MiB");
            return;
        }
        size = (long)info.st_size;
    } else {
        if (fseek(file, 0, SEEK_END) != 0) { fclose(file); return; }
        size = ftell(file);
        if (size < 0) { fclose(file); return; }
        if (size > WEB_INDEX_MAX_BYTES) {
            fclose(file);
            respond_web_file_too_large(fd, &index_too_large_logged, "web/index.html", "1 MiB");
            return;
        }
        rewind(file);
    }
    if (size == 0) {
        fclose(file);
        const char *error = "{\"error\":\"Start page is being replaced\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    /* A browser that takes gzip gets the installed gzip copy while it is the gzip form of exactly this page; the page is
       then only read through CRC-32, never held whole. Otherwise, and when the copy does not fit, the page below. */
    if (accepts_gzip(request) && serve_gzip_twin(fd, file, path, (size_t)size, measured ? &info : NULL, request, 1)) {
        fclose(file);
        return;
    }
    char *body = malloc((size_t)size);
    if (!body) { fclose(file); return; }
    size_t read_len = fread(body, 1, (size_t)size, file);
    int unchanged = !measured || (fstat(fileno(file), &after) == 0 && after.st_size == info.st_size &&
                                  after.st_mtim.tv_sec == info.st_mtim.tv_sec && after.st_mtim.tv_nsec == info.st_mtim.tv_nsec &&
                                  after.st_ctim.tv_sec == info.st_ctim.tv_sec && after.st_ctim.tv_nsec == info.st_ctim.tv_nsec);
    fclose(file);
    char etag[80];
    if (read_len != (size_t)size || !unchanged || !index_etag((const unsigned char *)body, read_len, etag, sizeof(etag))) {
        const char *error = "{\"error\":\"Start page is being replaced\"}\n";
        respond(fd, 503, "Service Unavailable", "application/json; charset=utf-8", error, strlen(error));
        free(body);
        return;
    }
    char sent[512]; /* A longer value is not ours; it is ignored and the page is sent. */
    if (http_header(request, "If-None-Match", sent, sizeof(sent)) == 1 && if_none_match_matches(sent, etag))
        respond_revalidate(fd, 304, "Not Modified", NULL, 0, etag, NULL);
    else
        respond_revalidate(fd, 200, "OK", body, read_len, etag, NULL);
    free(body);
}

/* Locale codes accepted in /i18n/<code>.json requests: 2-5 lowercase letters,
   optionally followed by '-' and 2 uppercase letters (e.g. "en", "pt-BR").
   Anchoring the charset this tightly also rules out any '..' or '/'. */
static int locale_code_valid(const char *code, size_t length) {
    if (length < 2 || length > 8) return 0;
    size_t letters = 0;
    while (letters < length && code[letters] >= 'a' && code[letters] <= 'z') letters++;
    if (letters < 2 || letters > 5) return 0;
    if (letters == length) return 1;
    if (length - letters != 3 || code[letters] != '-') return 0;
    return code[letters + 1] >= 'A' && code[letters + 1] <= 'Z' &&
           code[letters + 2] >= 'A' && code[letters + 2] <= 'Z';
}

/* Serves cc2-control/web/locales/<code>.json. The UI loads en.json as a
   fallback plus the requested locale, so a missing or partial file degrades
   to English strings instead of breaking the page. */
static void serve_locale(int fd, const char *web_root, const char *request_path, const char *request) {
    const char *name = request_path + strlen("/i18n/");
    size_t name_len = strlen(name);
    static const char suffix[] = ".json";
    if (name_len <= sizeof(suffix) - 1 ||
        strcmp(name + name_len - (sizeof(suffix) - 1), suffix) != 0 ||
        !locale_code_valid(name, name_len - (sizeof(suffix) - 1))) {
        const char *body = "Not found\n";
        respond(fd, 404, "Not Found", "text/plain; charset=utf-8", body, strlen(body));
        return;
    }
    char path[PATH_MAX_LOCAL];
    if (snprintf(path, sizeof(path), "%s/locales/%s", web_root, name) >= (int)sizeof(path)) {
        const char *body = "Locale path is too long\n";
        respond(fd, 500, "Internal Server Error", "text/plain; charset=utf-8", body, strlen(body));
        return;
    }
    FILE *file = fopen(path, "rb");
    if (!file) {
        const char *body = "{}\n";
        respond(fd, 404, "Not Found", "application/json; charset=utf-8", body, strlen(body));
        return;
    }
    if (fseek(file, 0, SEEK_END) != 0) { fclose(file); return; }
    long size = ftell(file);
    if (size < 0) { fclose(file); return; }
    if (size > WEB_LOCALE_MAX_BYTES) {
        fclose(file);
        char what[64];
        snprintf(what, sizeof(what), "web/locales/%s", name);
        respond_web_file_too_large(fd, &locale_too_large_logged, what, "256 KiB");
        return;
    }
    rewind(file);
    if (size > 0 && accepts_gzip(request) && serve_gzip_twin(fd, file, path, (size_t)size, NULL, request, 0)) {
        fclose(file);
        return;
    }
    char *body = malloc((size_t)size);
    if (!body) { fclose(file); return; }
    size_t read_len = fread(body, 1, (size_t)size, file);
    fclose(file);
    if (read_len == (size_t)size)
        respond_negotiated(fd, 200, "OK", "application/json; charset=utf-8", body, read_len, NULL);
    free(body);
}

static size_t content_length_from_headers(const char *request) {
    char value[32];int present=http_header(request,"Content-Length",value,sizeof(value));
    if(!present)return 0;
    if(present<0)return SIZE_MAX;
    size_t length=0;
    for(const char *p=value;*p;p++){
        if(!isdigit((unsigned char)*p)||length>(SIZE_MAX-(size_t)(*p-'0'))/10)return SIZE_MAX;
        length=length*10+(size_t)(*p-'0');
    }
    return length;
}

static void setup_status_response(int fd, const mqtt_client *mqtt) {
    if (mqtt->registered) setup_mode = 0;
    char body[256];
    int length = snprintf(body, sizeof(body),
        "{\"required\":%s,\"configured\":%s,\"mqtt_connected\":%s,"
        "\"mqtt_registered\":%s,\"snapshot_received\":%s}\n",
        setup_mode ? "true" : "false", mqtt->password[0] ? "true" : "false",
        mqtt->connected ? "true" : "false", mqtt->registered ? "true" : "false",
        mqtt->snapshot_len ? "true" : "false");
    if (length > 0 && (size_t)length < sizeof(body))
        respond(fd, 200, "OK", "application/json; charset=utf-8", body, (size_t)length);
}

static int access_code_valid(const char *code, size_t length) {
    if (!code || length < 1 || length > 128) return 0;
    for (size_t i = 0; i < length; ++i) {
        unsigned char ch = (unsigned char)code[i];
        if (!(isalnum(ch) || ch == '.' || ch == '_' || ch == '-')) return 0;
    }
    return 1;
}

static void setup_configure_response(int fd, mqtt_client *mqtt,
                                     const char *body, size_t body_len,
                                     int allow_revalidation) {
    if (mqtt->registered) setup_mode = 0;
    if (!setup_mode && !allow_revalidation) {
        const char *error = "{\"accepted\":false,\"error\":\"First-run setup is locked\"}\n";
        respond(fd, 403, "Forbidden", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    while (body_len && isspace((unsigned char)*body)) { body++; body_len--; }
    while (body_len && isspace((unsigned char)body[body_len - 1])) body_len--;
    if (!access_code_valid(body, body_len)) {
        const char *error = "{\"accepted\":false,\"error\":\"Invalid access code\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return;
    }

    char code[129], temporary[PATH_MAX_LOCAL];
    memcpy(code, body, body_len); code[body_len] = '\0';
    if (snprintf(temporary, sizeof(temporary), "%s.new", mqtt_config_path) >= (int)sizeof(temporary)) {
        const char *error = "{\"accepted\":false,\"error\":\"Configuration path is too long\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }

    FILE *file = fopen(temporary, "wb");
    int failed = !file;
    if (file) {
        if (fprintf(file, "mqtt_username=elegoo\nmqtt_password=%s\n"
                          "mqtt_topic=elegoo/+/api_status\nmqtt_serial=%s\n",
                    code, mqtt->serial) < 0 || fflush(file) != 0 || fsync(fileno(file)) != 0)
            failed = 1;
        if (fclose(file) != 0) failed = 1;
    }
    memset(code, 0, sizeof(code));
    if (!failed && chmod(temporary, S_IRUSR | S_IWUSR) != 0) failed = 1;
    if (!failed && rename(temporary, mqtt_config_path) != 0) failed = 1;
    if (!failed && chmod(mqtt_config_path, S_IRUSR | S_IWUSR) != 0) failed = 1;
    if (failed) {
        unlink(temporary);
        const char *error = "{\"accepted\":false,\"error\":\"Cannot save configuration\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }

    /* This process started without credentials.  Restarting only CC2 Control
       makes MQTT registration, the initial snapshot and Canvas discovery use
       the same clean ordering as every later boot.  procd performs the respawn;
       elegoo_printer, Klipper, the broker and an active print are untouched. */
    const char *ok = "{\"accepted\":true,\"restarting\":true,\"message\":\"Configuration saved; restarting CC2 Control\"}\n";
    respond(fd, 202, "Accepted", "application/json; charset=utf-8", ok, strlen(ok));
    first_run_restart_requested = 1;
}

static int preset_json_safe(const char *body,size_t len) {
    if(!body||len<2||len>8192)return 0;
    while(len&&isspace((unsigned char)*body)){body++;len--;}
    while(len&&isspace((unsigned char)body[len-1]))len--;
    if(len<2||body[0]!='['||body[len-1]!=']')return 0;
    if(!strstr(body,"\"name\"")||!strstr(body,"\"nozzle\"")||!strstr(body,"\"bed\""))return 0;
    for(size_t i=0;i<len;i++){
        unsigned char ch=(unsigned char)body[i];
        if(isalnum(ch)||isspace(ch)||strchr("[]{}\":,._+#-",ch))continue;
        return 0;
    }
    return 1;
}

static void presets_get_response(int fd) {
    FILE *f=fopen(material_presets_path,"rb");
    if(!f){respond(fd,200,"OK","application/json; charset=utf-8",default_material_presets,strlen(default_material_presets));return;}
    char body[8193];size_t n=fread(body,1,sizeof(body)-1,f);fclose(f);body[n]='\0';
    if(!preset_json_safe(body,n)){respond(fd,200,"OK","application/json; charset=utf-8",default_material_presets,strlen(default_material_presets));return;}
    respond(fd,200,"OK","application/json; charset=utf-8",body,n);
}

static void presets_put_response(int fd,const char *body,size_t body_len) {
    if(!preset_json_safe(body,body_len)){
        const char *error="{\"saved\":false,\"error\":\"Invalid preset data\"}\n";
        respond(fd,400,"Bad Request","application/json; charset=utf-8",error,strlen(error));return;
    }
    char temporary[512];snprintf(temporary,sizeof(temporary),"%s.new",material_presets_path);
    FILE *f=fopen(temporary,"wb");
    int failed=!f;
    if(f){if(fwrite(body,1,body_len,f)!=body_len||fflush(f)!=0||fclose(f)!=0)failed=1;f=NULL;}
    if(!failed&&rename(temporary,material_presets_path)!=0)failed=1;
    if(failed){unlink(temporary);const char *error="{\"saved\":false,\"error\":\"Cannot save presets\"}\n";respond(fd,500,"Internal Server Error","application/json; charset=utf-8",error,strlen(error));return;}
    const char *ok="{\"saved\":true}\n";
    respond(fd,200,"OK","application/json; charset=utf-8",ok,strlen(ok));
}

/* Reads the value of "key":"..." out of a compact JSON object. Returns 0
   (leaving out untouched) if the key is absent or the value does not fit
   out_cap, including the terminator. */
static int extract_json_string(const char *input, const char *key, char *out, size_t out_cap) {
    char needle[32];
    int written = snprintf(needle, sizeof(needle), "\"%s\":\"", key);
    if (written <= 0 || (size_t)written >= sizeof(needle)) return 0;
    const char *start = strstr(input, needle);
    if (!start) return 0;
    start += written;
    const char *end = strchr(start, '"');
    if (!end) return 0;
    size_t length = (size_t)(end - start);
    if (length == 0 || length >= out_cap) return 0;
    memcpy(out, start, length);
    out[length] = '\0';
    return 1;
}

/* Any locale that has a web/locales/<code>.json file is valid: the backend
   only stores the code, the frontend decides what to do with it (falling
   back to English for an unknown or not-yet-translated one). Empty until a
   language has been saved, so browsers can tell "never chosen" (and follow
   their own language) from an explicit choice. */
static const char *preferences_language(void) {
    static char language[9];
    language[0] = '\0';
    FILE *file = fopen(ui_preferences_path, "rb");
    if (!file) return language;
    char body[96];
    size_t length = fread(body, 1, sizeof(body) - 1, file);
    fclose(file);
    body[length] = '\0';
    char code[9];
    if (extract_json_string(body, "language", code, sizeof(code)) && locale_code_valid(code, strlen(code)))
        memcpy(language, code, strlen(code) + 1);
    return language;
}

/* Like the language, a theme is only an identifier the backend stores; the
   frontend owns the list of palettes and falls back to "dark" for an unknown
   one. Accepted shape: lowercase words joined by single hyphens, 2-24 chars
   ("dark", "light", "solarized-light"). */
static int theme_valid(const char *code, size_t length) {
    if (length < 2 || length > 24) return 0;
    for (size_t index = 0; index < length; ++index) {
        int hyphen = code[index] == '-';
        if (!hyphen && !(code[index] >= 'a' && code[index] <= 'z')) return 0;
        if (hyphen && (index == 0 || index == length - 1 || code[index - 1] == '-')) return 0;
    }
    return 1;
}

static const char *preferences_theme(void) {
    static char theme[25] = "dark";
    FILE *file = fopen(ui_preferences_path, "rb");
    if (!file) return theme;
    char body[160];
    size_t length = fread(body, 1, sizeof(body) - 1, file);
    fclose(file);
    body[length] = '\0';
    char code[25];
    if (extract_json_string(body, "theme", code, sizeof(code)) && theme_valid(code, strlen(code)))
        memcpy(theme, code, strlen(code) + 1);
    else
        memcpy(theme, "dark", 5);
    return theme;
}

static const char *quick_action_defaults[4] = {
    "home:ALL", "system:heaters_off", "system:fans_off", "system:motors_off"
};

static int quick_action_valid(const char *action) {
    static const char *allowed[] = {
        "home:ALL", "home:X", "home:Y", "home:Z",
        "system:heaters_off", "system:fans_off", "system:motors_off",
        "light:toggle", "page:control", "page:files", "page:bed", "page:canvas",
        "calibration:shaper", "calibration:hotend", "calibration:bed",
        "grille:open", "grille:close", "settings:connection",
        "control:fans", "control:tuning", "control:heating"
    };
    for (size_t index = 0; index < sizeof(allowed) / sizeof(allowed[0]); ++index)
        if (strcmp(action, allowed[index]) == 0) return 1;
    return 0;
}

static const char *preferences_quick_action(int slot) {
    static char actions[4][32];
    static const char *const keys[4] = {"quick1", "quick2", "quick3", "quick4"};
    if (slot < 0 || slot >= 4) return quick_action_defaults[0];
    snprintf(actions[slot], sizeof(actions[slot]), "%s", quick_action_defaults[slot]);
    FILE *file = fopen(ui_preferences_path, "rb");
    if (!file) return actions[slot];
    char body[512], value[32];
    size_t length = fread(body, 1, sizeof(body) - 1, file);
    fclose(file); body[length] = '\0';
    if (extract_json_string(body, keys[slot], value, sizeof(value)) && quick_action_valid(value))
        snprintf(actions[slot], sizeof(actions[slot]), "%s", value);
    return actions[slot];
}

static int preferences_camera_value(const char *body) {
    const char *value = strstr(body, "\"camera_persistent\":");
    if (!value) return -1;
    value += strlen("\"camera_persistent\":");
    while (isspace((unsigned char)*value)) value++;
    int enabled;
    if (!strncmp(value, "true", 4)) { enabled = 1; value += 4; }
    else if (!strncmp(value, "false", 5)) { enabled = 0; value += 5; }
    else return -1;
    while (isspace((unsigned char)*value)) value++;
    return (*value == ',' || *value == '}') ? enabled : -1;
}

static int preferences_camera_persistent(void) {
    FILE *file = fopen(ui_preferences_path, "rb");
    if (!file) return 0;
    char body[512];
    size_t length = fread(body, 1, sizeof(body) - 1, file);
    fclose(file); body[length] = 0;
    return preferences_camera_value(body) == 1;
}

static void preferences_get_response(int fd) {
    char body[384];
    int length = snprintf(body, sizeof(body),
        "{\"language\":\"%s\",\"theme\":\"%s\",\"quick_actions\":[\"%s\",\"%s\",\"%s\",\"%s\"],\"camera_persistent\":%s}\n",
        preferences_language(), preferences_theme(), preferences_quick_action(0),
        preferences_quick_action(1), preferences_quick_action(2), preferences_quick_action(3),
        preferences_camera_persistent() ? "true" : "false");
    respond(fd, 200, "OK", "application/json; charset=utf-8", body, (size_t)length);
}

static void preferences_put_response(int fd, const char *body, size_t body_len) {
    if (!body || body_len < 2 || body_len > 512) {
        const char *error = "{\"saved\":false,\"error\":\"Invalid preferences\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    char input[513];
    size_t compact_len = 0;
    for (size_t index = 0; index < body_len; ++index) {
        if (!isspace((unsigned char)body[index])) input[compact_len++] = body[index];
    }
    input[compact_len] = '\0';
    int has_camera = strstr(input, "\"camera_persistent\":") != NULL;
    int camera_enabled = has_camera ? preferences_camera_value(input) : preferences_camera_persistent();
    char language_code[9];
    int has_language = strstr(input, "\"language\":") != NULL;
    int valid_language = has_language &&
        extract_json_string(input, "language", language_code, sizeof(language_code)) &&
        locale_code_valid(language_code, strlen(language_code));
    char theme_code[25];
    int has_theme = strstr(input, "\"theme\":") != NULL;
    int valid_theme = has_theme &&
        extract_json_string(input, "theme", theme_code, sizeof(theme_code)) &&
        theme_valid(theme_code, strlen(theme_code));
    char quick[4][32]; int has_quick = 0, valid_quick = 1;
    static const char *const keys[4] = {"quick1", "quick2", "quick3", "quick4"};
    for (int slot = 0; slot < 4; ++slot) {
        const char *key = keys[slot];
        snprintf(quick[slot], sizeof(quick[slot]), "%s", preferences_quick_action(slot));
        char key_marker[12]; snprintf(key_marker, sizeof(key_marker), "\"%s\":", key);
        if (strstr(input, key_marker)) {
            has_quick = 1;
            if (!extract_json_string(input, key, quick[slot], sizeof(quick[slot])) ||
                !quick_action_valid(quick[slot])) valid_quick = 0;
        }
    }
    if ((!has_language && !has_theme && !has_quick && !has_camera) || (has_language && !valid_language) ||
        !valid_quick || camera_enabled < 0 ||
        (has_theme && !valid_theme)) {
        const char *error = "{\"saved\":false,\"error\":\"Unsupported UI preference\"}\n";
        respond(fd, 400, "Bad Request", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    const char *language = valid_language ? language_code : preferences_language();
    const char *theme = valid_theme ? theme_code : preferences_theme();
    char temporary[512];
    if (snprintf(temporary, sizeof(temporary), "%s.new", ui_preferences_path) >= (int)sizeof(temporary)) {
        const char *error = "{\"saved\":false,\"error\":\"Preferences path is too long\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    char canonical[384];
    int canonical_len = snprintf(canonical, sizeof(canonical),
        "{\"language\":\"%s\",\"theme\":\"%s\",\"quick1\":\"%s\",\"quick2\":\"%s\",\"quick3\":\"%s\",\"quick4\":\"%s\",\"camera_persistent\":%s}\n",
        language, theme, quick[0], quick[1], quick[2], quick[3], camera_enabled ? "true" : "false");
    FILE *file = fopen(temporary, "wb");
    int failed = !file;
    if (file) {
        if (fwrite(canonical, 1, (size_t)canonical_len, file) != (size_t)canonical_len ||
            fflush(file) != 0 || fclose(file) != 0) failed = 1;
    }
    if (!failed && chmod(temporary, S_IRUSR | S_IWUSR) != 0) failed = 1;
    if (!failed && rename(temporary, ui_preferences_path) != 0) failed = 1;
    if (failed) {
        unlink(temporary);
        const char *error = "{\"saved\":false,\"error\":\"Cannot save preferences\"}\n";
        respond(fd, 500, "Internal Server Error", "application/json; charset=utf-8", error, strlen(error));
        return;
    }
    const char *ok = "{\"saved\":true}\n";
    respond(fd, 200, "OK", "application/json; charset=utf-8", ok, strlen(ok));
}

/* Passive G-code reports only: no command, extra socket or firmware polling. */
static void console_monitor_response(int fd) {
 uds_console_lease(&telemetry);
 const uds_console *log=&telemetry.console;
 size_t capacity=UDS_CONSOLE_LINES*(UDS_CONSOLE_LINE*2+4)+256;
 char *body=malloc(capacity);
 if(!body){respond(fd,503,"Service Unavailable","application/json","{}",2);return;}
 size_t used=(size_t)snprintf(body,capacity,"{\"connected\":%s,\"sequence\":%lu,\"dropped\":%lu,\"frames\":[",
  uds_fresh(&telemetry)?"true":"false",log->sequence,log->dropped);
 for(unsigned int i=0;i<log->count;i++){
  unsigned int index=(log->next+UDS_CONSOLE_LINES-log->count+i)%UDS_CONSOLE_LINES;
  char escaped[UDS_CONSOLE_LINE*2];json_escape(escaped,sizeof(escaped),log->lines[index]);
  used+=(size_t)snprintf(body+used,capacity-used,"%s\"%s\"",i?",":"",escaped);
 }
 used+=(size_t)snprintf(body+used,capacity-used,"]}");
 respond(fd,200,"OK","application/json; charset=utf-8",body,used);free(body);
}

static void console_status_response(int fd, console_state *console, const char *query) {
    size_t capacity = CONSOLE_OUTPUT_MAX * 2 + 1024;
    char *body = malloc(capacity);
    if (!body) {
        const char *error = "Out of memory\n";
        respond(fd,500,"Internal Server Error","text/plain; charset=utf-8",error,strlen(error));
        return;
    }
    console_json_query(console, query, body, capacity);
    respond(fd,200,"OK","application/json; charset=utf-8",body,strlen(body));
    free(body);
}

static void console_clear_response(int fd, console_state *console) {
    if (console_clear(console) != 0) {
        const char *error="{\"cleared\":false,\"error\":\"Cannot clear while a command is running\"}\n";
        respond(fd,409,"Conflict","application/json; charset=utf-8",error,strlen(error)); return;
    }
    const char *ok="{\"cleared\":true}\n";
    respond(fd,200,"OK","application/json; charset=utf-8",ok,strlen(ok));
}

static void console_command_response(int fd, console_state *console, const mqtt_client *mqtt,
                                     const char *body, size_t body_len) {
    char command[CONSOLE_COMMAND_MAX], reason[256];
    while (body_len && isspace((unsigned char)*body)) { body++; body_len--; }
    while (body_len && isspace((unsigned char)body[body_len-1])) body_len--;
    if (!body_len || body_len >= sizeof(command)) {
        const char *error="{\"accepted\":false,\"error\":\"Invalid command length\"}\n";
        respond(fd,400,"Bad Request","application/json; charset=utf-8",error,strlen(error)); return;
    }
    memcpy(command,body,body_len); command[body_len]='\0';
    if (!strcasecmp(command,"M112")) usb_start_cancel();
    /* M112 bypasses the console and the firmware's command queue; see console_emergency_stop(). */
    if (!strcasecmp(command,"M112") && console_emergency_stop(console,reason,sizeof(reason)) == 0) {
        const char *ok="{\"accepted\":true}\n";
        respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok)); return;
    }
    /* User macros may call SAVE_CONFIG indirectly; emergency stop stays independent. */
    const char *pending = pending_autosave_guard();
    if (pending && strcasecmp(command, "M112")) {
        plates_fail(fd, 409, pending); return;
    }
    if(plates_background_active() && strcmp(command,"M112")){plates_fail(fd,409,"Plate verification is still running");return;}
    if (!console_command_allowed(console,command,mqtt,reason,sizeof(reason)) ||
        console_start(console,command,reason,sizeof(reason)) != 0) {
        char escaped[300],response[420]; json_escape(escaped,sizeof(escaped),reason);
        int n=snprintf(response,sizeof(response),"{\"accepted\":false,\"error\":\"%s\"}\n",escaped);
        respond(fd,409,"Conflict","application/json; charset=utf-8",response,(size_t)n); return;
    }
    const char *ok="{\"accepted\":true}\n";
    respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));
}

/* Compact PID readback: reuse console reports without polling the firmware. */
static int pid_completed_report(const char *output) {
    const char *p=output;
    while((p=strstr(p,"\"command\""))) {
        p+=9;while(isspace((unsigned char)*p))p++;
        if(*p!=':')continue;
        p++;
        while(isspace((unsigned char)*p))p++;
        if(strncmp(p,"\"pid_calibrate\"",15))continue;
        const char *line=strchr(p,'\n'),*result=strstr(p,"\"result\"");
        if(!result||(line&&result>=line))continue;
        result+=8;while(isspace((unsigned char)*result))result++;
        if(*result!=':')continue;
        result++;
        while(isspace((unsigned char)*result))result++;
        if(!strncmp(result,"\"completed\"",11))return 1;
    }
    return 0;
}
static int pid_ready_locked(const console_state *console) {
    return !console->busy && console->completed && console->success &&
        !strncmp(console->command,"PID_CALIBRATE HEATER=",21) && pid_completed_report(console->output);
}
static void pid_status_response(int fd,console_state *console) {
    char body[512],kp[40],ki[40],kd[40];
    pthread_mutex_lock(&console->lock);
    int selected=!strncmp(console->command,"PID_CALIBRATE HEATER=",21);
    int ready=pid_ready_locked(console),busy=console->busy;
    double p=number_after_marker(console->output,"pid_Kp="),i=number_after_marker(console->output,"pid_Ki="),d=number_after_marker(console->output,"pid_Kd=");
    json_number(kp,sizeof(kp),ready&&isfinite(p)&&p>=0,p);
    json_number(ki,sizeof(ki),ready&&isfinite(i)&&i>=0,i);
    json_number(kd,sizeof(kd),ready&&isfinite(d)&&d>=0,d);
    const char *heater=selected?(strstr(console->command,"HEATER=extruder ")?"extruder":"heater_bed"):"";
    int n=snprintf(body,sizeof(body),"{\"busy\":%s,\"heater\":\"%s\",\"ready\":%s,\"failed\":%s,\"kp\":%s,\"ki\":%s,\"kd\":%s}\n",
        busy?"true":"false",heater,ready?"true":"false",selected&&console->completed&&!ready?"true":"false",kp,ki,kd);
    pthread_mutex_unlock(&console->lock);
    respond(fd,200,"OK","application/json",body,(size_t)n);
}


/* A session, and a shutdown that is still pending, live only in this process. The marker
 * file tells the next process that one was left behind when this one was killed or
 * replaced: without it the bed would stay at the session's target with nobody to switch it
 * off. It is kept in /tmp, which a reboot clears together with the heater targets. It holds
 * that bed target in degrees; an empty marker (from an earlier version) stands for 60 C. */
static char screws_marker_default_path[64];
static const char *screws_marker_path = NULL;
static int screws_marker_present = -1; /* -1: not looked at yet */
static int screws_marker_bed = -1;     /* the bed target written to the marker, -1: none */
static int screws_resumed;             /* the pending shutdown comes from the marker */
static int screws_resumed_bed = CONTROL_SCREWS_BED_DEFAULT; /* the bed target the earlier process left */

static void screws_marker_sync(void){
    int want=control_screws_session_active()||control_screws_heaters_off_pending();
    /* The tramming session heats the bed to its chosen target. A shutdown that is only pending keeps the
     * target of the session that asked for it. */
    int bed=control_screws_session_active()?control_screws_bed():
            screws_marker_bed>=0?screws_marker_bed:screws_resumed_bed;
    if(!screws_marker_path||(want==screws_marker_present&&(!want||bed==screws_marker_bed)))return;
    if(want){
        char text[16];int n=snprintf(text,sizeof(text),"%d\n",bed);
        int fd=open(screws_marker_path,O_WRONLY|O_CREAT|O_TRUNC|O_NOFOLLOW|O_CLOEXEC,0600);
        if(fd<0)return; /* tried again on the next tick */
        int written=n>0&&write(fd,text,(size_t)n)==n;
        close(fd);
        if(!written)return;
        screws_marker_bed=bed;
    }else{
        if(unlink(screws_marker_path)!=0&&errno!=ENOENT)return;
        screws_marker_bed=-1;
    }
    screws_marker_present=want;
}
/* At startup: a marker of our own from an earlier process makes the shutdown pending. */
static void screws_marker_restore(int port){
    if(!screws_marker_path){
        snprintf(screws_marker_default_path,sizeof(screws_marker_default_path),"/tmp/cc2-control-%d-screw-session",port);
        screws_marker_path=screws_marker_default_path;
    }
    struct stat info;
    screws_marker_present=lstat(screws_marker_path,&info)==0;
    if(!screws_marker_present||!S_ISREG(info.st_mode)||info.st_uid!=geteuid())return;
    /* The marker holds the bed target of the session it stood for (0..110 C); an empty one,
     * from an earlier version, is the tramming session's 60 C. */
    char text[16]={0};int fd=open(screws_marker_path,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
    if(fd>=0){ssize_t n=read(fd,text,sizeof(text)-1);(void)n;close(fd);}
    char *end=NULL;long bed=strtol(text,&end,10);
    screws_resumed_bed=end!=text&&(*end==0||*end=='\n')&&bed>=0&&bed<=CONTROL_SCREWS_BED_MAX?(int)bed
                                                                                          :CONTROL_SCREWS_BED_DEFAULT;
    screws_marker_bed=screws_resumed_bed;
    control_screws_restore_pending();
    screws_resumed=1;
}

/* The session left the bed at its target, or an explicit end has not been confirmed:
 * retry the shutdown on every tick until it is delivered while the printer is
 * idle and the console free. A shutdown inherited from an earlier process is sent
 * only while telemetry still shows the session's bed target: a bed that is off
 * already, or that someone has set differently since, is left alone. */
static void screws_heaters_off_tick(const mqtt_client *mqtt,int busy,int (*send)(const char *script),
                                    int have_bed_target,double bed_target){
    if(!control_screws_heaters_off_pending()){screws_resumed=0;return;}
    if(busy||!mqtt->connected||!mqtt->registered||!mqtt->have_machine_status||mqtt->machine_status!=1)return;
    if(screws_resumed){
        if(!have_bed_target)return;
        if(fabs(bed_target-screws_resumed_bed)>0.5){control_screws_heaters_off_sent();screws_resumed=0;return;}
    }
    if(send("TURN_OFF_HEATERS")==0){control_screws_heaters_off_sent();screws_resumed=0;}
}

/* Keep the session's bed at its target, but only while telemetry still shows that target:
 * a target someone else set is left alone. */
static void screws_bed_renew_tick(const mqtt_client *mqtt,int busy,time_t now,int (*send)(const char *script),
                                  int have_bed_target,double bed_target){
    if(!control_screws_bed_renew_due(now)||busy||!mqtt->have_machine_status||mqtt->machine_status!=1)return;
    if(!have_bed_target||fabs(bed_target-control_screws_bed())>0.5)return;
    char renew[24];snprintf(renew,sizeof(renew),"M140 S%d",control_screws_bed());
    control_screws_bed_renewed(now,send(renew)==0);
}

/* A screw measurement may follow a bed mesh directly (control_screws_after_mesh): the bed target of a calibration whose
 * probing succeeded (result done, saved or work) when it ended at most SCREWS_AFTER_MESH_MS ago and no other console job
 * has run since (the console's last job is still its BED_MESH_CALIBRATE), else -1. X, Y and Z homed and the same bed
 * target are checked when the script is built. */
#define SCREWS_AFTER_MESH_MS 180000
static int screws_after_mesh_bed(console_state *console) {
    if (plates_cal.stage || !plates_cal.ended_at) return -1;
    long long now = monotonic_ms();
    if (now < plates_cal.ended_at || now - plates_cal.ended_at > SCREWS_AFTER_MESH_MS) return -1;
    pthread_mutex_lock(&console->lock);
    int same = !console->busy && console->generation == plates_cal.generation;
    pthread_mutex_unlock(&console->lock);
    return same ? plates_cal.temp : -1;
}

/* What POST /api/control notes once a screw job is queued. The console's job number is read only for a screw job (as
 * before the hold time): other actions, and callers without a console, never touch it. */
static void screws_note_queued(console_state *console, const char *action) {
    control_screws_note_action(action);
    if (!console || (!control_screws_is_quick(action) && !control_screws_is_tram(action))) return;
    pthread_mutex_lock(&console->lock); unsigned long generation = console->generation; pthread_mutex_unlock(&console->lock);
    if (control_screws_is_quick(action)) control_screws_note_quick(generation);
    if (control_screws_is_tram(action) && strcmp(action, "screws:tram:end")) control_screws_note_job(generation);
    if (!strcmp(action, "screws:tram:end")) control_screws_note_end(generation);
}

/* A hold time before a screw measurement: POST /api/control screws:soak:<minutes>:<measurement>. Built like the soak of
 * the bed mesh calibration (plates_cal in plates.h): M140 through the console, then the job waits until telemetry reads
 * the bed at its target, holds it for the minutes given and only then starts the measurement unchanged, the way
 * /api/control starts it. The console stays free meanwhile (no G4). While the job owns the bed it repeats the target
 * every ten minutes (the firmware's idle bed shutdown, see plates_cal_keep_bed). It never touches the nozzle: the
 * measurement's own G180 S3 or G28 heats it to the probing temperature. Every check of the measurement runs when the
 * hold time is accepted and again when it ends. The job lives only in this process: a restart of CC2 Control ends it
 * and leaves the bed at its target, which the firmware switches off 15 minutes after the last command, as after a
 * calibration that a restart ended. */
enum { SOAK_IDLE, SOAK_HEATING, SOAK_SOAKING };
#define SCREWS_SOAK_HEAT_MS (30 * 60000)
static struct {
    int stage, bed, seconds, m140_done;
    char action[96];          /* the measurement it starts, without the prefix */
    unsigned long generation; /* the console job of its M140 */
    long long since, done_at, soak_until, held, renew_at; /* stage start, M140 seen done, end of the hold, ... */
    const char *result;       /* "", "started", "cancelled", "ended" or "failed" */
    char reason[160];
} screws_soak = {.result = ""};
/* The bed of a job that ended before its own M140 reached telemetry: switched off once it shows, for a few seconds. */
static struct { int bed; long long until; } screws_soak_off;
/* Tests count the repeated targets and the switch-offs instead. */
static int (*screws_soak_send)(const char *script) = send_local_gcode_script;

static int screws_soak_active(void) { return screws_soak.stage != SOAK_IDLE; }

/* The bed heater is the job's while fresh MQTT reports Idle and fresh telemetry shows its target (as plates_cal_owns_bed). */
static int screws_soak_owns_bed(const mqtt_client *mqtt, int bed) {
    time_t now = time(NULL); double target;
    return mqtt->connected && mqtt->registered && mqtt->have_machine_status && mqtt->machine_status == 1 &&
           mqtt->last_message > 0 && now >= mqtt->last_message && now - mqtt->last_message <= 15 &&
           uds_value(&telemetry, U_BG, &target) && fabs(target - bed) <= 0.5;
}
/* At the target: at most 1 K below it (as the calibration) and, for a target of 5 C or more, at most 2.5 K above it; a
 * hotter bed is still cooling down (the measurements' own cooling limit, SCREWS_COOL_LIMIT_K in control.c). */
static int screws_soak_at_bed(double bed, int target) {
    return bed >= target - 1.0 && (target < 5 || bed <= target + 2.5);
}

static void screws_soak_end(const mqtt_client *mqtt, const char *result, const char *reason, int bed_off) {
    if (!screws_soak.stage) return;
    if (bed_off) {
        if (screws_soak_owns_bed(mqtt, screws_soak.bed)) (void)screws_soak_send("M140 S0");
        else if (screws_soak.stage == SOAK_HEATING && monotonic_ms() - screws_soak.since <= 10000) {
            screws_soak_off.bed = screws_soak.bed; screws_soak_off.until = screws_soak.since + 15000;
        }
    }
    fprintf(stderr, "Screw hold time at %d C before %s: %s %s\n", screws_soak.bed, screws_soak.action, result, reason);
    screws_soak.stage = SOAK_IDLE; screws_soak.result = result;
    snprintf(screws_soak.reason, sizeof(screws_soak.reason), "%s", reason);
}

static void screws_soak_keep_bed(const mqtt_client *mqtt, long long now) {
    if (now < screws_soak.renew_at || !screws_soak_owns_bed(mqtt, screws_soak.bed)) return;
    char command[24]; snprintf(command, sizeof(command), "M140 S%d", screws_soak.bed);
    screws_soak.renew_at = now + (screws_soak_send(command) == 0 ? PLATE_BED_RENEW_MS : 30000);
}

/* NULL when the measurement may start: fresh MQTT reports Idle and fresh telemetry reads the bed at its target. */
static const char *screws_soak_hold(const mqtt_client *mqtt, int have_bed, double bed, double target) {
    time_t now = time(NULL);
    if (!mqtt->connected || !mqtt->registered || !mqtt->have_machine_status || mqtt->last_message <= 0 ||
        now < mqtt->last_message || now - mqtt->last_message > 15) return "Printer status is stale";
    if (mqtt->machine_status != 1) return "The printer is not idle";
    if (!have_bed) return "Bed telemetry is unavailable";
    if (fabs(target - screws_soak.bed) > 0.5 || !screws_soak_at_bed(bed, screws_soak.bed)) return "The bed is not at the temperature";
    return NULL;
}

/* The checks POST /api/control makes before it queues `action` (a screws:measure... or screws:tram:start...
 * measurement), without queueing it: first those of the dispatcher (printer_change_refusal, as for that request), then
 * those of control_response. With `after_mesh` the direct variant may apply (*direct tells whether it does). */
static int screws_measure_check(const mqtt_client *mqtt, console_state *console, const char *action, int after_mesh,
                                char *reason, size_t cap, int *direct) {
    if (direct) *direct = 0;
    int plates_form;
    const char *blocked = printer_change_refusal("POST", "/api/control", action, strlen(action), &plates_form);
    if (blocked) { snprintf(reason, cap, "%s", blocked); return 0; }
    if (plates_background_active()) { snprintf(reason, cap, "Plate verification is still running"); return 0; }
    if (plates_cal.stage) { snprintf(reason, cap, "A bed mesh calibration is running"); return 0; }
    char script[700];
    control_screws_after_mesh(after_mesh ? screws_after_mesh_bed(console) : -1);
    int ok = control_check_script(action, mqtt, script, sizeof(script), reason, cap);
    if (direct) *direct = ok && control_screws_built_direct();
    control_screws_after_mesh(-1);
    return ok;
}

/* Starts the measurement after the hold time as /api/control would: 0 queued, 1 the console was busy (tried again), -1
 * not built. Never the direct variant: the job's own M140 ran after the mesh. The script is checked and queued first
 * and only then built with its effects (control_check_script builds the same script without them): a console that
 * refuses the start, tried again on every tick, leaves no session behind and no end reason, as no session ran. The
 * cancel tail is the same before and after the build (a session start's job is not yet done). */
static int screws_soak_start(const mqtt_client *mqtt, console_state *console, char *reason, size_t cap) {
    char script[700], built[700];
    control_screws_after_mesh(-1);
    if (!control_check_script(screws_soak.action, mqtt, script, sizeof(script), reason, cap)) return -1;
    const char *tail = control_screws_cancel_tail(screws_soak.action);
    if (tail) console_arm_staged(console, tail, control_axes_homed(mqtt));
    if (console_start(console, script, reason, cap) != 0) return 1;
    if (!control_build_script(screws_soak.action, mqtt, built, sizeof(built), reason, cap) || strcmp(built, script)) {
        /* Not reached: the same check in the same tick. Stop the queued job rather than run it without its state. */
        if (control_screws_is_start(screws_soak.action)) control_screws_invalidate();
        (void)console_cancel(console);
        snprintf(reason, cap, "The measurement could not be started");
        return -1;
    }
    screws_note_queued(console, screws_soak.action);
    return 0;
}

static void screws_soak_tick(const mqtt_client *mqtt, console_state *console, int emergency) {
    long long now = monotonic_ms();
    pthread_mutex_lock(&console->lock);
    int busy = console->busy, completed = console->completed, success = console->success;
    unsigned long generation = console->generation;
    pthread_mutex_unlock(&console->lock);
    if (screws_soak_off.until) {
        if (now > screws_soak_off.until || emergency) screws_soak_off.until = 0;
        else if (!busy && screws_soak_owns_bed(mqtt, screws_soak_off.bed) && screws_soak_send("M140 S0") == 0)
            screws_soak_off.until = 0;
    }
    if (!screws_soak.stage) return;
    if (emergency) { screws_soak_end(mqtt, "ended", "Emergency stop", 0); return; }
    if (plates_cal.stage) { screws_soak_end(mqtt, "ended", "A bed mesh calibration was started", 0); return; }
    if (mqtt->have_machine_status && mqtt->machine_status == 2) { screws_soak_end(mqtt, "ended", "A print started", 0); return; }
    if (!screws_soak.m140_done) {
        /* A later console job means that the job's M140 has ended. */
        if (generation != screws_soak.generation || (!busy && completed)) {
            if (generation == screws_soak.generation && !success) {
                screws_soak_end(mqtt, "failed", "The bed target could not be set", 1); return;
            }
            screws_soak.m140_done = 1; screws_soak.done_at = now;
        } else {
            if (now - screws_soak.since > 60000) screws_soak_end(mqtt, "failed", "The bed target could not be set", 1);
            return;
        }
    }
    if (mqtt->have_machine_status && mqtt->machine_status != 1) { screws_soak_end(mqtt, "ended", "The printer is not idle", 0); return; }
    double bed = 0, target = 0;
    int have_bed = uds_value(&telemetry, U_BT, &bed) && uds_value(&telemetry, U_BG, &target);
    if (screws_soak.stage == SOAK_HEATING) {
        if (have_bed && fabs(target - screws_soak.bed) > 0.5 && now - screws_soak.done_at > 10000) {
            screws_soak_end(mqtt, "ended", "The bed target was changed", 0); return;
        }
        if (have_bed && fabs(target - screws_soak.bed) <= 0.5 && screws_soak_at_bed(bed, screws_soak.bed)) {
            screws_soak.stage = SOAK_SOAKING; screws_soak.since = now;
            screws_soak.soak_until = now + (long long)screws_soak.seconds * 1000;
            return;
        }
        screws_soak_keep_bed(mqtt, now);
        if (now - screws_soak.since > SCREWS_SOAK_HEAT_MS)
            screws_soak_end(mqtt, "failed", "The bed did not reach the temperature", 1);
        return;
    }
    if (have_bed && fabs(target - screws_soak.bed) > 0.5) { screws_soak_end(mqtt, "ended", "The bed target was changed", 0); return; }
    if (!busy) screws_soak_keep_bed(mqtt, now);
    if (now < screws_soak.soak_until || busy) return; /* a command typed meanwhile finishes first */
    /* Waits up to a minute for fresh evidence, then stops. */
    const char *hold = screws_soak_hold(mqtt, have_bed, bed, target);
    if (hold) {
        if (!screws_soak.held) screws_soak.held = now;
        if (now - screws_soak.held > 60000) screws_soak_end(mqtt, "failed", hold, 1);
        return;
    }
    screws_soak.held = 0;
    char reason[256];
    if (!screws_measure_check(mqtt, console, screws_soak.action, 0, reason, sizeof(reason), NULL)) {
        screws_soak_end(mqtt, "failed", reason, 1); return;
    }
    int started = screws_soak_start(mqtt, console, reason, sizeof(reason));
    if (started < 0 || (started > 0 && now - screws_soak.soak_until > 60000)) { screws_soak_end(mqtt, "failed", reason, 1); return; }
    if (started == 0) screws_soak_end(mqtt, "started", "", 0);
}

static void screws_soak_json(char *out, size_t cap) {
    if (!screws_soak.stage) {
        char escaped[200]; json_escape(escaped, sizeof(escaped), screws_soak.reason);
        snprintf(out, cap, "{\"active\":false,\"result\":\"%s\",\"reason\":\"%s\"}", screws_soak.result, escaped);
        return;
    }
    long long left = screws_soak.stage == SOAK_SOAKING ? (screws_soak.soak_until - monotonic_ms() + 999) / 1000 : screws_soak.seconds;
    const char *kind = control_screws_action_kind(screws_soak.action);
    snprintf(out, cap, "{\"active\":true,\"stage\":\"%s\",\"bed\":%d,\"remaining\":%lld,\"total\":%d,\"action\":\"%s\"}",
             screws_soak.stage == SOAK_SOAKING ? "soaking" : "heating", screws_soak.bed, left > 0 ? left : 0,
             screws_soak.seconds, kind ? kind : "quick");
}

/* A screws:measure... or screws:tram:start... action, with or without a valid form. */
static int screws_measure_action(const char *action) {
    size_t n = !strncmp(action, "screws:measure", 14) ? 14 : !strncmp(action, "screws:tram:start", 17) ? 17 : 0;
    return n && (!action[n] || action[n] == ':');
}
static void control_reject(int fd, int status, const char *reason) {
    char escaped[300], response[420]; json_escape(escaped, sizeof(escaped), reason);
    int n = snprintf(response, sizeof(response), "{\"accepted\":false,\"error\":\"%s\"}\n", escaped);
    respond(fd, status, status == 400 ? "Bad Request" : "Conflict", "application/json; charset=utf-8", response, (size_t)n);
}

static void control_response(int fd,console_state *console,mqtt_client *mqtt,const char *body,size_t body_len){
    char action[160],script[700],reason[256];
    while(body_len&&isspace((unsigned char)*body)){body++;body_len--;}
    while(body_len&&isspace((unsigned char)body[body_len-1]))body_len--;
    if(!body_len||body_len>=sizeof(action)){
        const char *error="{\"accepted\":false,\"error\":\"Invalid action\"}\n";
        respond(fd,400,"Bad Request","application/json; charset=utf-8",error,strlen(error));return;
    }
    memcpy(action,body,body_len);action[body_len]='\0';
    if(!strcmp(action,"system:emergency_stop")){
        control_screws_invalidate_for(CONTROL_SCREWS_END_EMERGENCY);
        screws_soak_end(mqtt,"ended","Emergency stop",0);
        usb_start_cancel();
        /* Straight to the firmware's emergency_stop endpoint; the queued M112 below is only the fallback. */
        char stop_reason[160];
        if(console_emergency_stop(console,stop_reason,sizeof(stop_reason))==0){
            const char *ok="{\"accepted\":true}\n";
            respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));return;
        }
        fprintf(stderr,"Emergency stop endpoint failed (%s); sending M112\n",stop_reason);
    }
    /* R11: stop the running screw measurement after its current line; the console job itself lifts the nozzle and
     * switches the heaters off. Not a queued script, so it works while the console is busy. */
    if(!strcmp(action,"screws:cancel")){
        /* A hold time before a measurement ends at once; the bed goes off while the job owns it. */
        if(screws_soak.stage){
            screws_soak_end(mqtt,"cancelled","",1);
            const char *ok="{\"accepted\":true}\n";
            respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));return;
        }
        if(console_cancel(console)!=0){
            const char *error="{\"accepted\":false,\"error\":\"No screw measurement is running\"}\n";
            respond(fd,409,"Conflict","application/json; charset=utf-8",error,strlen(error));return;
        }
        control_screws_note_cancel();
        const char *ok="{\"accepted\":true}\n";
        respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));return;
    }
    if(!strcmp(action,"motors:quiet") && !experiments.quiet_motors){
        const char *error="{\"accepted\":false,\"error\":\"Enable the experimental Quiet controls first\"}\n";
        respond(fd,409,"Conflict","application/json",error,strlen(error));return;
    }
    if(plates_background_active() && strcmp(action,"system:emergency_stop")){plates_fail(fd,409,"Plate verification is still running");return;}
    /* A hold time before a screw measurement (screws:soak:<minutes>:<measurement>, see screws_soak above). With 0 minutes
     * the measurement runs exactly as without the prefix. */
    char soak_inner[96];int soak_minutes=0;
    int soak=control_screws_soak_parse(action,&soak_minutes,soak_inner,sizeof(soak_inner),reason,sizeof(reason));
    if(soak<0){control_reject(fd,400,reason);return;}
    if(soak&&!soak_minutes){memmove(action,soak_inner,strlen(soak_inner)+1);soak=0;}
    if(screws_measure_action(soak?soak_inner:action)){
        if(screws_soak.stage){control_reject(fd,409,"A screw measurement is waiting for its bed hold time: cancel it first");return;}
        /* The calibration would only wait for the console while the measurement heats and probes. */
        if(plates_cal.stage){control_reject(fd,409,"A bed mesh calibration is running");return;}
    }
    if(soak){
        int direct=0;
        if(!screws_measure_check(mqtt,console,soak_inner,1,reason,sizeof(reason),&direct)){control_reject(fd,409,reason);return;}
        /* Right after a bed mesh the bed was just held at this target: the hold time is left out. */
        if(direct)memmove(action,soak_inner,strlen(soak_inner)+1);
        else{
            /* The job ends on the next tick after an emergency stop (the latch stays until CC2 Control restarts), and
             * then without switching its bed off: refused before its M140 is sent. */
            if(atomic_load(&console->emergency_sent)){
                control_reject(fd,409,"An emergency stop was sent: restart the printer before a hold time");return;
            }
            char command[24];snprintf(command,sizeof(command),"M140 S%d",control_screws_action_bed(soak_inner));
            if(console_start(console,command,reason,sizeof(reason))!=0){control_reject(fd,409,reason);return;}
            pthread_mutex_lock(&console->lock);unsigned long generation=console->generation;pthread_mutex_unlock(&console->lock);
            memset(&screws_soak,0,sizeof(screws_soak));
            screws_soak.stage=SOAK_HEATING;screws_soak.bed=control_screws_action_bed(soak_inner);
            screws_soak.seconds=soak_minutes*60;screws_soak.generation=generation;screws_soak.result="";
            snprintf(screws_soak.action,sizeof(screws_soak.action),"%s",soak_inner);
            screws_soak.since=monotonic_ms();screws_soak.renew_at=screws_soak.since+PLATE_BED_RENEW_MS; /* the M140 */
            screws_soak_off.until=0;
            /* The job owns the bed now: a shutdown left pending by an ended session must not undo it. */
            control_screws_note_action(action);
            const char *ok="{\"accepted\":true}\n";
            respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));return;
        }
    }
    if(!strncmp(action,"grille:",7)){
        const char *native=uds_print_state(&telemetry);double nozzle,bed;
        /* No raw servo/PWM commands: native grille policy also owns the exhaust fan.
         * A retained MQTT print.enabled flag alone does not mean a job is running. */
        if(drying_active()||!native||(strcmp(native,"standby")&&strcmp(native,"complete")&&strcmp(native,"cancelled"))||
           !uds_value(&telemetry,U_EG,&nozzle)||!uds_value(&telemetry,U_BG,&bed)||
           !isfinite(nozzle)||!isfinite(bed)||nozzle!=0||bed!=0){
            plates_fail(fd,409,"Exhaust grille controls require fresh native idle state, heaters off and no bed-heating session");return;
        }
    }
    if(!strncmp(action,"light:",6)){
        if(strcmp(action,"light:on")&&strcmp(action,"light:off")){
            const char *error="{\"accepted\":false,\"error\":\"Unknown light state\"}\n";
            respond(fd,400,"Bad Request","application/json",error,strlen(error));return;
        }
        pthread_mutex_lock(&console->lock);int busy=console->busy;pthread_mutex_unlock(&console->lock);
        if(busy||mqtt_set_light(mqtt,!strcmp(action,"light:on"))!=0){
            const char *error=busy?
                "{\"accepted\":false,\"error\":\"Another command is running\"}\n":
                "{\"accepted\":false,\"error\":\"Printer did not acknowledge the light command\"}\n";
            respond(fd,409,"Conflict","application/json",error,strlen(error));return;
        }
        const char *ok="{\"accepted\":true}\n";
        respond(fd,202,"Accepted","application/json",ok,strlen(ok));return;
    }
    if (!strncmp(action, "pid:", 4)) {
        const char *pending = pending_autosave_guard();
        if (pending) { plates_fail(fd, 409, pending); return; }
    }
    if(!strcmp(action,"pid:save")) {
        pthread_mutex_lock(&console->lock);int ready=pid_ready_locked(console);pthread_mutex_unlock(&console->lock);
        if(!ready){const char *error="{\"error\":\"Complete a PID calibration before saving\"}\n";respond(fd,409,"Conflict","application/json",error,strlen(error));return;}
    }
    int z_action=!strncmp(action,"zoffset:",8);
    double z_next=0,z_reference=0;
    if(z_action){
        double current,delta;int end=0;
        const char *argument=!strncmp(action,"zoffset:adjust:",15)?action+15:
            !strncmp(action,"zoffset:undo:",13)?action+13:NULL;
        int valid=argument&&sscanf(argument,"%lf%n",&delta,&end)==1&&!argument[end]&&isfinite(delta);
        if(!valid||!z_offset_readback(&current)||z_offset_pending||
           fabs((current+delta)-(z_offset_session?z_offset_reference:current))>0.5001||
           (!strncmp(action,"zoffset:undo:",13)&&fabs((current+delta)-(z_offset_session?z_offset_reference:current))>0.0005)){
            const char *error="{\"accepted\":false,\"error\":\"Z offset requires fresh readback, confirmed previous motion and a session adjustment within +/-0.50 mm of the printer reference\"}\n";
            respond(fd,409,"Conflict","application/json; charset=utf-8",error,strlen(error));return;
        }
        z_next=current+delta;z_reference=z_offset_session?z_offset_reference:current;
    }
    double tune_value;
    if(strncmp(action,"tune:",5)==0&&
       !uds_value(&telemetry,strncmp(action,"tune:pressure-advance:",22)==0?U_PRESSURE_ADVANCE:
          strncmp(action,"tune:speed:",11)==0?U_SPEED_FACTOR:U_FLOW_FACTOR,&tune_value)){
        const char *error="{\"accepted\":false,\"error\":\"Fresh tuning readback is unavailable\"}\n";
        respond(fd,409,"Conflict","application/json; charset=utf-8",error,strlen(error));return;
    }
    if(!strncmp(action,"tune:pressure-advance:",22)){
        const char *native_state=uds_print_state(&telemetry);
        int idle=native_state&&(!strcmp(native_state,"standby")||!strcmp(native_state,"complete"));
        int printing_state=native_state&&(!strcmp(native_state,"printing")||!strcmp(native_state,"paused"));
        if(!((mqtt->machine_status==1&&idle)||(mqtt->machine_status==2&&printing_state))){
            const char *error="{\"accepted\":false,\"error\":\"Pressure Advance requires matching fresh native Idle or print state\"}\n";
            respond(fd,409,"Conflict","application/json; charset=utf-8",error,strlen(error));return;
        }
    }
    if(external_feed_enabled&&external_source_selected&&!strncmp(action,"canvas:",7)){
        const char *error="{\"error\":\"Select Canvas with the external filament removed before using its controls\"}";
        respond(fd,409,"Conflict","application/json",error,strlen(error));return;
    }
    mqtt->external_verified=0;
    mqtt->external_temperature=0;
    if(!strncmp(action,"external:",9)){
        char *reply=NULL;size_t length=0;external_readback state={0};
        if(external_read(&reply,&length,&state)){
            mqtt->external_verified=state.idle;
            if(!state.disconnected&&external_feed_enabled&&external_source_selected&&
                external_fresh_idle(mqtt,&state)&&state.active_channel==-1&&state.have_sensor&&
                (strcmp(action,"external:unload")||state.filament_detected))mqtt->external_verified=2;
            mqtt->external_temperature=state.temperature;
        }
        free(reply);
    }
    control_screws_after_mesh(screws_measure_action(action)?screws_after_mesh_bed(console):-1);
    int built=control_build_script(action,mqtt,script,sizeof(script),reason,sizeof(reason));
    int after_mesh=built&&control_screws_built_direct();
    control_screws_after_mesh(-1);
    mqtt->external_verified=0;
    if(built&&external_feed_enabled&&!external_source_selected&&
       (!strncmp(action,"canvas:load:",12)||!strncmp(action,"canvas:recover-load:",20)||!strncmp(action,"canvas:unload:",14))){
        char next[sizeof(script)];int n=snprintf(next,sizeof(next),"USED_CANVAS_DEV USED_CANVAS=1\n%s",script);
        if(n<0||(size_t)n>=sizeof(next)){built=0;snprintf(reason,sizeof(reason),"Source script exceeds capacity");}
        else memcpy(script,next,(size_t)n+1);
    }
    if(built&&control_screws_cancel_tail(action))console_arm_staged(console,control_screws_cancel_tail(action),control_axes_homed(mqtt));
    if(!built||console_start(console,script,reason,sizeof(reason))!=0){
        /* Only a start this call built: a start refused because a session is running must not end that session. */
        if(built&&control_screws_is_start(action))control_screws_invalidate_for(CONTROL_SCREWS_END_CONSOLE);
        char escaped[300],response[420];json_escape(escaped,sizeof(escaped),reason);
        int n=snprintf(response,sizeof(response),"{\"accepted\":false,\"error\":\"%s\"}\n",escaped);
        respond(fd,409,"Conflict","application/json; charset=utf-8",response,(size_t)n);return;
    }
    screws_note_queued(console,action);
    /* Another screw action (the measurements are refused meanwhile) or switched-off heaters end a hold time; the
     * action itself sets the heaters. */
    if(!strncmp(action,"screws:",7))screws_soak_end(mqtt,"ended","Another screw action was started",0);
    if(!strcmp(action,"heaters:off")||!strcmp(action,"system:heaters_off")||!strcmp(action,"system:all_off"))
        screws_soak_end(mqtt,"ended","The heaters were switched off",0);
    if(control_heater_action(action))screws_soak_off.until=0;
    if(!strcmp(action,"motors:quiet")||!strcmp(action,"motors:normal")){
        motor_mode_requested=action[7]=='q'?"quiet":"normal";motor_mode_connection=telemetry.connections;
    }
    if(!strncmp(action,"canvas:material:",16)||!strncmp(action,"canvas:catalog:",15)||!strcmp(action,"canvas:reset-all")){mqtt->canvas_material_read_at=time(NULL)+1;mqtt->canvas_watch_until=time(NULL)+15;}
    if(z_action){z_offset_reference=z_reference;z_offset_session=1;z_offset_expected=z_next;z_offset_pending=1;z_offset_timed_out=0;clock_gettime(CLOCK_MONOTONIC,&z_offset_started);}
    /* after_mesh: the measurement follows the bed mesh directly (no nozzle cleaning, no full G28, no hold time). */
    const char *ok=after_mesh?"{\"accepted\":true,\"after_mesh\":true}\n":"{\"accepted\":true}\n";
    respond(fd,202,"Accepted","application/json; charset=utf-8",ok,strlen(ok));
}

static int connections_busy(void);
static int installer_native_observation(int canvas_only,int canvas_transfer);
#include "rfid_http.h"
#include "rfid_lifecycle_http.h"

/* Release the steppers the firmware leaves energised once the printer has
 * stood idle with its heaters off; see control_idle_motors_due(). */
static control_idle_motors idle_motors;
static control_idle_sample idle_motors_observe(const mqtt_client *mqtt,console_state *console){
    control_idle_sample s={0};
    s.valid=gcode_idle_for_mutation(mqtt)&&mqtt->have_position&&
        uds_value(&telemetry,U_CF,&s.board_fan)&&uds_value(&telemetry,U_EG,&s.nozzle_target)&&
        uds_value(&telemetry,U_BG,&s.bed_target)&&uds_value(&telemetry,U_LIVE_SPEED,&s.velocity);
    s.machine_status=mqtt->machine_status;s.print_state=mqtt->print_state;
    s.x=mqtt->x;s.y=mqtt->y;s.z=mqtt->z;
    s.session=control_screws_session_active();
    pthread_mutex_lock(&console->lock);s.console_busy=console->busy;pthread_mutex_unlock(&console->lock);
    return s;
}
static void idle_motors_tick(const mqtt_client *mqtt,console_state *console){
    if(maintenance_barrier_active()){idle_motors.holding=0;return;}
    control_idle_sample s=idle_motors_observe(mqtt,console);
    if(!control_idle_motors_due(&idle_motors,&s,recovery_clock()))return;
    /* Admission is expensive with ABI2. Check it when an operation is due,
     * not on every HTTP/event-loop iteration. Never consume a refused M84;
     * require a new full idle interval after maintenance or lifecycle refusal. */
    if(rn_blocks()||maintenance_barrier_active()){
        idle_motors.holding=0;idle_motors.released=0;return;
    }
    /* Admission can take time: re-read freshness and motion/heater state
     * after it, before committing the release or sending any command. */
    s=idle_motors_observe(mqtt,console);
    idle_motors.released=0;
    if(!control_idle_motors_due(&idle_motors,&s,recovery_clock()))return;
    if(send_local_gcode_script("M84")!=0)
        idle_motors.holding=0; /* Not delivered: wait a full period before trying again. */
}

/* Switch the X/Y motors back to Normal (SpreadCycle, stock limits) once a print
 * that ran in Quiet has ended; see control_motor_mode_restore_due(). */
static int motor_mode_seen_print;
static void motor_mode_tick(const mqtt_client *mqtt,console_state *console){
    int quiet=motor_mode_requested&&!strcmp(motor_mode_requested,"quiet")&&
        telemetry.fd>=0&&telemetry.connections==motor_mode_connection;
    if(!quiet||!mqtt->have_machine_status){if(!quiet)motor_mode_seen_print=0;return;}
    if(!control_motor_mode_restore_due(&motor_mode_seen_print,quiet,mqtt->machine_status,mqtt->print_state))return;
    pthread_mutex_lock(&console->lock);int busy=console->busy;pthread_mutex_unlock(&console->lock);
    char script[CONSOLE_COMMAND_MAX],reason[160];
    if(busy||!control_build_script("motors:normal",mqtt,script,sizeof(script),reason,sizeof(reason))||
       send_local_gcode_script(script)!=0){
        motor_mode_seen_print=1; /* Not sent: try again on the next tick. */
        return;
    }
    motor_mode_requested="normal";
}

static int installer_native_status(int canvas_only);
#include "app_updates.h"
#include "app_update_catalog.h"
#include "bed_drying.h"
#include "nozzle_expansion.h"

/* The POST paths that start one of the sessions printer_change_refusal pauses printer changes for (or a firmware tool
 * or a network change). While a hold time before a screw measurement runs they are refused: its bed is held and the
 * measurement starts on its own when it ends. */
static int screws_soak_blocks_path(const char *path) {
    static const char *const starts[] = {
        "/api/nozzle-expansion/start", "/api/bed-drying/start", "/api/bed-drying/preheat", "/api/calibration-tools/action",
        "/api/app-update/upload", "/api/app-update/download", "/api/app-update/install", "/api/network/action",
        "/api/network/scan", "/api/rfid/action", "/api/rfid/lifecycle/action"};
    for (size_t i = 0; i < sizeof(starts) / sizeof(starts[0]); i++) if (!strcmp(path, starts[i])) return 1;
    return 0;
}

/* The refusals of every printer change while another session owns the printer, in the order and with the exceptions
 * handle_client answers them: maintenance, RFID lifecycle and scan, the firmware calibration tools, the load-cell
 * session, a pending rotation distance change (plate settings), an application update or network change, bed heating and
 * the nozzle expansion calibration; then the starts refused during a screw hold time. GET, HEAD and the emergency stop
 * always pass. NULL when the request may go on, else the 409 text; *plates_form tells the reply (plates_fail, otherwise
 * app_update_fail). A start that no request carries asks as the request that would have started it (the measurement
 * after a hold time: POST /api/control). */
static const char *printer_change_refusal(const char *method, const char *path, const char *body, size_t body_len, int *plates_form) {
    int emergency = !strcmp(method, "POST") && !strcmp(path, "/api/control") &&
        body_len == strlen("system:emergency_stop") && !memcmp(body, "system:emergency_stop", body_len);
    int console_m112 = !strcmp(path, "/api/console/command") && body_len == 4 && !memcmp(body, "M112", 4);
    int console_emergency = !strcmp(method, "POST") && console_m112;
    int owned_rfid_cancel = rfid.child && !strcmp(method, "POST") && !strcmp(path, "/api/rfid/action") && body_len == 6 &&
        !memcmp(body, "cancel", 6);
    int change = strcmp(method, "GET") && strcmp(method, "HEAD") && !emergency;
    *plates_form = 0;
    if (maintenance_request_blocked(method, emergency, console_emergency) && !owned_rfid_cancel)
        return "Installation or native maintenance is running; printer changes are paused";
    if (change && !console_emergency && strcmp(path, "/api/rfid/lifecycle/action") && !owned_rfid_cancel && rn_blocks())
        return "RFID activation or recovery is incomplete; finish the lifecycle before changing the printer";
    *plates_form = 1;
    if (rfid.child && change && !console_emergency && strcmp(path, "/api/rfid/action"))
        return "Cancel the RFID scan before changing printer settings";
    if (tools.busy && change && !console_emergency) return "A native calibration tool is still running";
    if (cell_active() && change && !console_emergency && strcmp(path, "/api/calibration-tools/action"))
        return "Finish the load-cell calibration session first";
    if (rotation_pending() && !strcmp(method, "POST") && !strncmp(path, "/api/plates/", 12))
        return "A rotation distance change needs a restart before changing plate settings";
    *plates_form = 0;
    if (change && (app_update_active() || (connections_busy() && strcmp(path, "/api/network/action"))))
        return "Application update is running; printer changes are paused";
    /* A drying session owns the bed until zero readback and timeout restoration.
     * M112 stays available; external display/slicer actions are observed by tick. */
    if (drying_active() && change && strcmp(path, "/api/bed-drying/stop") && !console_m112)
        return "Stop bed heating and wait for confirmation before another operation";
    /* The calibration heats the nozzle and moves the printhead until it has switched the nozzle off. */
    if (nx_active() && change && !console_m112)
        return "A nozzle expansion calibration is running; use the emergency stop to interrupt it";
    *plates_form = 1;
    if (screws_soak_active() && !strcmp(method, "POST") && screws_soak_blocks_path(path))
        return "A screw measurement is waiting for its bed hold time: cancel it first";
    *plates_form = 0;
    return NULL;
}

/* The refusals of handle_client for a start that no request carries, and a print start being prepared. */
static const char *printer_change_blocked(void) {
    int plates_form;
    const char *blocked = printer_change_refusal("POST", "", "", 0, &plates_form);
    if (blocked) return blocked;
    if (usb_start_active())
        return usb_start.internal ? "A print start is still being prepared" : "A USB file is still being copied for a print start";
    return NULL;
}
#include "experiments.h"
#include "backup.h"
#include "network_status_http.h"
#include "connections_http.h"

#define HTTP_PENDING_MAX 8
typedef struct {
    int fd;
    size_t used;
    struct timespec started;
    char request[REQUEST_MAX+1];
} http_pending;

static int http_request_complete(const char *request,size_t used){
    const char *end=strstr(request,"\r\n\r\n");size_t separator=4;
    if(!end){end=strstr(request,"\n\n");separator=2;}
    if(used==REQUEST_MAX)return 1;
    if(!end)return 0;
    if(!strncmp(request,"POST /api/app-update/upload ",sizeof("POST /api/app-update/upload ")-1)||
       !strncmp(request,"POST /api/gcode-files/upload?",29)||
       !strncmp(request,"POST /api/files/local ",22)||
       !strncmp(request,"POST /api/files/local?",22))return 1;
    size_t header=(size_t)(end-request)+separator;
    size_t length=content_length_from_headers(request);
    if(length>REQUEST_MAX-header)return -1;
    return used>=header+length;
}

/* 1 when `file` of the internal storage is the running print's, with the layer the service has seen for it. */
static int running_print_layer(const mqtt_client *mqtt,const char *file,int *current_layer){
    time_t now=time(NULL);
    int active_job=mqtt->connected&&mqtt->registered&&mqtt->last_message>0&&now-mqtt->last_message<=15&&
        mqtt->have_machine_status&&mqtt->machine_status==2&&mqtt->filename[0]&&
        (!strcmp(mqtt->print_state,"printing")||!strcmp(mqtt->print_state,"paused"));
    if(!active_job)return 0;
    const char *job=mqtt->filename;
    if(!strncmp(job,"local/",6))job+=6;
    if(strcmp(job,file))return 0;
    double live;*current_layer=mqtt->current_layer;
    if(uds_job_matches(&telemetry,mqtt->filename)&&uds_value(&telemetry,U_LAYER,&live))*current_layer=(int)live;
    return 1;
}

/* The read hold: while the printer homes, levels, probes or starts a print, no G-code file is read for the
 * layer path, the object preview or a picture (seen four times, last on 18.11.2026: a long read on the two
 * small cores while the printer homed for a print start, then the MCU's "Timer too close", error 803, and the
 * printer program crashed). One check for every file; it is on while
 * - fresh MQTT reports machine status 5 (Auto leveling), 7 (Resonance test), 8 (Self check) or
 *   10 (Manual homing): what the touchscreen, the printer's own calibrations and raw G28/PROBE report;
 * - fresh MQTT reports a print (status 2, printing or paused) that has not reached layer 1: heating, homing,
 *   probing and the purge of a print start (the layer as /api/printer shows it, which a new print resets to 0);
 * - this service's console runs a job that homes or probes (G28, G29, G180, PROBE..., BED_MESH_CALIBRATE,
 *   SCREWS_TILT_CALCULATE, Z_TILT_ADJUST, SHAPER_CALIBRATE, TEST_RESONANCES): the screw session, the mesh
 *   calibration and the console's own G28; MQTT reports such a job a poll later;
 * - this service's bed mesh calibration homes or probes.
 * "Fresh" is the 15 s of every other check here: connected, registered, a message within 15 s. Without the
 * printer nothing is held, so files can be browsed; MQTT that stops releases the hold after 15 s, so a stale
 * report never holds for long. What is remembered is still answered; the running print's own 409 refusals
 * come first. The main loop passes the result to running scans (gcode_read_hold) on every pass. */
static int gcode_read_homing_word(const char *word,size_t n){
    static const char *const words[]={"G28","G29","G180","PROBE","BED_MESH_CALIBRATE","SCREWS_TILT_CALCULATE",
                                      "Z_TILT_ADJUST","SHAPER_CALIBRATE","TEST_RESONANCES"};
    for(size_t i=0;i<sizeof(words)/sizeof(words[0]);i++){
        size_t w=strlen(words[i]);
        if(n==w&&!strncasecmp(word,words[i],n))return 1;
    }
    return n>6&&!strncasecmp(word,"PROBE_",6); /* PROBE_ACCURACY, PROBE_CALIBRATE; QUERY_PROBE does not move */
}
/* 1 when a line of `script` starts with a command that homes or probes. */
static int gcode_read_homing_script(const char *script){
    for(const char *line=script;*line;){
        while(*line==' '||*line=='\t'||*line=='\r'||*line=='\n')line++;
        size_t n=strcspn(line," \t\r\n");
        if(n&&gcode_read_homing_word(line,n))return 1;
        line+=strcspn(line,"\n");
    }
    return 0;
}
static int gcode_read_blocked(const mqtt_client *mqtt,console_state *console){
    if(console){
        pthread_mutex_lock(&console->lock);
        int homing=console->busy&&gcode_read_homing_script(console->command);
        pthread_mutex_unlock(&console->lock);
        if(homing)return 1;
    }
    if(plates_cal.stage==CAL_HOMING||plates_cal.stage==CAL_PROBING)return 1;
    time_t now=time(NULL);
    if(!mqtt||!mqtt->connected||!mqtt->registered||!mqtt->have_machine_status||mqtt->last_message<=0||
       now<mqtt->last_message||now-mqtt->last_message>15)return 0;
    int status=mqtt->machine_status;
    if(status==5||status==7||status==8||status==10)return 1;
    if(status!=2||(strcmp(mqtt->print_state,"printing")&&strcmp(mqtt->print_state,"paused")))return 0;
    double live;int layer=mqtt->current_layer;
    if(uds_job_matches(&telemetry,mqtt->filename)&&uds_value(&telemetry,U_LAYER,&live))layer=(int)live;
    return layer<1;
}
/* Answers a request (main thread) and tells running scans: they end at their next line once it is on. */
static int gcode_read_hold_now(const mqtt_client *mqtt,console_state *console){
    int held=gcode_read_blocked(mqtt,console);
    atomic_store(&gcode_read_hold,held);
    return held;
}
/* Every pass of the main loop, so a scan that began before the hold ends within about a second of it. */
static void gcode_read_follow(const mqtt_client *mqtt,console_state *console){(void)gcode_read_hold_now(mqtt,console);}

/* Refuses a layer-path request before any G-code is read when it names the file of the running print
 * and cannot belong to that print: a layer above the print's layer count, or a layer above 1 while the
 * service has not yet seen the print reach layer 1 (a new print can still show the layer of the one before
 * it, seen: layer 193 right after a start, a 20 s scan of 78.7 MB). Requests for other files, and any
 * request while no print runs (browsing by hand), pass. The reply is 409, which the page does not retry.
 * The layer the service has seen is the one /api/printer reports, which a new print resets to 0. */
static int layer_path_guard(int fd,const mqtt_client *mqtt,const char *query){
    char storage[16],file[LAYER_PATH_NAME_MAX];int layer=0;
    if(gcode_layer_path_query(query,storage,file,&layer)!=LAYER_PATH_OK||strcmp(storage,"internal"))return 0;
    int current_layer=0;
    if(!running_print_layer(mqtt,file,&current_layer))return 0;
    int file_layers=active_gcode_total_layers_now(mqtt,mqtt->filename);
    int total_layers=mqtt->have_total_layers?mqtt->total_layers:file_layers;
    if(total_layers>0&&layer>total_layers){
        layer_path_count_rejected();
        layer_path_fail(fd,409,"Conflict","Layer is beyond the running print");
        return 1;
    }
    if(layer>1&&current_layer<1){
        layer_path_count_rejected();
        layer_path_fail(fd,409,"Conflict","The running print has not reached that layer");
        return 1;
    }
    return 0;
}

/* The object preview of the running print's file waits, like layer 2 and up of the layer path, until the
 * service has seen the print reach layer 1: right after a start the printer is busiest and a full read of the
 * file could disturb it. Counted with the layer path's refusals. Layer numbers play no part here. */
static int object_preview_guard(int fd,const mqtt_client *mqtt,const char *query){
    char storage[16],file[LAYER_PATH_NAME_MAX],object[OBJECT_PREVIEW_NAME_MAX];int current_layer=0;
    if(gcode_object_preview_query(query,storage,file,object)!=OBJECT_PREVIEW_OK||strcmp(storage,"internal"))return 0;
    if(!running_print_layer(mqtt,file,&current_layer)||current_layer>=1)return 0;
    layer_path_count_rejected();
    layer_path_fail(fd,409,"Conflict","Object preview waits for the print start");
    return 1;
}

/* Drops the remembered object preview when a print of another file starts (the moments that reset the layer:
 * a new job uuid in mqtt.c, a new print or file in uds.c) or a print ends (printing or paused turns into
 * standby, complete, cancelled or error), and once it has not been asked for OBJECT_PREVIEW_KEEP_S. What is
 * remembered, or being read, for the file of the print that starts stays, so that file is not read a second
 * time after layer 1; a changed file is still read again (its stamp is compared on every request). Runs on
 * every pass of the main loop. */
static int object_preview_idle_state(const char *state){
    return !strcmp(state,"standby")||!strcmp(state,"complete")||!strcmp(state,"cancelled")||!strcmp(state,"error");
}
static void object_preview_print_started(const mqtt_client *mqtt,const uds_client *uds){
    const char *job=mqtt->filename;
    if(!strncmp(job,"local/",6))job+=6;
    pthread_mutex_lock(&object_preview_lock);
    int held=object_preview_cached.valid||object_preview_reading.active;
    const char *storage=object_preview_cached.valid?object_preview_cached.storage:object_preview_reading.storage;
    const char *file=object_preview_cached.valid?object_preview_cached.file:object_preview_reading.file;
    int same=held&&!strcmp(storage,"internal")&&((*job&&!strcmp(job,file))||uds_job_matches(uds,file));
    if(!same)object_preview_drop_locked();
    pthread_mutex_unlock(&object_preview_lock);
}
static void object_preview_follow(const mqtt_client *mqtt,const uds_client *uds){
    static int primed,mqtt_running,uds_running;static unsigned long mqtt_starts,uds_resets;
    int mqtt_now=!strcmp(mqtt->print_state,"printing")||!strcmp(mqtt->print_state,"paused");
    int uds_now=uds->have_print_state&&(!strcmp(uds->print_state,"printing")||!strcmp(uds->print_state,"paused"));
    int ended=(mqtt_running&&object_preview_idle_state(mqtt->print_state))||
              (uds_running&&uds->have_print_state&&object_preview_idle_state(uds->print_state));
    int started=mqtt->job_starts!=mqtt_starts||uds->job_resets!=uds_resets;
    if(primed&&ended)object_preview_forget();
    else if(primed&&started)object_preview_print_started(mqtt,uds);
    primed=1;mqtt_starts=mqtt->job_starts;uds_resets=uds->job_resets;
    if(mqtt_now)mqtt_running=1;else if(object_preview_idle_state(mqtt->print_state))mqtt_running=0;
    if(uds_now)uds_running=1;else if(uds->have_print_state&&object_preview_idle_state(uds->print_state))uds_running=0;
    object_preview_expire();
}

static int handle_client(int fd,char *request,size_t used,const char *web_root,mqtt_client *mqtt,console_state *console){
    /* A full initial read may contain a valid header followed by upload bytes.
     * Reject only oversized headers, not a streaming body's first chunk. */
    const char *request_header_end = strstr(request, "\r\n\r\n");
    if (!request_header_end) request_header_end = strstr(request, "\n\n");
    if (used == REQUEST_MAX && !request_header_end) {
        const char *body = "Request headers too large\n";
        respond(fd, 431, "Request Header Fields Too Large",
                "text/plain; charset=utf-8", body, strlen(body));
        return 0;
    }
    char method[16], path[2048], version[16];
    if (sscanf(request, "%15s %2047s %15s", method, path, version) != 3) return 0;
    if(!http_browser_allowed(fd,request,method,path,service_http_port,http_host_alias)){
        const char *error="{\"error\":\"Untrusted HTTP host or browser origin\"}\n";
        respond(fd,403,"Forbidden","application/json; charset=utf-8",error,strlen(error));return 0;
    }
    char *query = strchr(path, '?');
    if (query) *query++ = '\0';
    char *header_end=strstr(request,"\r\n\r\n"); size_t separator=4;
    if(!header_end){header_end=strstr(request,"\n\n");separator=2;}
    const char *body=header_end?header_end+separator:request+used;
    size_t body_len=header_end&&used>=(size_t)(body-request)?used-(size_t)(body-request):0;
    /* Every printer change is refused while another session owns the printer; the measurement after a screw hold time
     * asks the same function (screws_measure_check). */
    int plates_form;
    const char *change_refused=printer_change_refusal(method,path,body,body_len,&plates_form);
    if(change_refused){
        if(plates_form)plates_fail(fd,409,change_refused);else app_update_fail(fd,409,change_refused);
        return 0;
    }
    if(!strcmp(method,"GET")&&!strcmp(path,"/api/rfid/lifecycle")) {
        rfid_native_status_response(fd);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/rfid/lifecycle/action")) {
        rfid_native_action_response(fd,console,body,body_len);
    } else if(!strcmp(method,"GET")&&!strcmp(path,"/api/calibration-tools/status")) {
        tools_status(fd);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/calibration-tools/action")) {
        tools_action(fd,mqtt,body,body_len);
    } else if(!strcmp(path,"/api/network")) {
        if(!strcmp(method,"GET"))network_status_response(fd);
        else app_update_fail(fd,405,"Network status is read-only");
    } else if(!strcmp(method,"GET")&&!strcmp(path,"/api/network/manager")) {
        connections_status(fd,mqtt,console);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/network/action")) {
        connections_action(fd,body,body_len,0,mqtt,console);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/network/scan")) {
        connections_action(fd,body,body_len,1,mqtt,console);
    } else if(!strcmp(path,"/api/network/select") || !strcmp(path,"/api/network/trial")) {
        app_update_fail(fd,410,"Reload CC2 Control to use the Connections manager");
    } else if(!strcmp(method,"GET")&&!strcmp(path,"/api/cavity-fan-floor")){
        cavity_floor_response(fd);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/cavity-fan-floor")){
        cavity_floor_change(fd,mqtt,body,body_len);
    } else if(!strcmp(method,"GET")&&!strcmp(path,"/api/bed-drying")){
        drying_response(fd,mqtt,console);
    } else if(!strcmp(method,"GET")&&!strcmp(path,"/api/nozzle-expansion")){
        nx_response(fd);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/nozzle-expansion/start")){
        nx_start_response(fd,request,body,body_len,mqtt);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/nozzle-expansion/factory")){
        nx_factory_response(fd,mqtt,body,body_len);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/nozzle-expansion/restart")){
        nx_restart_response(fd,mqtt,body,body_len);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/bed-drying/start")){
        drying_start_response(fd,request,body,body_len,mqtt,console);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/bed-drying/preheat")){
        drying_preheat_response(fd,request,body,body_len,mqtt,console);
    } else if(!strcmp(method,"POST")&&!strcmp(path,"/api/bed-drying/stop")){
        drying_stop_response(fd,request,mqtt,console);
    } else if ((strcmp(method,"GET")==0 && strcmp(path,"/api/backup/export")==0) ||
        (strcmp(method,"POST")==0 && !strncmp(path,"/api/backup/import/",19))) {
        bk_response(fd,path,request,body,body_len,mqtt,console);
    } else if (!strcmp(method,"POST") && !strcmp(path,"/api/access/verify")) {
        if (!app_update_authorized(request,mqtt))
            app_update_fail(fd,401,"LAN code confirmation required or temporarily locked");
        else {
            const char *reply="{\"verified\":true}\n";
            respond(fd,200,"OK","application/json; charset=utf-8",reply,strlen(reply));
        }
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/experiments")==0) {
        experiments_response(fd,mqtt,console);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/experiments")==0) {
        experiments_put_response(fd,request,body,body_len,mqtt,console);
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/api/app-update/status") == 0) {
        app_update_status_response(fd, console);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/app-update/upload") == 0) {
        return header_end ? app_update_upload_start(fd, request, used, (size_t)(body-request), mqtt, console, NULL) : 0;
    } else if (strcmp(method, "GET") == 0 && strcmp(path, "/api/app-update/catalog") == 0) {
        app_catalog_get(fd);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/app-update/catalog") == 0) {
        app_catalog_store(fd, body, body_len);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/app-update/download") == 0) {
        return app_catalog_download(fd, request, body, body_len, mqtt, console);
    } else if (strcmp(method, "POST") == 0 && strcmp(path, "/api/app-update/install") == 0) {
        app_update_install_response(fd, request, body, body_len, mqtt, console);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/files/local")==0) {
        return header_end ? orca_upload_start(fd,request,used,(size_t)(body-request),mqtt):0;
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/upload")==0) {
        return header_end ? gcode_upload_start(fd,request,query,used,(size_t)(body-request),mqtt):0;
    } else if (strcmp(method,"GET")==0 && (strcmp(path,"/")==0 || strcmp(path,"/index.html")==0)) {
        serve_index(fd, web_root, request);
    } else if (strcmp(method,"GET")==0 && strncmp(path,"/i18n/",6)==0) {
        serve_locale(fd, web_root, path, request);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/orca/pending-print")==0) {
        orca_pending_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/orca/pending-print/clear")==0) {
        orca_pending_clear_response(fd,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/version")==0) {
        orca_version_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/health")==0) {
        health_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && (strcmp(path,"/api/v1/system/info")==0 || strcmp(path,"/api/system/capabilities")==0)) {
        system_info_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/setup")==0) {
        setup_status_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/setup")==0) {
        setup_configure_response(fd,mqtt,body,body_len,0);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/setup/revalidate")==0) {
        setup_configure_response(fd,mqtt,body,body_len,1);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/uds")==0) {
        uds_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/printer")==0) {
        printer_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/camera/claim")==0) {
        camera_claim_response(fd, body, body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/snapshot")==0) {
        snapshot_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/mqtt-diagnostic")==0) {
        mqtt_diagnostic_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/server/info")==0) {
        orca_server_info_response(fd,mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/server/database/item")==0 &&
               query && strcmp(query,"namespace=lane_data")==0) {
        orca_lane_data_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/rfid/lifecycle/scan-readiness")==0) {
        int ready=rfid_native_scan()&&rfid.child&&rfid.native_child&&!rfid.cancelled&&
            maintenance_barrier_active()&&rfid_same_identity()&&rfid_native_scan_available(console)&&
            installer_native_observation(1,0)==0&&installer_native_observation(0,1)==0;
        const char *reply=ready?"{\"ready\":true}":"{\"ready\":false}";
        respond(fd,200,"OK","application/json; charset=utf-8",reply,strlen(reply));
    } else if (strcmp(method,"GET")==0 && (strcmp(path,"/api/rfid/lifecycle/restore-readiness")==0||
               strcmp(path,"/api/rfid/lifecycle/host-restore-readiness")==0)) {
        int require_canvas=strcmp(path,"/api/rfid/lifecycle/host-restore-readiness")==0;
        int ready=maintenance_barrier_active()&&rn_restore_available(console)&&
            (!require_canvas||installer_native_observation(1, 0)==0)&&installer_native_observation(0, 1)==0;
        const char *reply=ready?"{\"ready\":true}":"{\"ready\":false}";
        respond(fd,200,"OK","application/json; charset=utf-8",reply,strlen(reply));
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/rfid/lifecycle/canvas-observation")==0) {
        canvas_lifecycle_observation_response(fd,mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/canvas")==0) {
        mqtt->canvas_watch_until=time(NULL)+15;
        canvas_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/canvas/refresh")==0) {
        canvas_refresh_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/canvas/auto-refill")==0) {
        canvas_auto_refill_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/runout")==0) {
        runout_response(fd,mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/runout/continue")==0) {
        runout_continue_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/runout/match-material")==0) {
        runout_setting_response(fd,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/canvas/unload")==0) {
        canvas_unload_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/canvas/unload")==0) {
        canvas_unload_save_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/canvas/unload/restart")==0) {
        canvas_unload_restart_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/history")==0) {
        history_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/history/refresh")==0) {
        history_refresh_response(fd, mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/history/delete")==0) {
        history_delete_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/history/timelapse")==0) {
        timelapse_generate_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/history/timelapse")==0) {
        return timelapse_download_start(fd,mqtt,query);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/material-presets")==0) {
        presets_get_response(fd);
    } else if (strcmp(method,"PUT")==0 && strcmp(path,"/api/material-presets")==0) {
        presets_put_response(fd,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/preferences")==0) {
        preferences_get_response(fd);
    } else if (strcmp(method,"PUT")==0 && strcmp(path,"/api/preferences")==0) {
        preferences_put_response(fd,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/gcode-files")==0) {
        gcode_files_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/gcode-files/page")==0) {
        gcode_page_response(fd,query);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/gcode-files/download")==0) {
        return gcode_download_start(fd,query);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/gcode-files/layer-path")==0) {
        if(layer_path_guard(fd,mqtt,query))return 0;
        return gcode_layer_path_begin(fd,query,gcode_read_hold_now(mqtt,console));
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/gcode-files/object-preview")==0) {
        if(object_preview_guard(fd,mqtt,query))return 0;
        return gcode_object_preview_begin(fd,query,gcode_read_hold_now(mqtt,console));
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/inspect")==0) {
        return analysis_start(fd,0,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/thumbnail")==0) {
        /* Up to 4 MB are read on this thread (#352): not while the printer homes, levels or starts a print. */
        if(gcode_read_hold_now(mqtt,console)){
            gcode_read_count_blocked();
            layer_path_fail(fd,503,"Service Unavailable",GCODE_READ_HELD_ERROR);
        }else gcode_thumbnail_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/metadata")==0) {
        return analysis_start(fd,1,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/delete")==0) {
        gcode_delete_response(fd,request,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/copy")==0) {
        gcode_copy_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/gcode-files/print")==0) {
        queue_item *waiting=queue_find(queue.active_id);
        if(plates_background_active())plates_fail(fd,409,"Plate verification is still running");
        else if(waiting&&!strcmp(waiting->state,"starting"))plates_fail(fd,409,"A queued copy is starting");
        else if(usb_start_active())plates_fail(fd,409,usb_start.internal?"Another print start is still being prepared"
                                                                        :"A USB file is still being copied for another start");
        /* Every dialog start, from USB and from internal memory, is checked on the worker (usb_start_*). */
        else return usb_start_begin(fd,mqtt,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/exclude-objects")==0) {
        exclude_objects_response(fd, mqtt);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/mesh")==0) {
        mesh_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/screws/history")==0) {
        screws_history_get_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/screws/history/clear")==0) {
        screws_history_clear_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/plates")==0) {
        plates_get_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/create")==0) {
        plates_create_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/save")==0) {
        plates_save_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/recapture")==0) {
        plates_recapture_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/edit")==0) {
        plates_edit_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/delete")==0) {
        plates_delete_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/measure")==0) {
        plates_measure_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/measure/edit")==0) {
        plates_measure_edit_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/calibrate")==0) {
        plates_calibrate_response(fd,mqtt,console,body,body_len,request);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/calibrate/cancel")==0) {
        plates_calibrate_cancel_response(fd,mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/measure/delete")==0) {
        plates_measure_delete_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/measures/clear")==0) {
        plates_measures_clear_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/keep")==0) {
        plates_keep_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/nozzle")==0) {
        plates_nozzle_save_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/nozzle/delete")==0) {
        plates_nozzle_delete_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/nozzle/select")==0) {
        plates_nozzle_select_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/mount")==0) {
        plates_mount_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/match")==0) {
        plates_match_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/blends/restart")==0) {
        plates_blends_restart_response(fd,mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/plates/unmount")==0) {
        plates_unmount_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/queue")==0) {
        queue_get_response(fd,mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/add")==0) {
        queue_add_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/start")==0) {
        if(queue_start_response(fd,mqtt,body,body_len))return 1; /* a USB copy holds the socket */
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/remove")==0) {
        queue_remove_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/reorder")==0) {
        queue_reorder_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/copies")==0) {
        queue_copies_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/filament")==0) {
        queue_filament_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/policy")==0) {
        queue_policy_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/clear-done")==0) {
        queue_clear_done_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/hold")==0) {
        queue_hold_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/queue/abandon")==0) {
        queue_abandon_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/spools")==0) {
        spools_get_response(fd,mqtt);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/enable")==0) {
        spools_enable_response(fd,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/save")==0) {
        spools_save_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/delete")==0) {
        spools_delete_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/assign")==0) {
        spools_assign_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/dismiss")==0) {
        spools_dismiss_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spools/adjust")==0) {
        spools_adjust_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman")==0) {
        spoolman_config_response(fd,body,body_len);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/spoolman")==0) {
        spoolman_status_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman/held/send")==0) {
        spoolman_held_send_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman/held/discard")==0) {
        spoolman_held_discard_response(fd,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman/unlink-old")==0) {
        spoolman_unlink_old_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman/keep-old")==0) {
        spoolman_keep_old_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/spoolman/catalog/refresh")==0) {
        spoolman_catalog_refresh_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/spoolman/catalog")==0) {
        spoolman_catalog_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/pid")==0) {
        pid_status_response(fd,console);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/console/monitor/clear")==0) {
        memset(&telemetry.console,0,sizeof(telemetry.console));
        console_monitor_response(fd);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/console/monitor")==0) {
        console_monitor_response(fd);
    } else if (strcmp(method,"GET")==0 && strcmp(path,"/api/console")==0) {
        console_status_response(fd,console,query);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/console/clear")==0) {
        console_clear_response(fd,console);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/console/command")==0) {
        console_command_response(fd,console,mqtt,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/recovery/reboot")==0) {
        recovery_reboot_response(fd,body,body_len);
    } else if (!strcmp(method,"POST")&&!strcmp(path,"/api/filament-source")) {
        filament_source_response(fd,console,mqtt,body,body_len);
    } else if (!strcmp(method,"GET")&&!strcmp(path,"/api/external-filament")) {
        external_filament_response(fd,mqtt);
    } else if (!strcmp(method,"GET")&&!strcmp(path,"/api/rfid")) {
        rfid_status_response(fd,mqtt,console);
    } else if (!strcmp(method,"POST")&&!strcmp(path,"/api/rfid/action")) {
        rfid_action_response(fd,mqtt,console,body,body_len);
    } else if (strcmp(method,"POST")==0 && strcmp(path,"/api/control")==0) {
        control_response(fd,console,mqtt,body,body_len);
    } else if (strcmp(method,"GET")!=0 && strcmp(method,"POST")!=0 && strcmp(method,"PUT")!=0) {
        const char *error="Method not allowed\n";
        respond(fd,405,"Method Not Allowed","text/plain; charset=utf-8",error,strlen(error));
    } else {
        const char *body = "Not found\n";
        respond(fd, 404, "Not Found", "text/plain; charset=utf-8", body, strlen(body));
    }
    return 0;
}

#include "connections/json.h"

static int installer_native_heater_safe(const ng_json *reply,int heater,double limit,int strict){
    double temperature,target;
    return ng_number(reply,heater,"temperature",&temperature)&&temperature>=0&&(strict?temperature<limit:temperature<=limit)&&
        ng_number(reply,heater,"target",&target)&&target==0;
}

static int installer_native_observation(int canvas_only,int canvas_transfer){
    static const char safety[]=
        "{\"id\":1,\"method\":\"objects/query\",\"params\":{\"objects\":{\"print_stats\":[\"state\",\"machine_status\"],"
        "\"extruder\":[\"temperature\",\"target\"],\"heater_bed\":[\"temperature\",\"target\"],"
        "\"motion_report\":[\"live_velocity\"]}}}\003";
    static const char canvas_query[]=
        "{\"id\":1,\"method\":\"objects/query\",\"params\":{\"objects\":{\"canvas_dev\":[\"canvas_lite\"]}}}\003";
    char *body=NULL;size_t length=0;
    ng_json *reply=malloc(sizeof(*reply));
    int status=-1;
    if(reply&&!uds_query_json(canvas_only?canvas_query:safety,&body,&length)&&ng_json_parse(reply,body,length))
        status=ng_member(reply,ng_member(reply,0,"result"),"status");
    int result=3;
    if(status>=0&&canvas_only){
        double connected;
        int canvas=ng_member(reply,ng_member(reply,status,"canvas_dev"),"canvas_lite");
        if(ng_number(reply,canvas,"connected",&connected)&&(connected==0||connected==1))
            result=connected==1?0:2;
    }else if(status>=0){
        double machine,velocity;
        int print=ng_member(reply,status,"print_stats");
        const char *state=ng_string(reply,print,"state");
        if(state&&(!strcmp(state,"standby")||!strcmp(state,"complete")||!strcmp(state,"cancelled"))&&
           ng_number(reply,print,"machine_status",&machine)&&machine==1&&
           ng_number(reply,ng_member(reply,status,"motion_report"),"live_velocity",&velocity)&&fabs(velocity)<=1e-9&&
           installer_native_heater_safe(reply,ng_member(reply,status,"extruder"),50,canvas_transfer)&&
           installer_native_heater_safe(reply,ng_member(reply,status,"heater_bed"),canvas_transfer?40:50,canvas_transfer))result=0;
    }
    free(reply);free(body);object_query_close();
    return result;
}

static int installer_native_status(int canvas_only){return installer_native_observation(canvas_only,0);}

#include "rfid_app_update_boot.h"
int main(int argc, char **argv) {
    if(argc>=2&&(!strcmp(argv[1],"--installer-native-idle")||!strcmp(argv[1],"--installer-native-canvas"))){
        if(argc==4&&!strcmp(argv[2],"--uds-socket"))object_query_path=argv[3];
        else if(argc!=2)return 3;
        int canvas_only=!strcmp(argv[1],"--installer-native-canvas");
        int result=installer_native_status(canvas_only);
        if(!canvas_only&&result)fputs("STOP: native console did not confirm Idle, no motion and cold heaters with zero targets.\n",stderr);
        return result;
    }
    /* The independent panel manager owns panel recovery. RFID recovery
     * belongs to the RFID service and cannot gate panel startup. */
    if(0 && !rfid_app_update_boot()) {
        fputs("RFID app-update recovery incomplete; retain the transaction and installation backup.\n",stderr);
        return 1;
    }
    int port = 8081;
    int panda_port = 7125;
    const char *web_root = "./web";
    const char *uds_path = "/tmp/elegoo_uds";
    int canvas_uds_enabled=0;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) port = atoi(argv[++i]);
        else if (strcmp(argv[i], "--http-host") == 0 && i + 1 < argc) http_host_alias = argv[++i];
        else if (strcmp(argv[i], "--panda-port") == 0 && i + 1 < argc) panda_port = atoi(argv[++i]);
        else if (strcmp(argv[i], "--web-root") == 0 && i + 1 < argc) web_root = argv[++i];
        else if (strcmp(argv[i], "--experimental-canvas-uds") == 0) canvas_uds_enabled=1;
        else if (strcmp(argv[i], "--experiments") == 0 && i + 1 < argc) experiments_path=argv[++i];
        else if (strcmp(argv[i], "--uds-socket") == 0 && i + 1 < argc) uds_path = argv[++i];
        else if (strcmp(argv[i], "--config") == 0 && i + 1 < argc) mqtt_config_path = argv[++i];
        else if (strcmp(argv[i], "--presets") == 0 && i + 1 < argc) material_presets_path = argv[++i];
        else if (strcmp(argv[i], "--updates-root") == 0 && i + 1 < argc) app_update_root = argv[++i];
        else if (strcmp(argv[i], "--update-verifier") == 0 && i + 1 < argc) app_update_verifier = argv[++i];
        else if (strcmp(argv[i], "--update-downloader") == 0 && i + 1 < argc) app_update_downloader = argv[++i];
        else if (strcmp(argv[i], "--update-ca") == 0 && i + 1 < argc) app_update_ca = argv[++i];
        else if (strcmp(argv[i], "--update-runner") == 0 && i + 1 < argc) app_update_runner = argv[++i];
        else if (strcmp(argv[i], "--preferences") == 0 && i + 1 < argc) ui_preferences_path = argv[++i];
        else if (strcmp(argv[i], "--layer-index-dir") == 0 && i + 1 < argc) layer_store_dir = argv[++i];
        else if (strcmp(argv[i], "--plates") == 0 && i + 1 < argc) plates_path = argv[++i];
        else if (strcmp(argv[i], "--screws-history") == 0 && i + 1 < argc) screws_history_path = argv[++i];
        else if (strcmp(argv[i], "--spools") == 0 && i + 1 < argc) spools_path = argv[++i];
        else if (strcmp(argv[i], "--queue") == 0 && i + 1 < argc) queue_path = argv[++i];
        else if (strcmp(argv[i], "--autosave") == 0 && i + 1 < argc) printer_autosave_path = argv[++i];
        else if (strcmp(argv[i], "--gcode-internal") == 0 && i + 1 < argc) gcode_internal_root = argv[++i];
        else if (strcmp(argv[i], "--gcode-usb") == 0 && i + 1 < argc) gcode_usb_root = argv[++i];
        else {
            fprintf(stderr, "Usage: %s [--port 8081] [--web-root ./web] [--config FILE] [--presets FILE] [--preferences FILE] [--plates FILE] [--screws-history FILE] [--spools FILE] [--queue FILE] [--autosave FILE] [--gcode-internal DIR] [--gcode-usb DIR] [--uds-socket PATH]\n", argv[0]);
            return 2;
        }
    }
    if (port < 1024 || port > 65535) {
        fprintf(stderr, "Port must be between 1024 and 65535\n");
        return 2;
    }
    if (panda_port < 0 || panda_port > 65535 || (panda_port > 0 && panda_port < 1024) || panda_port == port) {
        fprintf(stderr, "Invalid Panda port (use 0 to disable, or 1024..65535 different from --port)\n");
        return 2;
    }
    service_http_port = port;
    service_panda_port = panda_port;
    signal(SIGINT, stop_server);
    signal(SIGTERM, stop_server);
    signal(SIGPIPE, SIG_IGN);

    mqtt_client mqtt;
    console_state console;
    console_init(&console,"/tmp/elegoo_uds");
    recovery_console=&console;
    uds_init(&telemetry);
    experiments_load();
    external_feed_load();
    experiments_cli_canvas=canvas_uds_enabled;
    telemetry.canvas_enabled=canvas_uds_enabled||experiments.canvas_uds;
    if(!bk_recover()){fprintf(stderr,"Application restore recovery failed; refusing to load mixed libraries\n");console_destroy(&console);return 1;}
    drying_load();
    nx_load();
    plates_load();
    screws_history_init();
    screws_marker_restore(port);
    if (!plates_available) fprintf(stderr, "Plate library disabled: %s (%s)\n", plates_error, plates_path);
    spools_load();
    queue_load();
    (void)gcode_usb_part_cleanup();
    if (!spools_available) fprintf(stderr, "Spool library disabled: %s (%s)\n", spools_error, spools_path);
    mqtt_init(&mqtt);
    if (mqtt_load_config(&mqtt, mqtt_config_path) != 0) {
        setup_mode = 1;
        fprintf(stderr, "MQTT disabled: missing or incomplete config %s\n", mqtt_config_path);
    }
    else
        (void)mqtt_connect_local(&mqtt);

    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) { perror("socket"); return 1; }
    int reuse = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons((unsigned short)port);
    if (bind(server, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind"); close(server); return 1;
    }
    if (listen(server, 8) < 0) { perror("listen"); close(server); return 1; }
    panda_server panda;
    if (panda_start(&panda, panda_port, port, gcode_internal_root) != 0) {
        perror("panda bridge");
        close(server); mqtt_close(&mqtt); console_destroy(&console);
        return 1;
    }
    printf("CC2 Control " CC2_CONTROL_VERSION " + Panda bridge listening on 0.0.0.0:%d (Panda port %d)\n", port, panda_port);
    fflush(stdout);

    /* Layer maps live next to CC2 Control's other data (the folder of --preferences) unless
     * --layer-index-dir names another one; never next to the G-code. */
    static char layer_store_dir_buffer[PATH_MAX_LOCAL * 2];
    if (!strcmp(layer_store_dir, "./layer-index")) {
        const char *slash = strrchr(ui_preferences_path, '/');
        if (slash && snprintf(layer_store_dir_buffer, sizeof(layer_store_dir_buffer), "%.*s/layer-index",
                              (int)(slash - ui_preferences_path), ui_preferences_path) < (int)sizeof(layer_store_dir_buffer))
            layer_store_dir = layer_store_dir_buffer;
    }
    static int layer_prewarm_done; static time_t layer_started_at; layer_started_at = time(NULL);
    if (layer_store_start() != 0) fprintf(stderr, "Layer maps disabled: cannot start the background builder\n");

    http_pending *pending=calloc(HTTP_PENDING_MAX,sizeof(*pending));
    if(!pending){perror("HTTP receive pool");panda_stop(&panda);close(server);mqtt_close(&mqtt);console_destroy(&console);return 1;}
    for(int i=0;i<HTTP_PENDING_MAX;i++)pending[i].fd=-1;
    while (running) {
        recovery_tick();
        bk_tick();
        mqtt_tick(&mqtt);
        object_query_path = uds_path;
        uds_tick(&telemetry,uds_path);
        uds_motion_light(&telemetry,&mqtt);
        plates_tick(&mqtt);
        plates_calibration_tick(&mqtt,&console);
        drying_tick(&mqtt);
        nx_tick(&mqtt);
        tools_tick(&mqtt);
        rfid_tick(&mqtt,&console);
        rfid_native_tick(&console);
        runout_tick(&mqtt);
        fd_set read_set;
        FD_ZERO(&read_set); FD_SET(server,&read_set);
        int max_fd=server;
        if(mqtt.fd>=0){FD_SET(mqtt.fd,&read_set);if(mqtt.fd>max_fd)max_fd=mqtt.fd;}
        if(telemetry.fd>=0){FD_SET(telemetry.fd,&read_set);if(telemetry.fd>max_fd)max_fd=telemetry.fd;}
        int receiving=0;
        for(int i=0;i<HTTP_PENDING_MAX;i++)if(pending[i].fd>=0){
            FD_SET(pending[i].fd,&read_set);if(pending[i].fd>max_fd)max_fd=pending[i].fd;receiving=1;
        }
        int short_wait=receiving||plates_background_active()||plates_late_active()||drying.exchange.fd>=0||tools.busy||runout.x.fd>=0||
            (nx.exchange.fd>=0&&nx.stage!=NX_RUNNING)||usb_start_active(); /* the calibration's own reply takes up to hours */
        struct timeval wait={short_wait?0:1,short_wait?100000:0};
        int ready=select(max_fd+1,&read_set,NULL,NULL,&wait);
        if(ready<0){if(errno==EINTR)continue;perror("select");break;}
        if(mqtt.fd>=0&&FD_ISSET(mqtt.fd,&read_set)){(void)mqtt_process(&mqtt);active_scan_follow(&mqtt);}
        if(telemetry.fd>=0&&FD_ISSET(telemetry.fd,&read_set))uds_process(&telemetry);
        uds_motion_light(&telemetry,&mqtt);
        quiet_disable_tick(&console);
        idle_motors_tick(&mqtt,&console);
        motor_mode_tick(&mqtt,&console);
        {
            console_snapshot snap;
            console_take_snapshot(&console,&snap);
            int completed=snap.completed,success=snap.success,busy=snap.busy,emergency;unsigned long generation=snap.generation;
            /* a cancel that met a failing line, or whose tail was cut short or refused at a heater line, never switched the
             * heaters off: it is not taken for a clean cancel (control.c) */
            control_screws_note_console_end(snap.completed,snap.cancelled,snap.cancel_tail_failed);
            emergency=atomic_load(&console.emergency_sent);
            time_t tram_now=time(NULL);
            pthread_mutex_lock(&console.lock);
            screws_sample_tick(&mqtt,generation,console.output,console.output_len);
            pthread_mutex_unlock(&console.lock);
            (void)control_screws_tick(&mqtt,completed,success,generation,emergency,tram_now);
            /* Record the measured corners of a session job that just completed (#329). The
             * console output still belongs to that job: nothing new starts within this tick. */
            control_screws_job tram_job;
            if(control_screws_take_finished(&tram_job)){
                int recorded;
                pthread_mutex_lock(&console.lock);
                const screw_ist *sample=screws_sample.gen==generation&&screws_sample.ist.have?&screws_sample.ist:NULL;
                recorded=screw_history_record_ist(&screws_history,&tram_job,console.output,console.output_len,tram_now,sample);
                pthread_mutex_unlock(&console.lock);
                memset(&screws_sample,0,sizeof(screws_sample));
                if(recorded)(void)screws_history_store();
            }
            if(screw_history_tick(&screws_history,control_screws_session_active(),tram_now,control_screws_end_reason()))
                (void)screws_history_store();
            double tram_bed=0;
            int have_tram_bed=uds_value(&telemetry,U_BG,&tram_bed);
            screws_bed_renew_tick(&mqtt,busy,tram_now,send_local_gcode_script,have_tram_bed,tram_bed);
            int have_bed_target=uds_value(&telemetry,U_BG,&tram_bed);
            screws_heaters_off_tick(&mqtt,busy,send_local_gcode_script,have_bed_target,tram_bed);
            screws_marker_sync();
            /* Last: a measurement it starts must not clear the console output of a job recorded above. */
            screws_soak_tick(&mqtt,&console,emergency);
        }
        spools_tick(&mqtt);
        queue_tick(&mqtt);
        usb_start_tick(&mqtt);
        print_watch_tick(&mqtt);
        object_preview_follow(&mqtt,&telemetry);
        gcode_read_follow(&mqtt,&console);
        layer_store_set_idle(gcode_idle_for_mutation(&mqtt) && !atomic_load(&gcode_read_hold) && !usb_start_active());
        if (!layer_prewarm_done && atomic_load(&layer_store_idle) && time(NULL) - layer_started_at >= 60) {
            layer_prewarm_done = 1; /* once, a minute after the start and at the first idle time */
            (void)layer_store_prewarm(gcode_internal_root, LAYER_STORE_PREWARM_MAX);
        }
        struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);
        if (spools_available) spoolman_tick((long long)now.tv_sec * 1000 + now.tv_nsec / 1000000);
        for(int i=0;i<HTTP_PENDING_MAX;i++){
            http_pending *p=&pending[i];if(p->fd<0)continue;
            double age=(double)(now.tv_sec-p->started.tv_sec)+(now.tv_nsec-p->started.tv_nsec)/1e9;
            /* Probe every pending nonblocking socket before expiring it.
             * Readiness is a scheduling hint: an empty/stale select result
             * must not discard bytes that are already queued on the socket. */
            ssize_t n=recv(p->fd,p->request+p->used,REQUEST_MAX-p->used,MSG_DONTWAIT);
            if(n<0&&(errno==EAGAIN||errno==EWOULDBLOCK||errno==EINTR)){
                if(age>=2){close(p->fd);p->fd=-1;}
                continue;
            }
            if(n<=0){close(p->fd);p->fd=-1;continue;}
            p->used+=(size_t)n;p->request[p->used]=0;
            int complete=http_request_complete(p->request,p->used);
            if(!complete){if(age>=2){close(p->fd);p->fd=-1;}continue;}
            int fd=p->fd;p->fd=-1;
            int flags=fcntl(fd,F_GETFL,0);
            if(flags<0||fcntl(fd,F_SETFL,flags&~O_NONBLOCK)<0){close(fd);continue;}
            if(complete<0){
                const char *error="Request body too large\n";
                respond(fd,413,"Payload Too Large","text/plain; charset=utf-8",error,strlen(error));close(fd);
            }else if(!handle_client(fd,p->request,p->used,web_root,&mqtt,&console))close(fd);
        }
        if(first_run_restart_requested){running=0;continue;}
        if(!FD_ISSET(server,&read_set))continue;
        int client = accept(server, NULL, NULL);
        if (client < 0) {
            if (errno == EINTR) continue;
            perror("accept"); break;
        }
        struct timeval timeout;
        timeout.tv_sec = 2;
        timeout.tv_usec = 0;
        (void)setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        (void)setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
        int slot=-1;
        for(int i=0;i<HTTP_PENDING_MAX;i++)if(pending[i].fd<0){slot=i;break;}
        int flags=fcntl(client,F_GETFL,0);
        if(slot<0){
            const char overload[]="HTTP/1.1 503 Service Unavailable\r\nRetry-After: 2\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
            (void)send(client,overload,sizeof(overload)-1,MSG_NOSIGNAL|MSG_DONTWAIT);close(client);continue;
        }
        if(client>=FD_SETSIZE||flags<0||fcntl(client,F_SETFL,flags|O_NONBLOCK)<0){close(client);continue;}
        pending[slot].fd=client;pending[slot].used=0;pending[slot].request[0]=0;
        clock_gettime(CLOCK_MONOTONIC,&pending[slot].started);
        if (first_run_restart_requested) {
            fprintf(stderr, "First-run configuration saved; requesting a clean CC2 Control restart\n");
            running = 0;
        }
    }
    for(int i=0;i<HTTP_PENDING_MAX;i++)if(pending[i].fd>=0)close(pending[i].fd);
    free(pending);
    bk_discard();
    spools_flush();
    object_query_close();
    nt_close(&tools.call);plates_exchange_close(&cell.query);
    uds_close(&telemetry);
    panda_stop(&panda);
    mqtt_close(&mqtt);
    console_destroy(&console);
    close(server);
    return 0;
}
