/* SHA-256 (FIPS 180-4) of an open file, as lowercase hex, for comparing a program on the
 * printer against a known fingerprint. Reads in 64 KiB blocks. */
#ifndef CC2_SHA256_H
#define CC2_SHA256_H

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct { uint32_t h[8]; uint64_t bytes; unsigned char block[64]; size_t used; } sha256_state;

static const uint32_t sha256_k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};

static uint32_t sha256_rotr(uint32_t x, unsigned n) { return (x >> n) | (x << (32 - n)); }

static void sha256_compress(uint32_t h[8], const unsigned char *p) {
    uint32_t w[64], a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
    for (int i = 0; i < 16; i++)
        w[i] = (uint32_t)p[i * 4] << 24 | (uint32_t)p[i * 4 + 1] << 16 | (uint32_t)p[i * 4 + 2] << 8 | p[i * 4 + 3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = sha256_rotr(w[i - 15], 7) ^ sha256_rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = sha256_rotr(w[i - 2], 17) ^ sha256_rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = k + (sha256_rotr(e, 6) ^ sha256_rotr(e, 11) ^ sha256_rotr(e, 25)) + ((e & f) ^ (~e & g)) + sha256_k[i] + w[i];
        uint32_t t2 = (sha256_rotr(a, 2) ^ sha256_rotr(a, 13) ^ sha256_rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
        k = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += k;
}

static void sha256_init(sha256_state *s) {
    static const uint32_t iv[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    memcpy(s->h, iv, sizeof(iv)); s->bytes = 0; s->used = 0;
}

static void sha256_update(sha256_state *s, const unsigned char *data, size_t length) {
    s->bytes += length;
    while (length) {
        size_t n = 64 - s->used < length ? 64 - s->used : length;
        memcpy(s->block + s->used, data, n); s->used += n; data += n; length -= n;
        if (s->used == 64) { sha256_compress(s->h, s->block); s->used = 0; }
    }
}

static void sha256_hex(sha256_state *s, char out[65]) {
    uint64_t bits = s->bytes * 8;
    unsigned char pad = 0x80, zero = 0, length[8];
    sha256_update(s, &pad, 1);
    while (s->used != 56) sha256_update(s, &zero, 1);
    for (int i = 0; i < 8; i++) length[i] = (unsigned char)(bits >> (56 - 8 * i));
    sha256_update(s, length, 8);
    for (int i = 0; i < 8; i++) snprintf(out + i * 8, 9, "%08x", (unsigned)s->h[i]);
}

/* 1 with `out` set, 0 when the file cannot be read completely. The descriptor is left open. */
static int sha256_fd(int fd, char out[65]) {
    unsigned char *buffer = malloc(65536);
    if (!buffer) return 0;
    sha256_state s; sha256_init(&s);
    ssize_t n;
    while ((n = read(fd, buffer, 65536)) != 0) {
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        sha256_update(&s, buffer, (size_t)n);
    }
    free(buffer);
    if (n != 0) return 0;
    sha256_hex(&s, out);
    return 1;
}

#endif
