# Stage 2 + PING + File Manager + Object Exclusion + Camera Fix

Base: File Manager NO-CODE, no changes to src/mqtt.c, print start, Canvas, file operations or upload.

- GET /api/exclude-objects queries Klipper exclude_object via printer UDS. Returns 503 if UDS unavailable; never shows sample objects as real objects.
- POST /api/control with body object:exclude:<name> executes EXCLUDE_OBJECT only while status=Printing and only for a restricted object-name character set. Frontend requests confirmation and disables already excluded objects.
- Object data must be supplied by the active G-code (object labeling/EXCLUDE_OBJECT_DEFINE). No registered objects -> no exclusion possible.
- Camera in Job/Print menu uses object-fit:contain; its frame and dashboard camera are unchanged.
- IMPORTANT: Exclusion is irreversible for the current print. This release is not tested on the target ARM printer; perform read-only GET /api/exclude-objects first and a print start/stop regression test before attempting live object exclusion.
- Without authentication on port 8081, /api/control permits operations from any reachable client: keep the port on a trusted LAN only.
