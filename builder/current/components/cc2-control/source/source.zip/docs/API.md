# CC2 Control Discovery API v1

Canonical endpoint:

    GET /api/v1/system/info

Compatibility alias:

    GET /api/system/capabilities

Purpose: allow local integrations (including future MoonFaker/CentauriPrime support) to detect the community firmware and available CC2 Control facilities without SSH probing or firmware-specific filesystem parsing.

The endpoint is read-only and does not expose the LAN access code, MQTT password, or other credentials.

Example response:

```json
{
  "platform": "cc2-community",
  "implementation": "Neme77/centauri-carbon-2-community",
  "device": "ELEGOO Centauri Carbon 2",
  "community_firmware": "4.2",
  "cc2_control": "1.1.31",
  "api_version": 1,
  "printer_uuid": "...",
  "services": {
    "cc2_control": 8081,
    "moonraker_compat": 7125
  },
  "capabilities": {
    "mqtt": true,
    "camera": true,
    "canvas": true,
    "file_manager": true,
    "gcode_thumbnails": true,
    "object_exclusion": true,
    "gcode_console": true,
    "orca_upload": true,
    "orca_print": true,
    "panda_compat": true,
    "material_presets": true,
    "persistent_ui_preferences": true
  },
  "endpoints": {
    "printer": "/api/printer",
    "health": "/api/health",
    "canvas": "/api/canvas",
    "files": "/api/gcode-files",
    "console": "/api/console",
    "preferences": "/api/preferences",
    "discovery": "/api/v1/system/info"
  },
  "runtime": {
    "mqtt_connected": true,
    "mqtt_registered": true
  }
}
```

## Compatibility contract

- `api_version` is the discovery schema version. New optional fields may be added within v1.
- Existing v1 field meanings should not change incompatibly.
- Breaking schema changes require a new `/api/vN/...` endpoint.
- `services` reports the actual ports selected at CC2 Control startup.
- `printer_uuid` may be empty until printer telemetry has supplied it.

## LAN access-code setup and rotation

- `GET /api/setup` reports credential and MQTT synchronization state.
- `POST /api/setup` accepts the initial LAN access code during first-run setup.
- `POST /api/setup/revalidate` atomically replaces an existing LAN code and restarts only CC2 Control.

## OrcaSlicer Canvas filament synchronization

- `GET /server/info` reports the live CC2 Control MQTT readiness state in Moonraker-compatible form.
- `GET /server/database/item?namespace=lane_data` exposes the cached Canvas trays as read-only AFC lanes for OrcaSlicer's Moonraker printer agent.

No additional polling, process, thread, or MQTT subscription is created by these endpoints.

## Live camera viewer

The web UI shows the camera (`ai_camera` on port 8080) on one CC2 Control page at a time.

- `POST /api/camera/claim` with a text body of 8–40 characters from `0-9`, `a-z` and `-` (the page's random
  viewer id) makes that page the current viewer and returns `{"viewer":"<id>"}`. Like other commands it requires
  `X-CC2-Request: 1`; an invalid id is rejected with 400.
- `GET /api/printer` reports the current viewer as `camera_viewer` (`null` until a page claims the camera; the
  value is kept in memory only).

A page streaming live view stops when `camera_viewer` names another page, and offers to take the camera back. The
camera service itself is unchanged: other clients connected directly to port 8080 are not affected.
