# Stage 2 + CC2 application PING — isolated test

Baseline: CC2 Control Stage 2 backend plus the *tested* isolated Stage 2 screws UI.
Only `src/mqtt.c` and `src/mqtt.h` differ from the original Stage 2 backend;
`web/index.html` is the tested Stage 2 screws interface.

The additional heartbeat publishes `{"type":"PING"}` on
`elegoo/<serial>/<client_id>/api_request` every 10 seconds after client
registration. It is distinct from MQTT PINGREQ and follows the public
ELEGOO elegoo-link CC2 protocol adapter. The experiment does NOT change
registration retries, IDs, the method 1020 print request, Canvas, HTTP,
or G-code functionality. A failed heartbeat publish closes the MQTT
connection using the existing reconnect path.

The SDK also recognises PONG and defines a timeout, but PONG timeout/reconnect
handling is *not* introduced here: isolating heartbeat transmission is the
purpose of this test. `mqtt_connected` does not certify application registration.

Compile from WSL/Linux with ARM toolchain:
`make clean && make && file dist/cc2-control/cc2-control`

Deploy binary and web into a NEW /opt/usr/cc2-stage2-app-ping directory.
Keep existing Stage 2 untouched. Do not change the printer firmware.
First test a normal print; after cancellation and a waiting period longer
than the previous failure interval, repeat without restarting CC2 Control.
Do not infer causality from a single successful print.
