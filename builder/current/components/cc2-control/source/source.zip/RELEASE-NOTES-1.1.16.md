# CC2 Control 1.1.16

## USB print reliability fix

The printer does not reliably start USB files through the public MQTT
`method:1020` request with `storage_media:"u-disk"`. The original touchscreen
uses an additional private preparation/import stage.

CC2 Control now reproduces the effective workflow without depending on that
private interface:

- validates the selected USB path and rejects symbolic links;
- copies the G-code atomically into `/opt/usr/gcode/local`;
- assigns a deterministic `CC2_USB_<hash>_...gcode` name;
- submits the proven `method:1020` request as `storage_media:"local"`;
- supports files in the USB root and in nested directories;
- reports import failures instead of claiming that the print was accepted.

Repeated starts of the same USB path reuse the same imported filename. The
original USB file is never modified or removed.

All 1.1.15 features remain included: stable high-DPI thermal chart, internal
and USB G-code browser, Canvas spool mapping, persistent material presets,
2D/3D bed mesh and protected printer controls.
