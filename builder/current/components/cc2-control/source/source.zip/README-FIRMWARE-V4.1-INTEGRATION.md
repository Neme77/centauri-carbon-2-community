# CC2 Control – firmware community v4.1 integration package

This package combines the validated Console Stage B R4 UI/backend with Discovery API v1 and a firmware-ready filesystem overlay.

## Validated console baseline

R4 preserves the validated behaviour:
- local warning/confirmation unlock, no password/token phrase;
- manual input no longer resets while typing;
- lock/unlock visual state is coherent;
- console blocked during printing;
- G28 allowed before homing;
- G0/G1 require full XYZ homing and protected range validation;
- G90/G91 tracked;
- kinematic bypass commands blocked;
- Klipper remains final authority;
- the internal-light button follows live MQTT telemetry (cyan when on, dimmed when off).
- the English/Italian language selection is persistent on the printer and shared by every client.

## New discovery API

- `GET /api/v1/system/info` – canonical endpoint
- `GET /api/system/capabilities` – compatibility alias

See `API-V1.md`.

## Firmware filesystem layout

Immutable firmware payload:

    /opt/inst/cc2-control/cc2-control
    /opt/inst/cc2-control/web/index.html
    /opt/inst/cc2-control/start.sh
    /opt/inst/cc2-control/defaults/material-presets.json
    /etc/init.d/cc2-control

Persistent writable data:

    /opt/usr/cc2-control/cc2-control.conf
    /opt/usr/cc2-control/material-presets.json
    /opt/usr/cc2-control/ui-preferences.json

The startup script creates `/opt/usr/cc2-control` if needed and seeds default material presets only when the persistent file does not already exist. It deliberately does not overwrite an existing config/preset file during firmware updates.

## Build/integration

1. Cross-compile using the normal CC2 WSL toolchain:

       make clean && make

2. Verify:

       file dist/cc2-control/cc2-control

   Expected: ELF 32-bit LSB ARM EABI5, statically linked, stripped.

3. Copy the resulting ARM binary into:

       firmware-integration/overlay/opt/inst/cc2-control/cc2-control

4. Merge the contents of `firmware-integration/overlay/` into the v4.1 rootfs overlay.

5. Ensure boot enablement for `/etc/init.d/cc2-control` using the same S98/procd integration already used by the community firmware builder.

6. Do not replace `/opt/usr/cc2-control/cc2-control.conf` or an existing `material-presets.json` during an update.

## Post-flash smoke test

    pidof cc2-control
    readlink -f /proc/$(pidof cc2-control)/exe
    wget -qO- http://127.0.0.1:8081/api/health
    wget -qO- http://127.0.0.1:8081/api/v1/system/info

The executable path should be `/opt/inst/cc2-control/cc2-control` in the final firmware build.
