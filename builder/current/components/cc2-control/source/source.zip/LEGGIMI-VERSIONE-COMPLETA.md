# CC2 Control — pacchetto completo: OrcaSlicer, Canvas, Object Exclusion

Questo archivio unisce il **sorgente backend** dell'ultima prova «Carica e stampa» (PING applicativo incluso) con l'**ultima interfaccia approvata** per il popup Canvas nella scheda Dispositivo incorporata di OrcaSlicer, che non richiede refresh manuale. Include Makefile, script di servizio originali, configurazione d'esempio, documentazione e test sorgente.

## Funzioni incluse
- Dashboard CC2 Control, Canvas e popup di selezione della bobina prima dell'avvio della stampa.
- Upload e «Carica e stampa» da OrcaSlicer: l'upload non avvia il lavoro da solo; la richiesta resta in attesa di conferma nell'interfaccia.
- Polling del popup adatto alla pagina incorporata di OrcaSlicer, senza dipendere da `visibilityState`.
- Object Exclusion con nomi sotto la rappresentazione del piatto, testo a capo e area scorrevole; Live View e nomi file adattati.
- PING applicativo, gestione G-code, thumbnail e bridge Panda presenti nel backend di partenza.

## Compilazione
Richiede un ambiente Linux/WSL con toolchain `arm-linux-gnueabihf-gcc` compatibile con TinaLinux. Dalla cartella radice:

    make clean && make
    file dist/cc2-control/cc2-control

Verificare che `file` indichi **ELF 32-bit ARM**, non x86-64, prima di copiare il binario sulla stampante. L'archivio contiene **sorgenti**, non un binario ARM precompilato: l'ultima prova sulla stampante è stata effettuata dall'utente con la stessa combinazione di backend e UI, ma non è stato possibile verificare qui una build ARM né ripetere il test hardware.

## Installazione / configurazione
Eseguire un backup dell'installazione funzionante e testare la build in una directory separata sulla stampante a stampa inattiva. Conservare i file `cc2-control.conf` e `material-presets.json` persistenti della stampante: non sono inclusi nell'archivio e **non vanno sovrascritti** con i file d'esempio. Installare `dist/cc2-control/cc2-control` e `dist/cc2-control/web/index.html` nello stesso percorso di prova. I file `scripts/` sono materiale sorgente di riferimento: `launch.sh` presuppone il percorso di installazione `/opt/usr/cc2-control`, quindi adattare i percorsi prima di abilitare l'avvio automatico.

La porta 8081 espone azioni di upload e gestione file senza autenticazione applicativa: usare soltanto su LAN attendibile; non pubblicarla su Internet.

## Limiti
OrcaSlicer **non passa automaticamente** alla scheda Dispositivo: l'utente la apre manualmente e il popup viene mostrato senza refresh. Non chiamare questa distribuzione un firmware ELEGOO completo: è un pacchetto sorgente del componente CC2 Control, non un'immagine firmware flashabile.
