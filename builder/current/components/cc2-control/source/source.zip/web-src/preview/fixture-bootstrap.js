(() => {
  const state = window.__CC2_PREVIEW = {
    connected: true,
    status: 1,
    reject: false,
    commands: [],
    unload: { configured: 85, override: null, pending: false, restarts: 0, extended: false },
    headLoaded: false, activeTray: -1, canvasFresh: true,
    fans: { part: 0, aux: 0, box: 0 },
    trays: [0, 1, 2, 3].map(i => ({tray_id:i,status:i===1||i===2?1:0,filament_color:['','#66BB6A','#48A7FA','#F5F5F5'][i],filament_name:['','PETG','PETG','PLA'][i],filament_type:['','PETG','PETG','PLA'][i]})),
    preferences: { language: 'it', theme: 'dark', ...JSON.parse(localStorage.getItem('cc2-fixture-preferences') || '{}') },
  }
  const printer = () => ({
    connected: state.connected, messages: 42, last_message_age: state.connected ? 0 : 60,
    extruder: { temperature: 27.4, target: 0 }, heater_bed: { temperature: 24.1, target: 0 },
    chamber: { temperature: 25 },
    fans: Object.fromEntries(Object.entries(state.fans).map(([key, value]) => [key, value * 2.55])),
    machine: { status: state.status, status_name: state.status === 2 ? 'Printing' : 'Idle', sub_status: 0, reason: 0, progress: 0 },
    print: { enabled: false, filename: '', state: '', current_layer: 0, total_layers: 0, duration: 0, remaining: 0 },
    motion: { x: 52.5, y: 264, z: 4.97, speed: 1500, speed_mode: 1, homed_axes: '' },
    tuning: { speed_percent: 100, flow_percent: 100, live_velocity: 0 },
    z_offset: { value: 0, reference: 0, adjustment: 0, pending: false, timed_out: false },
    recovery: { available: false, reboot_pending: false, error: 'none' },
    hardware: { camera: true, usb: true, light: 1, filament_detection: true, filament_detected: false },
    spools: { enabled: Boolean(state.spoolLibrary?.enabled), revision: state.spoolLibrary?.revision || 1, questions: [] },
    printer_report: null, printer_error: null, camera_viewer: null,
  })
  const reply = (data, status = 200) => Promise.resolve(new Response(JSON.stringify(data), {
    status, headers: { 'Content-Type': 'application/json' },
  }))
  window.fetch = (input, options = {}) => {
    const raw = typeof input === 'string' ? input : input.url
    let path = new URL(raw, location.href).pathname
    const api = path.indexOf('/api/')
    if (api >= 0) path = path.slice(api)
    const locale = path.match(/\/(?:locales|i18n)\/(\w+)\.json$/)
    if (locale) return reply(window.__CC2_PREVIEW_LOCALES[locale[1]] || window.__CC2_PREVIEW_LOCALES.en)
    if (path === '/api/preferences') {
      if (options.method === 'PUT') {
        Object.assign(state.preferences, JSON.parse(options.body))
        localStorage.setItem('cc2-fixture-preferences', JSON.stringify(state.preferences))
      }
      return reply(state.preferences)
    }
    if (path === '/api/camera/claim') return reply({viewer:String(options.body)})
    if (path === '/api/canvas') return reply({available:true,auto_refill:false,slots:state.trays.map(t=>{
        const fresh=state.connected&&state.canvasFresh&&state.canvasConnected!==false
        const changing=(state.headLoaded&&state.activeTray===-1)||(!state.headLoaded&&state.activeTray!==-1)
        const kind=!fresh?'unknown':changing?'transition':t.status===0?'empty':t.status===2&&state.activeTray===t.tray_id&&state.headLoaded?'loaded':t.status===1&&state.activeTray!==t.tray_id?'present':'transition'
        const busy=state.status!==1
        const load=fresh&&!busy&&kind==='present'&&!state.headLoaded&&state.activeTray===-1
        const unload=fresh&&!busy&&kind==='loaded'
        const transitionReason=state.headLoaded&&state.activeTray===-1?'unassigned_head':'transition'
        const recovery_load=fresh&&!busy&&state.headLoaded&&state.activeTray===-1&&t.status===1&&state.trays.length===4&&state.trays.every(t=>t.status===0||t.status===1)
        return {slot:t.tray_id,state:kind,load,unload,recovery_load,reason_load:!fresh?'unavailable':busy?'busy':kind==='empty'?'empty':kind==='loaded'?'already_loaded':kind==='transition'?transitionReason:load?'none':'head_occupied',reason_unload:!fresh?'unavailable':busy?'busy':kind==='empty'?'empty':kind==='transition'?transitionReason:unload?'none':'not_loaded'}
      }),telemetry:{result:{canvas_info:{canvas_list:[{canvas_id:0,connected:state.canvasConnected===false?0:1,tray_list:state.trays}]}}}})
    if (path === '/api/canvas/unload/restart' && options.method === 'POST') {
      if (String(options.body) !== 'RESTART') return reply({ ok: false, error: 'Explicit restart confirmation required' }, 400)
      if (!state.unload.pending || state.status !== 1) return reply({ ok: false, error: 'The printer must be idle' }, 409)
      state.unload.restarts++
      return reply({ ok: true, restarting: true }, 202)
    }
    if (path === '/api/canvas/unload') {
      const u = state.unload
      const max = u.extended ? 1000 : 350
      if (options.method === 'POST') {
        const text = String(options.body).trim()
        const value = text === 'default' ? null : /^\d{2,4}$/.test(text) ? Number(text) : NaN
        if (value !== null && !(value >= 60 && value <= max)) return reply({ ok: false, error: `Enter a whole number of millimetres from 60 to ${max}` }, 400)
        if (state.status !== 1) return reply({ ok: false, error: 'The printer must be idle' }, 409)
        if (value !== u.override) Object.assign(u, { override: value, pending: true })
      }
      return reply({ ok: true, editable: true, min: 60, max, extended: u.extended, configured: u.configured, override: u.override, pending_restart: u.pending, restart: 'none' })
    }
    if (path === '/api/spools') return reply(state.spoolLibrary || {})
    // The legacy file preview has no native network manager. Return its real
    // unavailable shape rather than the generic empty-object fallback.
    if (path === '/api/network') return reply({ available: false, fresh: false, refreshing: false, age_ms: null, snapshot: null })
    if (path === '/api/network/manager') {
      const ip = { enabled: false, method: 'dhcp', ip: '', prefix: 0, gateway: '', dns1: '', dns2: '', ssid: '' }
      const config = { schema: 1, ethernet_support: false, selected: 'wifi', wifi: { ...ip, enabled: true }, ethernet: { ...ip } }
      const actual = { known: false, method: 'unknown', prefix: 0, gateway: '', dns1: '', dns2: '' }
      return reply({ schema: 1, installed: false, state_valid: false, configured: false, ready: false, busy: false, last_exit: -1, phase: 'idle', config, saved: config, actual: { wifi: actual, ethernet: actual }, last_error: '', pending: null, networks: null, diagnostic: '', automatic_selection: false, temporary: false })
    }
    if (path === '/api/gcode-files/layer-path') {
      const u = new URL(raw, location.href)
      const file = u.searchParams.get('file') || ''
      const layer = Number(u.searchParams.get('layer'))
      const storage = u.searchParams.get('storage') || 'internal'
      if (!file || !Number.isInteger(layer) || layer < 1) return reply({ error: 'invalid layer path request' }, 400)
      if (layer > 10000) return reply({ error: 'layer not found' }, 404)
      const r2 = n => Math.round(n * 100) / 100
      const oval = (cx, cy, rx, ry, n = 32) => Array.from({length: n + 1}, (_, i) => {
        const a = (i / n) * Math.PI * 2
        return [r2(cx + rx * Math.cos(a)), r2(cy + ry * Math.sin(a))]
      })
      const island = (cx, cy, rx, ry, infill) => {
        const paths = [oval(cx, cy, rx, ry), oval(cx, cy, rx * 0.78, ry * 0.78)]
        if (!infill) return paths
        const irx = rx * 0.7, iry = ry * 0.7
        const inside = (x, y) => ((x - cx) / irx) ** 2 + ((y - cy) / iry) ** 2 <= 1
        for (let offset = -irx * 1.7; offset <= irx * 1.7; offset += 4.2) {
          const pts = []
          for (let s = -1; s <= 1.001; s += 0.045) {
            const x = cx + offset + s * irx, y = cy + s * iry
            if (inside(x, y)) pts.push([r2(x), r2(y)])
          }
          if (pts.length >= 2) paths.push(pts)
        }
        return paths
      }
      const grow = layer % 2 === 0 ? 2.4 : 0
      const paths = [
        ...island(128, 120, 30 + grow, 24 + grow, true),
        ...island(70, 192, 20 + grow * 0.7, 17 + grow * 0.7, true),
        ...island(190, 190, 18 + grow * 0.7, 16 + grow * 0.7, true),
      ]
      if (layer <= 8) paths.push(...island(190, 48, 16, 11, false))
      return reply({
        storage, file, layer, total_layers: 227, z: Math.round(layer * 0.2 * 100) / 100,
        paths, point_count: paths.reduce((n, p) => n + p.length, 0), truncated: false,
      })
    }
    if (path === '/api/printer') return reply(printer())
    if (path === '/api/health') return reply({ service: 'cc2-control', version: '1.2.3', mqtt_connected: state.connected })
    if (path === '/api/setup') return reply({ required: false, configured: true, mqtt_connected: state.connected })
    if (path === '/api/console') return reply({ busy: false, command: '', output: '', completed: false, success: false })
    if (path === '/api/pid') return reply({ busy: false, ready: false, failed: false, heater: '', kp: null, ki: null, kd: null })
    if (path === '/api/material-presets') {
      if (options.method === 'PUT') {
        state.presets = JSON.parse(options.body)
        localStorage.setItem('cc2-fixture-presets', options.body)
        return reply({saved:true})
      }
      return reply(state.presets || JSON.parse(localStorage.getItem('cc2-fixture-presets') || 'null') || [
      { name: 'PLA', nozzle: 200, bed: 60 }, { name: 'PETG', nozzle: 240, bed: 70 },
      { name: 'ABS', nozzle: 250, bed: 100 }, { name: 'ASA', nozzle: 255, bed: 100 },
      { name: 'TPU', nozzle: 220, bed: 50 }, { name: 'PA-CF', nozzle: 285, bed: 100 },
      ])
    }
    if (path === '/api/control' && options.method === 'POST') {
      const action = String(options.body)
      state.commands.push(action)
      if (state.reject || !state.connected) return reply({ error: 'Comando rifiutato nella simulazione' }, 409)
      const recovery=action.match(/^canvas:recover-load:([0-3])$/)
      if(recovery&&state.status===1&&state.canvasFresh&&state.headLoaded&&state.activeTray===-1&&state.trays[Number(recovery[1])]?.status===1&&state.trays.length===4&&state.trays.every(t=>t.status===0||t.status===1))return reply({accepted:true,simulated:true})
      if (action === 'canvas:reset-all') {
        if (state.status !== 1) return reply({error:'Stampante occupata'},409)
        state.trays.forEach(t=>Object.assign(t,{filament_color:'',filament_name:'',filament_type:'',min_nozzle_temp:0,max_nozzle_temp:0}))
        return reply({accepted:true,simulated:true})
      }
      const fan = action.match(/^fan:(part|aux|box):(\d+)$/)
      if (fan && Number(fan[2]) <= 100) {
        state.fans[fan[1]] = Number(fan[2])
        return reply({ accepted: true, simulated: true })
      }
      return reply({ error: 'Questa anteprima permette solo di provare le ventole' }, 403)
    }
    // The plate library of the Mesh tab (it holds the load cell block): not available here, but with its lists.
    if (path === '/api/plates') return reply({ available: false, plates: [], nozzles: [], current: '', pending: '', nozzle: '', error: 'unavailable' })
    return reply({})
  }
  if (!location.hash) location.hash = '#control'
  document.addEventListener('DOMContentLoaded', () => {
    const badge = document.createElement('div')
    badge.textContent = 'ANTEPRIMA · dati simulati · Invio applica la percentuale'
    badge.style.cssText = 'position:fixed;bottom:12px;left:50%;transform:translateX(-50%);z-index:1000;max-width:calc(100% - 24px);padding:8px 14px;border:1px solid #17445b;border-radius:8px;background:#052131;color:#8daebf;font:12px system-ui;text-align:center;pointer-events:none'
    document.body.append(badge)
  })
})()
