import assert from 'node:assert/strict'
import { createServer } from 'vite'
import { chromium } from 'playwright'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const root = fileURLToPath(new URL('..', import.meta.url))
const server = await createServer({ root, configFile: path.join(root, 'vite.config.ts'), mode: 'demo', server: { port: 0, host: '127.0.0.1' } })
let browser
try {
  await server.listen()
  const origin = server.resolvedUrls.local[0]
  browser = await chromium.launch({ headless: true, ...(process.env.CC2_BROWSER_PATH ? { executablePath: process.env.CC2_BROWSER_PATH } : {}) })
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  await page.goto(origin + '#settings/appearance')
  const theme = page.locator('select').filter({ has: page.locator('option[value="obsidian"]') })
  await theme.waitFor()
  await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark')
  assert.deepEqual(await theme.locator('option').evaluateAll(options => options.map(option => option.value)), ['auto', 'dark', 'light', 'dracula', 'nord', 'monokai', 'solarized-light', 'obsidian', 'aurora', 'klipper', 'dune', 'swamp', 'klipperscreen', 'ember', 'rose'])
  const saved = page.waitForResponse(r => r.url().endsWith('/api/preferences') && r.request().method() === 'PUT')
  const appearanceSaved = page.waitForResponse(r => r.url().endsWith('/api/appearance') && r.request().method() === 'PUT')
  await theme.selectOption('obsidian')
  assert.equal((await saved).ok(), true)
  assert.equal((await appearanceSaved).ok(), true)
  await page.reload()
  await page.waitForFunction(() => document.documentElement.dataset.theme === 'obsidian')
  assert.equal(await theme.inputValue(), 'obsidian')
  const fresh = await browser.newContext()
  const other = await fresh.newPage()
  await other.goto(origin + '#settings/appearance')
  await other.waitForFunction(() => document.documentElement.dataset.theme === 'obsidian')
  await fresh.close()
  const box = () => page.evaluate(() => {
    const content = document.querySelector('.cc2-page-content').getBoundingClientRect()
    const side = document.querySelector('#cc2-navigation').getBoundingClientRect()
    const main = document.querySelector('main').getBoundingClientRect()
    const camera = document.querySelector('.cc2-camera-frame')?.getBoundingClientRect()
    return { width: content.width, centre: content.x + content.width / 2, expectedCentre: (side.right + main.right) / 2, camera: camera?.width, overflow: document.documentElement.scrollWidth > innerWidth }
  })
  for (const width of [1024, 1440, 1920, 2560]) {
    await page.setViewportSize({ width, height: 1100 })
    for (const route of ['dashboard', 'control', 'canvas', 'settings/appearance']) {
      await page.goto(origin + '#' + route)
      await page.waitForTimeout(350)
      const before = await box()
      await page.getByTitle('Collapse menu', { exact: true }).click()
      await page.waitForTimeout(350)
      const after = await box()
      assert(Math.abs(before.width - after.width) < 1, `${route} at ${width}: content changed width: ${before.width} -> ${after.width}`)
      if (before.camera) assert(Math.abs(before.camera - after.camera) < 1, 'camera changed width')
      assert(Math.abs(after.centre - after.expectedCentre) < 1, `${route}: content not centred`)
      assert.equal(after.overflow, false)
      await page.getByTitle('Expand menu', { exact: true }).click()
      await page.waitForTimeout(350)
    }
  }
  for (const width of [390, 768]) {
    await page.setViewportSize({ width, height: 1100 })
    await page.goto(origin + '#dashboard')
    await page.waitForTimeout(350)
    const before = await box()
    await page.locator('#cc2-menu-toggle').click()
    await page.waitForTimeout(200)
    assert(Math.abs((await box()).width - before.width) < 1, 'drawer resized mobile page')
    await page.keyboard.press('Escape')
    assert.equal((await box()).overflow, false)
  }
  // Ember is a dark palette and Rose a light one: the stored mode, the form
  // control colour scheme and the CSS block must agree, also after a reload.
  const scheme = { light: 'light', dark: 'dark', obsidian: 'dark', aurora: 'light', ember: 'dark', rose: 'light' }
  for (const id of ['light', 'dark', 'obsidian', 'aurora', 'ember', 'rose']) {
    await page.goto(origin + '#settings/appearance')
    const saved = page.waitForResponse(r => r.url().endsWith('/api/preferences') && r.request().method() === 'PUT')
    const appearanceSaved = page.waitForResponse(r => r.url().endsWith('/api/appearance') && r.request().method() === 'PUT')
    await theme.selectOption(id)
    assert.equal((await saved).ok(), true, `${id}: preferences saved`)
    const appearanceResponse = await appearanceSaved
    assert.equal(appearanceResponse.ok(), true, `${id}: appearance saved`)
    const payload = JSON.parse(appearanceResponse.request().postData())
    assert.equal(payload.dashboard.theme, id, `${id}: appearance document theme`)
    assert.equal(payload.dashboard.mode, scheme[id], `${id}: appearance mode`)
    assert.equal(await theme.inputValue(), id)
    await page.waitForFunction(value => document.documentElement.dataset.theme === value, id)
    assert.equal(await page.evaluate(() => document.documentElement.style.colorScheme), scheme[id], `${id}: colour scheme`)
    assert.equal((await (await page.request.get(origin + 'api/preferences')).json()).theme, id, `${id}: server preference`)
    await page.reload()
    await page.waitForFunction(value => document.documentElement.dataset.theme === value, id)
    assert.equal(await theme.inputValue(), id, `${id}: selection survives reload`)
    assert.equal(await page.evaluate(() => document.documentElement.style.colorScheme), scheme[id], `${id}: colour scheme survives reload`)
    const fresh = await browser.newContext()
    try {
      const other = await fresh.newPage()
      await other.goto(origin + '#settings/appearance')
      await other.waitForFunction(value => document.documentElement.dataset.theme === value, id)
      assert.equal(await other.locator('select').filter({ has: other.locator(`option[value="${id}"]`) }).inputValue(), id, `${id}: fresh browser uses saved preference`)
    } finally { await fresh.close() }
  }
  assert.deepEqual(errors, [])
  console.log('PASS: theme selection/server persistence/reload/fresh browser including Ember and Rose, desktop page/camera sizing and centring, mobile drawer')
} finally { await browser?.close(); await server.close() }
