import { useEffect, useRef, useState } from 'preact/hooks'
import { cn } from '@/lib/utils'
import { CanvasIcon } from '@/components/canvas-icon'
import { UpdateNotice } from '@/components/update-notice'
import { HeaderTitle } from '@/components/header-title'
import { PrinterIcon } from '@/components/printer-icon'
import {
  Menu,
  RotateCw,
  Files as FilesIcon,
  Flame,
  Gauge,
  Grid3x3,
  History,
  ListChecks,
  ListOrdered,
  Settings,
  SlidersHorizontal,
  PanelLeftClose,
  PanelLeftOpen,
  Spool,
  SquareTerminal,
  TriangleAlert,
  X,
} from 'lucide-preact'
import { Dot } from '@/components/ui/badge'
import { type Key, t, tpl } from '@/lib/i18n'
import { control, errText, notify, post, toast } from '@/lib/api'
import { ask } from '@/lib/confirm'
import { printerError, printerRequest, statusTitle } from '@/lib/machine'
import { pandabreath, pandabreathName } from '@/lib/pandabreath'
import { openJobs, queue, refreshQueue } from '@/lib/queue'
import { usePoll } from '@/lib/poll'
import {
  consoleStatus,
  refreshPrinter,
  health,
  menu,
  mobileMenu,
  nav,
  printer,
  toggleMenu,
  view,
  type Page,
} from '@/lib/state'

// Same query as the compact layout in index.css.
const COMPACT = '(max-width: 900px) and (orientation: portrait), (max-height: 500px) and (orientation: landscape)'
type NavIcon = typeof Gauge | typeof CanvasIcon
const items: [Page, NavIcon, Key][] = [
  ['dashboard', Gauge, 'app.dashboard'],
  ['control', SlidersHorizontal, 'common.control'],
  ['job', ListChecks, 'common.job'],
  ['files', FilesIcon, 'common.files'],
  ['queue', ListOrdered, 'queue.title'],
  ['history', History, 'common.history'],
  ['bed', Grid3x3, 'common.bed_levelling'],
  ['canvas', CanvasIcon, 'common.canvas'],
  ['spools', Spool, 'spools.title'],
  ['pandabreath', Flame, 'common.pandabreath'],
  ['console', SquareTerminal, 'common.console'],
  ['settings', Settings, 'common.settings'],
]

// Hold for one second to trigger the emergency stop; a plain click only explains how.
const EStop = () => {
  const [holding, setHolding] = useState(false)
  const timer = useRef(0),
    fired = useRef(false)
  const cancel = () => {
    clearTimeout(timer.current)
    timer.current = 0
    setHolding(false)
  }
  const start = (e: Event) => {
    if (e.type === 'keydown' && !['Enter', ' '].includes((e as KeyboardEvent).key)) return
    e.preventDefault()
    if (e.type === 'keydown' && (e as KeyboardEvent).repeat) return
    cancel()
    fired.current = false
    setHolding(true)
    timer.current = window.setTimeout(async () => {
      timer.current = 0
      fired.current = true
      setHolding(false)
      if (await control('system:emergency_stop')) await refreshPrinter()
    }, 1000)
  }
  return (
    <button
      type="button"
      aria-label={t('app.hold_for_emergency_stop')}
      onPointerDown={start}
      onPointerUp={cancel}
      onPointerCancel={cancel}
      onPointerLeave={cancel}
      onKeyDown={start}
      onKeyUp={cancel}
      onBlur={cancel}
      onContextMenu={e => e.preventDefault()}
      onClick={e => {
        e.preventDefault()
        if (!fired.current) notify(t('app.hold_emergency_stop_for_one_second'))
      }}
      class="cc2-emergency-stop relative flex h-11 shrink-0 touch-none select-none items-center justify-center overflow-hidden rounded-md border border-red bg-red/10 px-2 font-bold text-red md:px-3"
    >
      <i
        class={cn(
          'absolute inset-y-0 left-0 bg-red/30',
          holding ? 'w-full transition-[width] duration-1000 ease-linear' : 'w-0'
        )}
      />
      <span class="relative flex items-center gap-1.5">
        <TriangleAlert size={20} strokeWidth={1} />
        <span class="cc2-header-action-label hidden md:inline">{t('app.emergency_stop')}</span>
      </span>
    </button>
  )
}

const RestartPrinter = () => {
  const { data, ok } = printer.use()
  const [busy, setBusy] = useState(false)
  const available = ok && data?.recovery?.available && !data?.recovery?.reboot_pending && !busy
  const restart = async () => {
    if (!available || !(await ask(t('recovery.confirm'), true))) return
    setBusy(true)
    try {
      await post('/api/recovery/reboot', 'REBOOT_AFTER_EMERGENCY')
      notify(t('recovery.restarting'))
      await refreshPrinter()
    } catch (e) {
      notify(tpl('common.rejected_error', { error: errText(e) }), 'error')
    } finally {
      setBusy(false)
    }
  }
  return (
    <button
      type="button"
      disabled={!available}
      onClick={restart}
      title={t(available ? 'recovery.restart' : 'recovery.requires_emergency')}
      aria-label={t('recovery.restart')}
      class="flex h-11 shrink-0 items-center justify-center gap-2 rounded-md border border-edge px-3 disabled:opacity-40 md:px-4"
    >
      <RotateCw size={20} strokeWidth={1} />
      <span class="cc2-header-action-label hidden md:inline">{t('recovery.restart')}</span>
    </button>
  )
}

export const Sidebar = () => {
  const { page } = nav.use()
  const h = health.use().data
  // Trays whose new filament still waits for "which spool is this?".
  const questions = printer.use().data?.spools?.questions?.length || 0
  // Jobs waiting in the print queue; the count is refreshed slowly here and fast on the Queue page.
  usePoll(refreshQueue, 20000)
  const queued = openJobs(queue.use().data).length
  const { collapsed } = menu.use()
  const { open } = mobileMenu.use()
  const pb = pandabreath.use() // optional page, off unless turned on; named after the firmware
  const aside = useRef<HTMLElement>(null)
  useEffect(() => {
    if (!open) {
      if (aside.current?.contains(document.activeElement)) document.getElementById('cc2-menu-toggle')?.focus()
      return
    }
    const media = matchMedia(COMPACT)
    const close = () => mobileMenu.set({ open: false })
    const closeOnEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close()
      if (e.key === 'Tab') {
        const toggle = document.getElementById('cc2-menu-toggle')
        const links = Array.from(aside.current?.querySelectorAll<HTMLAnchorElement>('a') || [])
        const targets = [toggle, ...links].filter((el): el is HTMLElement => Boolean(el?.getClientRects().length))
        const current = targets.indexOf(document.activeElement as HTMLElement)
        if (targets.length && (current < 0 || (e.shiftKey ? current === 0 : current === targets.length - 1))) {
          e.preventDefault()
          targets[e.shiftKey ? targets.length - 1 : 0].focus()
        }
      }
    }
    const changed = () => {
      if (!media.matches) close()
    }
    const oldOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    aside.current?.querySelector<HTMLAnchorElement>('a')?.focus()
    document.addEventListener('keydown', closeOnEscape)
    media.addEventListener('change', changed)
    return () => {
      document.body.style.overflow = oldOverflow
      document.removeEventListener('keydown', closeOnEscape)
      media.removeEventListener('change', changed)
    }
  }, [open])
  return (
    <>
      {open && (
        <button
          type="button"
          class="cc2-menu-backdrop"
          aria-label={t('app.collapse_menu')}
          onClick={() => mobileMenu.set({ open: false })}
        />
      )}

      <aside
        id="cc2-navigation"
        aria-label={t('app.sidebar')}
        ref={aside}
        class={cn(
          'cc2-sidebar',
          open && 'cc2-sidebar-open',
          'fixed bottom-0 left-0 top-17 z-20 flex w-15.5 flex-col border-r border-edge bg-panel transition-[width]',
          !collapsed && 'md:w-52'
        )}
      >
        <nav
          class="mt-2 grid min-h-0 flex-1 content-start gap-0.5 overflow-y-auto overflow-x-hidden"
          aria-label={t('app.main_navigation')}
        >
          {items
            .filter(([p]) => p !== 'pandabreath' || pb.enabled)
            .map(([p, Glyph, item]) => {
              const label = p === 'pandabreath' ? pandabreathName(pb) : item
              return (
                <a
                  key={p}
                  href={`#${p}`}
                  onClick={() => mobileMenu.set({ open: false })}
                  aria-current={page === p ? 'page' : undefined}
                  title={t(label)}
                  class={cn(
                    'relative flex h-13 items-center gap-3.5 border-l-4 border-transparent pl-[14px] hover:bg-field', // same icon x collapsed or not
                    page === p && 'border-cyan bg-field text-cyan'
                  )}
                >
                  <Glyph size={24} strokeWidth={1} class="shrink-0" />
                  {p === 'spools' && questions > 0 && (
                    <i
                      class="absolute left-9 top-2.5 size-2.5 rounded-full bg-amber"
                      title={t('spools.question_tag')}
                      aria-hidden="true"
                    />
                  )}
                  {p === 'queue' && queued > 0 && (
                    <span
                      data-queue-count
                      class="absolute left-8 top-2 min-w-4 rounded-full bg-cyan px-1 text-center text-xs font-semibold leading-4 text-ink"
                      aria-hidden="true"
                    >
                      {queued}
                    </span>
                  )}
                  {/* Always rendered: the sidebar width transition clips it progressively; invisible only starts once collapsed. */}
                  <span
                    class={cn('hidden whitespace-nowrap transition-[visibility] md:inline', collapsed && 'invisible')}
                  >
                    {t(label)}
                  </span>
                </a>
              )
            })}
        </nav>
        <div class="mt-auto hidden shrink-0 border-t border-edge md:block">
          <button
            type="button"
            onClick={toggleMenu}
            aria-expanded={!collapsed}
            title={t(collapsed ? 'app.expand_menu' : 'app.collapse_menu')}
            class="flex h-11 w-full items-center gap-3.5 overflow-hidden pl-[19px] text-muted hover:bg-field hover:text-fg"
          >
            {collapsed ? (
              <PanelLeftOpen size={22} strokeWidth={1} class="shrink-0" />
            ) : (
              <PanelLeftClose size={22} strokeWidth={1} class="shrink-0" />
            )}
            <span class={cn('whitespace-nowrap transition-[visibility]', collapsed && 'invisible')}>
              {t('app.collapse_menu')}
            </span>
          </button>
          {/* Always rendered so the button above keeps the same y when the menu collapses. */}
          <div
            class={cn(
              'h-7 overflow-hidden whitespace-nowrap px-5 pb-3 text-center text-xs text-muted transition-[visibility]',
              collapsed && 'invisible'
            )}
          >
            {t('app.version')} <b class="font-medium tabular-nums text-fg">{h ? `${h.version}` : '—'}</b>
          </div>
        </div>
      </aside>
    </>
  )
}

export const Topbar = () => {
  const { open } = mobileMenu.use()
  const { data: d, ok } = printer.use()
  const v = view(d)
  consoleStatus.use()
  const title = statusTitle(v.state)
  // The state under "CC2" is only shown while the link is healthy; otherwise it could be stale or unknown.
  // One link indicator: CC2 Control reachable → MQTT session up → printer messages recent (3 missed 10 s heartbeats = stale).
  const link: ['green' | 'amber' | 'red', Key] = !ok
    ? ['red', 'app.printer_unreachable']
    : !d
      ? ['amber', 'app.connecting_to_the_printer']
      : !d.connected
        ? ['red', 'app.reconnecting_to_the_printer']
        : d.last_message_age < 0 || d.last_message_age > 30
          ? ['amber', 'app.waiting_for_the_printer']
          : ['green', 'app.printer_connected']
  return (
    <header class="cc2-topbar fixed inset-x-0 top-0 z-30 flex h-17 items-center justify-between gap-4 border-b border-edge bg-panel px-4 md:px-5 xl:pl-2">
      <button
        type="button"
        id="cc2-menu-toggle"
        class="cc2-mobile-menu hidden h-11 w-11 shrink-0 items-center justify-center rounded-md border border-edge"
        aria-label={t(open ? 'app.collapse_menu' : 'app.expand_menu')}
        aria-expanded={open}
        aria-controls="cc2-navigation"
        onClick={() => mobileMenu.set({ open: !open })}
      >
        <Menu size={22} strokeWidth={1} />
      </button>
      <HeaderTitle />
      <div class="cc2-header-actions flex shrink-0 items-center gap-2">
        <div class="cc2-header-status flex h-11 items-center gap-2 rounded-md border border-edge px-3">
          <PrinterIcon class="hidden size-6 sm:block" />
          <div>
            {link[0] === 'green' ? (
              <>
                {title.text}
                {!title.replaced && v.detail && <span class="hidden md:inline"> · {v.detail}</span>}
                {v.active ? ` · ${Math.round(v.progress)}%` : ''}
              </>
            ) : (
              '—'
            )}
          </div>
        </div>
        <div class="hidden h-11 items-center gap-2 rounded-md border border-edge px-3 sm:flex">
          <Dot c={link[0]} />
          {t(link[1])}
        </div>
        <UpdateNotice />
        <EStop />
        <RestartPrinter />
      </div>
      {v.active && (
        <div
          class="absolute inset-x-0 bottom-0 h-1 bg-edge"
          role="progressbar"
          aria-label={t('app.print_progress')}
          aria-valuenow={Math.round(v.progress)}
        >
          <i class="block h-full bg-cyan transition-[width]" style={{ width: `${v.progress}%` }} />
        </div>
      )}
    </header>
  )
}

// Keeps the browser tab title informative: current page, and print progress while a job runs.
export const TitleSync = () => {
  const { page } = nav.use()
  const v = view(printer.use().data)
  const label = items.find(i => i[0] === page)?.[2] ?? 'app.dashboard'
  document.title = `${v.active ? `${Math.round(v.progress)}% · ` : ''}${t(label)} · Centauri Carbon 2`
  return null
}

// The printer answers CC2 Control's MQTT requests after the HTTP request has returned; each new refusal
// is shown once. An old refusal seen when the page opens is not news.
export const RefusalWatcher = () => {
  const refusal = printer.use().data?.printer_error
  const seen = useRef<number | null>(null)
  useEffect(() => {
    if (!refusal || refusal.sequence === seen.current) return
    const first = seen.current === null
    seen.current = refusal.sequence
    if (first && Number(refusal.age) > 15) return
    notify(
      tpl('printer.refused', {
        request: printerRequest(Number(refusal.method)),
        error: printerError(Number(refusal.code)),
        code: Number(refusal.code),
      }),
      'error'
    )
  }, [refusal?.sequence])
  return null
}

export const Toast = () => {
  const { text, n, tone } = toast.use()
  const [show, setShow] = useState(false)
  useEffect(() => {
    if (!n || !text) {
      setShow(false)
      return
    }
    setShow(true)
    const id = setTimeout(() => setShow(false), tone === 'error' ? 7000 : 3600)
    return () => clearTimeout(id)
  }, [n, text, tone])
  return show && text ? (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      class={cn(
        'fixed bottom-6 left-1/2 z-[70] flex max-w-[90%] -translate-x-1/2 items-center gap-3 rounded-lg border bg-panel py-3 pl-5 pr-3 shadow-2xl',
        tone === 'error' ? 'border-red text-red' : 'border-cyan'
      )}
    >
      <span>{text}</span>
      <button
        type="button"
        onClick={() => setShow(false)}
        aria-label={t('app.dismiss')}
        title={t('app.dismiss')}
        class="rounded p-1 hover:bg-field"
      >
        <X size={16} strokeWidth={1} />
      </button>
    </div>
  ) : null
}

// No extra poll: retain the latest native event in the existing printer response.
export const PrinterReport = () => {
  const { data, ok } = printer.use()
  const report = data?.printer_report
  const storageKey = 'cc2-printer-report-seen'
  const eventId = report?.event_id ?? (report ? String(report.sequence) : '')
  const [dismissed, setDismissed] = useState<string | null>(() => {
    try {
      return localStorage.getItem(storageKey)
    } catch {
      return null
    }
  })
  useEffect(() => {
    if (!report || (report.level !== 1 && report.level !== 2)) return
    try {
      localStorage.setItem(storageKey, eventId)
    } catch {
      // Storage restrictions must not prevent showing printer errors.
    }
  }, [eventId, report?.level])
  if (!report || (report.level !== 1 && report.level !== 2) || dismissed === eventId) return null
  const title =
    report.level === 3
      ? 'printer.report_resume'
      : report.level === 2
        ? 'printer.report_critical'
        : report.level === 1
          ? 'printer.report_warning'
          : 'printer.report_info'
  return (
    <section role="alert" data-testid="printer-report" class="mb-4 rounded-lg border border-warning bg-panel p-4">
      <div class="flex items-start justify-between gap-3">
        <strong>
          {t(title)} · {tpl('printer.report_code', { code: report.code })}
        </strong>
        <button type="button" aria-label={t('printer.report_dismiss')} onClick={() => setDismissed(eventId)}>
          <X size={18} />
        </button>
      </div>
      {report.message && <p class="mt-2 whitespace-pre-wrap break-words">{report.message}</p>}
      <p class="mt-2 text-xs text-muted">
        {tpl('printer.report_last', { seconds: report.age })} {t('printer.report_history')}
      </p>
      {(!ok || !data.connected) && <p class="text-xs text-muted">{t('printer.report_disconnected')}</p>}
    </section>
  )
}
