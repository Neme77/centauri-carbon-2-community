# Stage 2 + PING + miniature

Base: Stage 2 + application PING. The only backend source change is src/main.c: isolated thumbnail extraction and POST /api/gcode-files/thumbnail. The web/index.html is BYTE IDENTICAL to CC2-UI-Layout4-Canvas-Popup-PING-Backend (working dashboard + Canvas popup). The existing print route and MQTT code are unchanged.

Request: POST /api/gcode-files/thumbnail, text/plain body: `internal\n<relative G-code path>` or `usb\n<relative G-code path>`. The server scans the first 4 MiB of the G-code for `; thumbnail begin WxH ...` / `; thumbnail_JPG begin WxH ...` and returns the largest complete embedded PNG/JPEG block as image/png or image/jpeg; supports 144x144 and 300x300. A missing/unsupported image yields a non-200 response and the preview placeholder remains. This endpoint is read-only, checks the existing G-code path validation, and does not publish MQTT commands. Limits: 4 MiB scanning and 1 MiB base64 per image.

Compile (WSL): `make clean && make && file dist/cc2-control/cc2-control`. Deploy only new binary into /opt/usr/cc2-stage2-ping-thumbnails/cc2-control and the included web/index.html into its web/ directory; do not overwrite the proven Stage 2 + PING.

First test: verify selected G-code preview and Canvas popup. Only then verify print initiation and an idle-period retry.
