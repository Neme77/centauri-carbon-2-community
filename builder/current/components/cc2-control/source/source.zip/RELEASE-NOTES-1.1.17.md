# CC2 Control 1.1.17

This maintenance release fixes protected-console commands remaining busy after
long resonance and bed-mesh calibrations.

## Fixed

- Increased the retained console output from 64 KiB to 256 KiB.
- Command completion is now detected directly from the printer stream, even
  when the visible console buffer is full.
- Completion markers split across multiple UDS reads are reconstructed safely.
- A saturated stream is released after ten seconds without new calibration
  reports instead of remaining blocked until the 15-minute timeout.
- Existing dashboard, USB printing, Canvas and material-preset behaviour is
  unchanged.

The inactivity fallback does not cancel a printer operation. It only releases
CC2 Control after the report stream has stopped.
