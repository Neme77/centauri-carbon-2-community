# CC2 Control 1.1.12

## Cold-start recovery

The Centauri Carbon 2 initializes Canvas twice during a cold boot. The MQTT
TCP connection may remain open while the printer discards CC2 Control's first
application registration. Version 1.1.12 no longer assumes that one successful
MQTT connection or one registration publish means the printer is fully ready.

- Repeats application registration until Canvas discovery completes.
- Repeats the `1002` snapshot request while discovery is pending.
- Repeats Canvas channel discovery with `method:2005`.
- Uses 10-second startup retries and one-minute long-term retries.
- Increases the post-`elegoo_printer` hardware delay from 12 to 20 seconds.
- Preserves the existing dashboard, controls, Bed Mesh and Canvas UI.

## Required cold-start test

Install the new binary and scripts, shut the printer down completely, then
power it on. Do not open the dashboard. After the printer display and Canvas
finish their second initialization, wait 30 seconds and run:

```sh
pidof cc2-control
wget -qO- http://127.0.0.1:8081/api/health
wget -qO- http://127.0.0.1:8081/api/canvas
```

The health response must report version `1.1.12`, registration and snapshot as
true. The Canvas response must report `"available":true`.
