# CC2 Control test plan

## Milestone 1.1.15 thermal-chart hotfix checks

- Open the dashboard at browser zoom 100% and leave it visible for at least five
  minutes; the thermal chart and camera card must not increase in height.
- Repeat at Windows display scaling 125% or 150%, or with a browser/device pixel
  ratio above 1; chart lines and labels must remain sharp without layout growth.
- Resize across the 900 px and 760 px breakpoints and confirm the chart settles
  at 130 px and 125 px respectively without cumulative changes.
- Reload the page and switch repeatedly between Dashboard, Bed Mesh and Canvas;
  the chart must retain its fixed height when the Dashboard becomes active again.
- Confirm temperature history continues to advance and remains bounded at 120
  samples while printer, MQTT and Canvas telemetry continue normally.

## Milestone 1.1.15 G-code library checks

- Open **G-code** and confirm internal files match `/opt/usr/gcode/local/`.
- Insert a USB drive containing `.gcode` files, press **Refresh files**, and
  confirm they appear under **USB drive** with relative paths, sizes and dates.
- Remove the drive, refresh, and confirm the UI reports that no USB drive is
  mounted without affecting the dashboard.
- Confirm non-G-code files and hidden files are not shown.
- Confirm merely opening or refreshing the tab neither starts nor modifies a
  print file, and that no continuous file-list polling occurs after leaving it.
- With the printer idle, choose a single-filament file and press **Print**.
  Confirm the popup shows all four current Canvas spools, select one, cancel and
  verify nothing starts. Repeat, accept, and confirm the selected spool is used.
- Open a known multicolour file containing at least `T0` and `T1`. Confirm the
  popup shows one mapping row per tool and refuses to start until every row has
  a Canvas spool. Map the tools to two different slots and verify the ordinary
  multicolour print-start sequence.
- For a single-filament file, clear **Use ELEGOO Canvas** and verify the explicit
  external/default filament path still works. The option must be unavailable
  for a multicolour file.
- While a job is active, attempt to start a second file and confirm the backend
  rejects it without disturbing the current print.
- Test one internal file and one USB file. Confirm the request uses the displayed
  file and that a removed USB file is rejected after backend revalidation.
- From SSH, verify `wget -qO- http://127.0.0.1:8081/api/gcode-files` returns valid
  JSON containing separate `internal` and `usb` objects.
- Reinspect a file after changing it and confirm a stale or incomplete mapping
  is rejected before method 1020 is sent.

## Milestone 1.1.14 first-run checks

- Back up and replace the persistent configuration with the empty template,
  restart CC2 Control and confirm port 8081 opens the setup wizard.
- Submit an invalid code and confirm it is rejected without replacing the file.
- Submit the real LAN access code and confirm the configuration is mode `600`.
- Confirm the wizard reports MQTT connection, registration and snapshot without
  putting the code in the URL, browser storage, API response or diagnostics.
- Reload during setup and confirm the wizard remains available until registration.
- After registration, confirm `POST /api/setup` returns `403` and the ordinary
  dashboard opens directly on later restarts.
- Confirm Canvas cold-boot discovery and custom material presets still work.

## Milestone 1.1.13 final checks

- Enable the bundled procd service, power-cycle the printer and do not open the Canvas tab.
- Confirm CC2 Control starts after `elegoo_printer` and `/api/health` reports version 1.1.13.
- Add a `PA-CF` preset, reload from another browser and confirm it remains available.
- Confirm `/opt/usr/cc2-control/material-presets.json` exists after the first save.
- Assign a custom safe material name and temperature range to an idle Canvas slot.
- Confirm the 3D mesh shows the Z=0 reference plate, X/Y/Z axes and vertical displacement stems.
- Within the startup discovery window, confirm `/api/canvas` becomes available without a manual refresh.
- Confirm method 2005 retries stop after valid `canvas_info` is received.
- Restart CC2 Control alone and confirm Canvas is discovered again after MQTT registration.

## Milestone 1.1.10 operational checks

- Confirm CC2 Control and MQTT connection labels are more legible and each has a glowing green dot.
- Confirm Dashboard, Bed Mesh and Canvas labels are slightly larger without crowding the navigation.
- Confirm thermal-chart labels and lines remain sharp at normal and high-DPI browser scaling.
- Confirm the dashboard below the compact system row and all Canvas behaviour remain unchanged.

## Milestone 1.1.9 operational checks

- Confirm the larger C2 mark and CC2 Control title remain balanced with the header height.
- On a wide screen, confirm Camera occupies the left column; Printer Status, Current Job and Print Time share the upper-right row; Thermals fills the area below them.
- Confirm Service, Available Memory, System Uptime, System Load and Messages form the compact row below the overview.
- Confirm the dashboard from Fans/Position/Hardware through the console is unchanged from 1.1.8.

## Milestone 1.1.8 Canvas checks

- Confirm the dashboard arrangement and fan controls match 1.1.4; no full-width Fans & Outputs panel is present.
- Open Canvas after restarting CC2 Control without touching the printer screen. The tab must issue one lightweight channel-information request and populate after the following MQTT update.
- If Canvas still remains unavailable, press **Refresh Canvas** once and inspect **Show diagnostic data**; the MQTT diagnostic should contain the response to method 2005 without writing anything into the G-code console.
- Confirm Canvas material, LOAD and UNLOAD buttons remain disabled until a connected module is reported.

## Milestone 1.1.5 operational checks

- Verify Canvas stays connected after partial MQTT updates and highlights `active_tray_id`.
- With the printer idle, verify slot selection, material save, LOAD and UNLOAD one operation at a time.
- Verify Canvas operations are rejected while printing or while the printer is not idle.
- Verify Part, Auxiliary and Chamber fan controls in their original 1.1.4 locations; Controller and Heater remain read-only.

1. Confirm the dashboard uses the same gradient panel language as the lower controls and no flat grey shell remains.
2. Confirm Current Job, Print Time, Service, Memory, Uptime, System Load and Messages share one compact row on a wide display.
3. Confirm CC2 Control and MQTT health appear at the right of the main navigation and no Platform Status panel remains.
4. Open Bed Mesh and switch repeatedly between Heatmap 2D and Surface 3D; both must retain and render the same data.

## Milestone 1.1.3 operational checks

1. After starting CC2 Control, load or select a Canvas tray so the printer emits `canvas_info`.
2. Confirm Canvas reports Online and shows the four trays in `tray_id` order.
3. Confirm loaded trays show their real colour, material, brand and nozzle range; empty trays must be labelled Empty.
4. Wait through multiple temperature updates and confirm the Canvas data remains visible.

## Milestone 1.1.2 operational checks

1. Confirm Camera and the combined Printer Status/Thermals column end at approximately the same vertical position with no large empty region.
2. Confirm nozzle, bed and chamber readings update in the compact thermal table and in the browser-only two-minute chart.
3. Open Canvas, operate or reload one Canvas slot, then inspect **Show diagnostic data** for the module message.
4. Confirm `/api/mqtt-diagnostic` remains bounded and the process RSS stays within the target after several minutes.

## Milestone 1.1 operational checks

1. Open **Bed Mesh 3D** after loading a valid mesh and confirm the coloured surface matches the minimum/high areas in the 2D heatmap.
2. Rotate by dragging, zoom with the mouse wheel or a two-finger pinch, change Z exaggeration and use **Reset view**.
3. Leave the 3D tab and confirm no animation or background rendering continues.
4. Open **Canvas** with the module connected and confirm four slots, active slot, materials, colours and state when supplied by the firmware snapshot.
5. If the Canvas fields are not recognised, open **Show diagnostic data**, copy the JSON and use it to add an exact firmware mapping. Do not publish the JSON before checking it for identifiers.
6. Confirm Canvas refreshes about every five seconds only while its tab is visible and that leaving the tab stops its timer.
7. Repeat the original memory measurement; browser rendering must not materially change `cc2-control` RSS or the printer services.

## Milestone 1.0 operational checks

1. Open the Bed Mesh tab and use **Read current mesh**; if the firmware exposes an active matrix, confirm the heatmap and table appear.
2. If no matrix is exposed, run a guided bed calibration and verify the graph grows progressively to 121 points.
3. Confirm the completed mesh reports minimum, maximum, range and average, and remains available after refreshing the browser.
4. Verify the graph orientation: X increases left-to-right and Y runs from rear at the top to front at the bottom.
5. Confirm switching tabs does not stop telemetry, webcam or console polling.

## Milestone 0.9 operational checks

1. Test part, auxiliary (`M106 P2`) and case (`SET_CAVITY_FAN`) fans independently at 25%, 50% and 0%.
2. Confirm PLA, PETG and ABS presets set only the documented nozzle/bed targets while idle and are rejected during printing.
3. Confirm extrusion/retraction is rejected below 170 °C, accepted while idle at or above 170 °C, and rejected during printing.
4. Confirm Motors Off and All Off are rejected during printing. After All Off, verify heater targets, part/aux/case fans and stepper motors are disabled; the automatic board fan may run briefly during cooldown.
5. Exercise Emergency Stop only as a dedicated recovery test; expect the printer engine to require recovery afterward.
6. Verify terminal history with Arrow Up/Down and run guided calibrations only with an empty bed and an idle printer.
7. Z-offset persistence remains intentionally disabled; the displayed mesh is stored only in the browser and does not write printer configuration. Do not run `SAVE_CONFIG` from this milestone.

## Original acceptance checks

This milestone is read-only and does not install a boot service.

1. `file cc2-control` reports ARM EABI5 and `statically linked`.
2. The process starts on TCP port 8081 without affecting ports 80, 8080, 1883 or 9001.
3. `http://PRINTER_IP:8081/` opens from a browser on the same LAN.
4. `/api/health` returns valid JSON every two seconds.
5. RSS remains below 3 MiB after five minutes.
6. `elegoo_printer`, `ai_camera` and Mosquitto retain their previous RSS and remain responsive.
7. `Ctrl+C` stops only CC2 Control.

## Measurements

```sh
PID=$(pidof cc2-control)
grep -E 'VmSize|VmRSS|VmData|Threads' /proc/$PID/status
free
netstat -lntp 2>/dev/null
```

Do not add automatic startup until all checks pass.
