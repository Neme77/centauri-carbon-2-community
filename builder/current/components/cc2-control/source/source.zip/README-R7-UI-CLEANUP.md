# CC2 Control v4.1 – R7 UI cleanup

R7 is a presentation-only cleanup based on the validated R6 package.

Changes:
- Browser title changed to `CC2 Control · Centauri Carbon 2`.
- Removed release-visible `Design proof`, `Design preview`, `Offline design proof`, and `Local preview` wording.
- Replaced initial demo/simulated labels with neutral connecting/live labels.
- Camera placeholders now use release wording (`Waiting for camera stream`).
- Footer and sidebar use community/local-control wording.
- Main `web/index.html` and firmware overlay web root are byte-identical.

No backend, Panda/Moonraker compatibility, API v1, console safety, or runtime behavior was intentionally changed.
