# CC2 Console v4.1 firmware work – Stage B

This test package starts from the last validated CC2 Control backend/UI combination and changes only the console path.

## Behaviour
- Unlock is local UI confirmation only: no password, token, or `UNLOCK GCODE` phrase.
- Every manual console command is rejected while `machine_status == Printing`.
- Console commands require Idle state.
- `G28` is allowed before homing.
- Before full XYZ homing, only known non-motion/status/heater/fan commands are accepted.
- Direct `G0/G1` moves require XYZ homing and live position telemetry.
- Direct `G0/G1` targets are checked against the same protected CC2 ranges already used by dashboard jog controls: X 0..256, Y 0..266, Z -2..256 mm.
- `G90/G91` mode is tracked for direct move pre-checks.
- After homing, normal Klipper commands/macros are passed to Klipper; Klipper remains the final authority for unsupported commands and kinematic validation.
- Commands that can intentionally bypass normal kinematic safeguards are blocked: `FORCE_MOVE`, `SET_KINEMATIC_POSITION`, `MANUAL_STEPPER`, `STEPPER_BUZZ`, `SET_STEPPER_ENABLE`, `M18`, `M84`, `G92`.

## Test sequence
Use only while the printer is idle and clear of obstacles.
1. Unlock console and run `STATUS`.
2. Before homing, try `G1 X10`: it must be rejected.
3. Run `G28`.
4. Run `G90`, then a small in-range move such as `G1 X100 F3000` only if that position is physically safe.
5. Try `G1 X300`: it must be rejected before Klipper receives it.
6. Start a harmless print and confirm `STATUS` from the manual console is rejected while printing. Do not test motion during a print.
