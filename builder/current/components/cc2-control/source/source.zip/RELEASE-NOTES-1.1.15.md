# CC2 Control 1.1.15

This hotfix removes a browser-only layout feedback loop in the live thermal
chart introduced by the high-DPI canvas sizing path.

- The chart keeps a fixed CSS height independent of its high-resolution backing
  buffer.
- Desktop, tablet and narrow-screen heights are pinned to 145, 130 and 125 px.
- The adjacent live-camera card no longer stretches as temperature samples are
  added.
- High-DPI rendering remains enabled, so graph lines and labels stay sharp.
- A new G-code tab lists print files from internal memory and a mounted USB
  drive, with relative path, size and modification date.
- File discovery is read-only and on demand. It scans only the two known printer
  storage roots, ignores symbolic links, limits recursion to four levels and
  returns at most 128 files per storage device.
- Each listed file has a Print button that opens a Canvas spool-selection
  dialog. CC2 Control detects the G-code tools and requires one physical spool
  assignment for every filament in a multicolour job.
- The backend revalidates the path, tool list, Canvas mapping and machine state,
  then sends firmware-native MQTT method 1020 with `local` or `u-disk` media and
  the official `t`, `canvas_id` and `tray_id` slot-map fields.
- Print start is rejected unless MQTT is registered and the printer reports
  Idle. The implementation uses layout A, no forced leveling and no timelapse.
  A single-filament job may explicitly use the external/default path; a
  multicolour job always requires a complete Canvas mapping.
- Deleting and uploading files are intentionally not part of this release.
  Canvas method 2005, persistent presets, protected controls and first-run setup
  are unchanged from 1.1.14.

Install both the updated service binary and web file, then refresh the browser.
No printer configuration or preset migration is required.
