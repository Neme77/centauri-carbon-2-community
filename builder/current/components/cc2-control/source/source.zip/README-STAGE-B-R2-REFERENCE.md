# CC2 Console v4.1 – Stage B R2 Reference

Base: `CC2-Console-v4.1-StageB-FULL(1).zip`.

## Changes in R2

### Backend
- Centralized console idle-state check in `console_idle_safe()`.
- Console remains completely blocked while `machine_status == 2` (Printing).
- Commands require live MQTT registration, machine status telemetry and non-stale telemetry.
- Rejections caused by a non-idle state now include the numeric `machine_status` to simplify printer-side diagnosis.
- Existing Stage B protections are preserved: G28 before homing, G0/G1 require full XYZ homing and protected ranges, G90/G91 tracking, and kinematic-bypass blacklist.

### UI
- Removed the yellow emoji padlock from the Locked/Unlocked status box.
- Replaced it with the same SVG lock family used by the Protected Terminal heading.
- Added a matching SVG `i-unlock` icon for the unlocked state.
- Removed the key emoji from Unlock Expert Mode.
- Lock/Unlock console button now uses matching SVG lock/unlock icons instead of emoji.
- Removed the lock emoji from the disabled command input.
- Backend rejection reasons are also written into the terminal output, not only shown as a toast.

## First printer test
1. Printer idle: unlock the console.
2. Send `STATUS` and `M105`.
3. Before homing, `G1 X10` must be rejected.
4. Send `G28`.
5. Send `G90`, then a physically safe in-range move.
6. `G1 X300` must be rejected before reaching Klipper.
7. Start a harmless print: `STATUS` from the manual console must be rejected.

If a command is rejected while the dashboard says Idle, copy the new terminal line containing the exact backend reason and `machine_status` value.
