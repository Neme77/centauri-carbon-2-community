# CC2 Control

Lightweight, independent web control platform for the ELEGOO Centauri Carbon 2.

Version 1.1.25 is the CC2 community firmware v4.1 integration baseline. It
combines the current Klipper-style bilingual interface, protected Console Stage
B R4, OrcaSlicer upload and confirmation flow, Canvas spool mapping, Panda
compatibility and Discovery API v1. The internal-light control now follows live
MQTT telemetry: it is highlighted in cyan while the chamber light is on and is
dimmed grey while it is off. The selected language is stored on the printer and
is therefore shared by normal browsers and the OrcaSlicer WebView. Backend,
health endpoint, discovery endpoint and the interface report the same 1.1.25
version.

Version 1.1.17 fixes long resonance and bed-mesh calibrations remaining busy
after their console output reached the previous 64 KiB limit. Completion is
now detected independently of the visible output buffer, split result markers
are handled, the buffer is 256 KiB, and a safe inactivity fallback releases a
saturated command stream. Version 1.1.16 keeps the high-DPI thermal-chart fix
from 1.1.15 and adds a
reliable USB printing workflow. USB G-code files are imported into protected
internal storage before the proven local MQTT start request is sent. This
matches the preparation stage observed on the original touchscreen and works
for files in the USB root as well as nested directories.

Version 1.1.15 fixed a high-DPI browser layout feedback loop in the live thermal
chart. The chart keeps a fixed responsive CSS height while its internal canvas
buffer still follows the display pixel ratio, so the thermal panel and adjacent
camera no longer grow vertically as telemetry samples arrive. It also adds a
G-code library for the printer's internal storage and mounted USB drive. The
bounded scan runs only when the G-code tab is opened or refreshed; it follows no
symbolic links and exposes only relative `.gcode` paths, sizes and modification
times. Print inspects the tools used by the file and opens a Canvas popup where
each G-code filament is assigned to one of the four physical spools. A confirmed
action uses native MQTT method 1020 with the official slot map and is accepted
only while the printer is idle. Printer, preset and first-run behaviour are
unchanged from 1.1.14.

Version 1.1.14 adds a first-run setup wizard to the dashboard. When CC2 Control
starts without a valid local MQTT configuration, opening port 8081 asks for the
printer LAN access code, writes the private configuration atomically with mode
`600`, and displays MQTT registration and snapshot progress. The setup endpoint
locks after successful printer registration. The code is never returned by an
API, placed in a URL or stored by the dashboard. `cc2-configure` remains the SSH
recovery path.

Version 1.1.13 adds printer-persistent custom material presets, free-form safe Canvas material names and a referenced 3D mesh with the ideal Z=0 plate, Cartesian axes and vertical displacement stems. It retains the 1.1.12 recovery of registration, snapshot and Canvas discovery across the printer's two-stage cold boot.
It retries method 2005 every 10 seconds during the first startup minute and,
if the accessory is still unavailable, once per minute thereafter. Discovery
stops as soon as valid `canvas_info` arrives. The distribution also includes a
procd service and a hardware-aware launcher for automatic TinaLinux startup.

Version 1.1.10 makes the CC2 Control and MQTT connection labels clearer, gives both
a glowing green status indicator, and slightly enlarges the primary navigation.
The thermal chart now matches its browser dimensions and the display pixel ratio,
eliminating stretched or blurred lines and labels without adding a render loop.

Version 1.1.9 follows the requested dashboard sketch: a larger C2 mark and title,
camera on the left, Status / Current Job / Print Time across the top right,
and Thermals below. Five system cards remain below the overview. Narrow screens
stack the panels. Lower controls and the working Canvas method 2005 are preserved.
JavaScript syntax, unique IDs and native C compilation were checked. Visual browser
verification was unavailable in the build environment (Chromium not installed).

Version 1.1.8 restores the proven 1.1.4 dashboard arrangement and its original fan-control placement. Canvas now requests the firmware's current channel information through its native MQTT API method 2005 (`CANVAS_GET_CHANNEL_INFO`), instead of incorrectly treating the API action as G-code or depending exclusively on a new `method:6000` event occurring after CC2 Control starts. Load, unload and material controls remain disabled until the module is actually detected.

Version 1.1.5 added retained Canvas slot/active-state telemetry and protected Canvas load/unload and material controls derived from the stock firmware protocol.

Version 1.1.3 maps the confirmed CC2 Canvas schema (`canvas_info.canvas_list[].tray_list[]`) and retains its latest telemetry separately from the rolling MQTT diagnostics. The Canvas tab now reports connection, four trays, material, colour, brand and recommended nozzle range from a dedicated endpoint.

Version 1.1.2 replaces the sparse upper dashboard with matched Fluidd-style Camera, Printer Status and Thermals panels. A lightweight two-minute temperature chart is drawn entirely in the browser. It also adds a bounded local MQTT diagnostic buffer and endpoint so Canvas telemetry can be identified from the printer's real messages instead of assuming it is part of `GetBasicInfo`.

Version 1.1.1 refreshes the upper dashboard with a denser Fluidd/Klipper-inspired visual language: flatter graphite panels, compact typography, reduced spacing and blue active-state accents. The established lower control workspace remains unchanged.

Version 1.1.0 adds an interactive, browser-rendered 3D view of the same bed mesh plus a read-only Canvas tab for the four-slot multicolour module. The 3D surface uses a dependency-free HTML canvas renderer with drag rotation, wheel/pinch zoom and adjustable Z exaggeration; it has no animation loop and therefore adds no continuous load. Canvas status is requested only while its tab is visible, using the existing local printer snapshot. A diagnostic view is included to identify firmware-specific Canvas field names during hardware validation.

Version 1.0.0 added the dedicated Bed Mesh tab with a colour heatmap, numeric 11×11 grid, summary statistics and browser persistence. It first queries Klipper's current `bed_mesh` object through ELEGOO's local UDS; while a calibration is running it can also reconstruct the mesh progressively from the three probe readings at each coordinate. The compact dashboard, camera, editable material presets, protected controls, guided calibrations and live print Z-offset remain available unchanged.

## Target

- ARMv7 hard-float (`arm-linux-gnueabihf`)
- no userspace C-library dependency (statically linked ARM binary)
- TinaLinux / OpenWrt-style userspace
- firmware installation directory: `/opt/inst/cc2-control`
- persistent configuration directory: `/opt/usr/cc2-control`
- TCP port: `8081`

## Current endpoints

- `GET /` — diagnostic dashboard
- `GET /api/health` — service, system uptime, load average and memory data
- `GET /api/setup` — first-run state without exposing credentials
- `POST /api/setup` — save the access code only while first-run setup is active
- `GET /api/printer` — accumulated temperatures, fans, machine/job status, motion and hardware telemetry
- `GET /api/snapshot` — temporary diagnostic view of the latest `GetBasicInfo` response
- `GET /api/mqtt-diagnostic` — bounded recent local MQTT payloads used to discover Canvas telemetry
- `GET /api/canvas` — latest retained CC2 `canvas_info` telemetry (the Canvas tab requests channel discovery when this is initially unavailable)
- `POST /api/canvas/refresh` — request current Canvas channel information through firmware API method 2005
- `GET /api/gcode-files` — bounded read-only listing of `.gcode` files in internal storage and the mounted USB drive
- `POST /api/gcode-files/inspect` — safely detect the G-code tool/filament identifiers used by a selected file
- `POST /api/gcode-files/print` — revalidate file and Canvas mapping, then submit native MQTT start method 1020 while idle
- `GET /api/mesh` — raw protected `bed_mesh` object query through the local printer UDS
- `GET /api/console` — current console job and captured UDS reports
- `POST /api/console/clear` — clear captured terminal output when no command is running
- `POST /api/console/command` — submit one whitelisted command as `text/plain`
- `POST /api/control` — submit one structured, range-checked dashboard action

The console accepts informational commands at any time and selected calibration commands only while the printer is idle. Multiline commands, unrestricted G-code, `SAVE_CONFIG`, firmware restarts and low-level motion commands remain blocked. PID targets are range checked. A detached worker keeps dashboard and MQTT telemetry responsive during long calibrations.

Dashboard controls are translated into fixed backend-generated scripts. Manual motion requires telemetry, homed axes, an idle printer and a destination inside the protected build volume. Heater, fan, speed and flow values are range checked. Cancel requires browser confirmation. The printer serial is learned from the first MQTT status topic and appended to the private local configuration, allowing immediate registration on later starts.

## Local configuration

Copy `cc2-control.conf.example` to `cc2-control.conf`, set the printer access code locally, and restrict its permissions:

```sh
cp cc2-control.conf.example cc2-control.conf
chmod 600 cc2-control.conf
```

Do not commit or distribute `cc2-control.conf`. The access code is read by the backend and is never returned by the HTTP API or sent to the browser.

## Build on Ubuntu or WSL

Install an ARM hard-float cross compiler:

```sh
sudo apt update
sudo apt install gcc-arm-linux-gnueabihf
```

Build:

```sh
make
```

The result is `build/cc2-control`. The default build is static so it remains
compatible with the printer's older glibc 2.23 userspace.

Verify it before copying:

```sh
file build/cc2-control
```

The output must contain `ELF 32-bit`, `ARM`, `EABI5` and `statically linked`.

## Manual test on the printer

Copy the complete `dist/cc2-control` directory to `/opt/usr/cc2-control`, then run:

```sh
chmod +x /opt/usr/cc2-control/cc2-control
/opt/usr/cc2-control/start.sh
```

Open:

```text
http://PRINTER_IP:8081/
```

Stop it with `Ctrl+C`. No boot service is installed in this milestone.

## Resource target

The native service is designed to remain below 2–3 MiB RSS. Verify on the printer with:

```sh
PID=$(pidof cc2-control)
grep -E 'VmSize|VmRSS|VmData|Threads' /proc/$PID/status
```

## Safety

Keep port 8081 on a trusted LAN. Authentication and reverse-proxy support will be added before any remote-access release.
