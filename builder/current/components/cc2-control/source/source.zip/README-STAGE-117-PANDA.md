# CC2 Control 1.1.17 + Panda bridge — isolated stage 1

This is the original 1.1.17 source with **only** the read-only Panda compatibility bridge from 1.1.22 integrated. The original 1.1.17 `src/mqtt.c`, `src/console.c`, `src/control.c`, `web/index.html`, and the G-code/Canvas handling in `src/main.c` remain unchanged. `src/main.c` only includes/starts/stops the Panda module and parses `--panda-port`. The Makefile adds `src/panda.c` to compilation.

The Panda bridge is a read-only Moonraker-like compatibility layer. It does NOT implement OrcaSlicer upload/print or thumbnail endpoints. Its port is 7125 by default; use `--panda-port 0` to disable it. Do not overwrite the working 1.1.17, firmware, `elegoo_printer`, or the installed 1.1.22 binary.

## Build under Ubuntu WSL (ARM toolchain required)

Extract this archive into `C:\\CC2_TEST_117_PANDA` and run from PowerShell:

```powershell
wsl -d Ubuntu -- bash -lc "cd /mnt/c/CC2_TEST_117_PANDA && make clean && make"
wsl -d Ubuntu -- bash -lc "file /mnt/c/CC2_TEST_117_PANDA/dist/cc2-control/cc2-control"
```

Confirm that `file` identifies a **32-bit ARM** ELF; if compilation fails or the result is x86-64, do not transfer it.

## Install to an isolated directory

After the active print is complete and the printer is idle:

```powershell
ssh root@192.168.1.103 "mkdir -p /opt/usr/cc2-test117-panda/web"
scp "C:\\CC2_TEST_117_PANDA\\dist\\cc2-control\\cc2-control" root@192.168.1.103:/opt/usr/cc2-test117-panda/
scp "C:\\CC2_TEST_117_PANDA\\dist\\cc2-control\\web\\index.html" root@192.168.1.103:/opt/usr/cc2-test117-panda/web/
```

SSH into the printer and stop ONLY the currently running CC2 Control instance (do not stop `elegoo_printer` or Mosquitto):

```sh
PID=$(pidof cc2-control)
[ -n "$PID" ] && kill "$PID"
sleep 2
pidof cc2-control
```

If `pidof` still shows a process, investigate the service respawn and stop its init service before proceeding; never run two copies on port 8081. Once the previous instance has stopped:

```sh
chmod +x /opt/usr/cc2-test117-panda/cc2-control
/opt/usr/cc2-test117-panda/cc2-control \
  --port 8081 --panda-port 7125 \
  --web-root /opt/usr/cc2-test117-panda/web \
  --config /opt/usr/cc2-control/cc2-control.conf \
  --presets /opt/usr/cc2-control/material-presets.json \
  > /opt/usr/cc2-test117-panda/test.log 2>&1 &
readlink /proc/$(pidof cc2-control)/exe
wget -qO- http://127.0.0.1:8081/api/health
wget -qO- http://127.0.0.1:7125/server/info
```

Open `http://192.168.1.103:8081`, use the original UI, and test one small known-good G-code with the correct Canvas slot, supervised, only after confirming the printer is idle. `202 Accepted` alone does not verify actual print start; observe the real printer state.

## Restore the original firmware 1.1.22 service

Once the printer is idle:

```sh
PID=$(pidof cc2-control)
[ -n "$PID" ] && kill "$PID"
sleep 2
/etc/init.d/cc2-control start
readlink /proc/$(pidof cc2-control)/exe
```

Expected original path: `/opt/inst/cc2-control/cc2-control`. To restore the previously working **test** 1.1.17 instead, stop the stage-1 process and relaunch `/opt/usr/cc2-test117/cc2-control` with its previous command line; the stage-1 package does not replace it.

## Verification limits

A native Linux x86-64 build and offline Panda/G-code tests were performed. The package contains source only, **not** an ARM binary; ARM cross-compilation and the live print trial are to be performed on the user's WSL/printer. Do not claim that this stage has already printed successfully.
