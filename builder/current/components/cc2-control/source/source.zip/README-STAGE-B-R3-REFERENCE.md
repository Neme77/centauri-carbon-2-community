# CC2 Console v4.1 – Stage B R3 Reference

R3 is based on the validated R2 reference package and changes only the manual-console UI state handling.

## R3 fix
- Fixed manual G-code input being cleared by the periodic `expertUi()` refresh.
- `expertUi()` no longer assigns `input.value = ''`.
- The informational row under the console now follows the real lock state:
  - Locked: `Console is locked. Unlock Expert Mode to enable command input.`
  - Unlocked: `Console unlocked. Backend safety guards remain active.`
- R2 lock/unlock SVG icon cleanup is preserved.
- R2 backend safety guards are unchanged.

## Expected test
1. Unlock Expert Mode and accept the warning.
2. Confirm the input remains editable while typing for several seconds.
3. Type a manual command such as `STATUS` and send it.
4. Before homing, `G1 X10` must still be rejected.
5. `G28` must be allowed while idle.
6. During printing the manual console must remain blocked by backend safety guards.
