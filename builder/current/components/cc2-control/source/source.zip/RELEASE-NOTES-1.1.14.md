# CC2 Control 1.1.14

This release adds browser-based first-run configuration for firmware installs
that do not already have `/opt/usr/cc2-control/cc2-control.conf`.

- Port 8081 displays a guided setup overlay only when MQTT credentials are
  missing or incomplete at process start.
- The access code is validated, written atomically and protected with mode 600.
- The browser shows configuration, MQTT registration, snapshot and Canvas
  discovery progress without receiving the saved credential.
- Setup remains available for correcting an unsuccessful first attempt, then
  locks automatically after successful printer registration.
- Existing configured installations open the dashboard normally.
- `cc2-configure` remains available through SSH as a recovery method.
- CC2 Control 1.1.13 presets, 3D mesh and cold-boot Canvas recovery are retained.
