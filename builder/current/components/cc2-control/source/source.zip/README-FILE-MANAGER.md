# CC2 Control — Stage 2 + PING + Layout 4 + thumbnails + file manager

This test build adds G-code upload and deletion to the last verified Stage 2 + application PING / Layout 4 / Canvas-popup / thumbnail build.

## New operations

- `POST /api/gcode-files/upload?storage=internal|usb&name=<URL-encoded basename>`: raw `application/octet-stream` file bytes, `Content-Length` required, at most 64 MiB. The upload runs in a dedicated worker to avoid pausing the main MQTT heartbeat. One upload at a time. New files are written to a hidden temporary file and published only after the transfer finishes. Existing names are never overwritten. HTTP 201 means the file was saved, not printed.
- `POST /api/gcode-files/delete`: plain-text body `internal\n<relative/path.gcode>` or `usb\n<relative/path.gcode>`; HTTP 200 on successful deletion.
- Upload and deletion do not request or verify the printer LAN access code; this change applies only to these two file operations.
- Mutations require a fresh, connected, idle machine state. USB writes/deletes require a mounted, writable USB filesystem. File-extension, traversal, symlink and no-overwrite checks are enforced.
- Neither operation runs a print, invokes Canvas, or modifies the MQTT start command.

## Limitations and cautions

- **Unauthenticated file upload and deletion:** any device that can access port 8081 can modify G-code files. Limit access to your trusted LAN; never publish port 8081 to the Internet or an unauthenticated reverse proxy.
- The USB must be mounted at the configured `--gcode-usb` directory (default `/mnt/exUDISK`) and writable. If the printer uses a different USB path, configure that path only after inspecting actual mounts.
- Uploads are supported for `.gcode` filenames (basename only), not `.3mf` or arbitrary filesystem paths; existing subdirectories are browseable/deletable but uploads always target the chosen support's root.
- The 64 MiB maximum is deliberately conservative for the printer hardware; upload only when the machine is idle. No simultaneous transfers.
- Backend and browser tests were run on desktop Linux; **ARM compilation, USB hardware compatibility, and full printing on Centauri Carbon 2 must be checked on the device before treating this as a production release.**

## Deployment

Unzip on PC as `C:\CC2_TEST_FILE_MANAGER`. In WSL Ubuntu run:

```sh
cd /mnt/c/CC2_TEST_FILE_MANAGER && make clean && make && file dist/cc2-control/cc2-control
```

Copy the binary and `dist/cc2-control/web/index.html` to a new directory on the printer, e.g. `/opt/usr/cc2-file-manager/` and `/opt/usr/cc2-file-manager/web/`. Start with the same 8081/7125/config/presets options as the verified Stage 2 + PING, changing only `--web-root` to that new directory. Keep the verified version intact for rollback.

## Initial test sequence

1. Check `/api/health` and that the active executable points to `/opt/usr/cc2-file-manager/cc2-control`.
2. Inspect a thumbnail and verify that the Canvas popup and first print still work; the PING regression needs a later idle-period print test too.
3. Upload a **disposable** small `.gcode` to internal memory. Verify the file appears in the refreshed list and inspect its size and thumbnail. Then delete that disposable file and verify that it disappears.
4. With a writable mounted USB, repeat with another disposable `.gcode` on USB. Verify a same-name upload is rejected rather than overwritten.
5. Never use a valuable G-code to test deletion. Never upload or delete while printing.
